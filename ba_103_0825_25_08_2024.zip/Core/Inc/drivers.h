/*
 * drivers.h
 *
 *  Created on: 6 дек. 2022 г.
 *      Author: vitaly
 */

#ifndef INC_DRIVERS_H_
#define INC_DRIVERS_H_

#define  TRUE_VALUE_DELAY	16		// in cycles count measuring
#define  SIFU_BEGIN_VALUE	100
#define  SIFU_START_VALUE	5
#define	 SIFU_MINIMAL_VALUE	10

#define  BUZZER_PIN_ON		1
#define  BUZZER_PIN_OFF		0
#define  PWM_ON				1
#define  PWM_OFF			0

#define  RELAY_SHNEK1		0
#define  RELAY_SHNEK2		1
#define  RELAY_SHNEK3		2
#define  RELAY_HEATER		3
#define  RELAY_PUMP			4
#define  RELAY_FAN			5
#define  RELAY_KOLOSNIK_ON	6
#define  RELAY_KOLOSNIK_OFF	7
#define  RELAY_LOCK			8		// PB6

#define  IND_PULSE_LEN		3		//  3 mSec
#define  IND_DIGIT			5		//  count digit leds
#define  DIGIT_SET			1
#define  DIGIT_CLR			0
#define  DIGIT_OFF			0
#define	 LED				0
#define  RELAY				1

#define  ADC_BUFF_LEN		18
#define  ADC_FILTER_VAL		3		// pick for skip value
#define  NTC_SENSOR_SHORT	-10		// -10(C) for testing NTC sensors
#define  NTC_SENSOR_OPEN	150		// 150(C) for testing NTC sensors

#define	SCLOCK()		HAL_GPIO_WritePin(SCLK_GPIO_Port, SCLK_Pin, GPIO_PIN_SET); HAL_GPIO_WritePin(SCLK_GPIO_Port, SCLK_Pin, GPIO_PIN_RESET)
#define	SLATCH()		HAL_GPIO_WritePin(LATCH_GPIO_Port, LATCH_Pin, GPIO_PIN_RESET); HAL_GPIO_WritePin(LATCH_GPIO_Port, LATCH_Pin, GPIO_PIN_SET)
#define OE_LED_SET()	HAL_GPIO_WritePin(OE_LED_GPIO_Port, OE_LED_Pin, GPIO_PIN_RESET)
#define OE_LED_UNSET()	HAL_GPIO_WritePin(OE_LED_GPIO_Port, OE_LED_Pin, GPIO_PIN_SET)
#define OE_OUT_SET()	HAL_GPIO_WritePin(OE_OUT_GPIO_Port, OE_OUT_Pin, GPIO_PIN_RESET)
#define OE_OUT_UNSET()	HAL_GPIO_WritePin(OE_OUT_GPIO_Port, OE_OUT_Pin, GPIO_PIN_SET)
#define OE_IN_LOAD()	HAL_GPIO_WritePin(OE_IN_GPIO_Port, OE_IN_Pin, GPIO_PIN_RESET); HAL_GPIO_WritePin(OE_IN_GPIO_Port, OE_IN_Pin, GPIO_PIN_SET)
#define SDOUT_SET()		HAL_GPIO_WritePin(SDOUT_GPIO_Port, SDOUT_Pin, GPIO_PIN_SET)
#define SDOUT_CLR()		HAL_GPIO_WritePin(SDOUT_GPIO_Port, SDOUT_Pin, GPIO_PIN_RESET)
#define SDLED_SET()		HAL_GPIO_WritePin(SDLED_GPIO_Port, SDLED_Pin, GPIO_PIN_SET)
#define SDLED_CLR()		HAL_GPIO_WritePin(SDLED_GPIO_Port, SDLED_Pin, GPIO_PIN_RESET)

#define	KEY_RELEASED		0x0000000F
#define KEY_UP_PRESS		0x0000000E
#define KEY_DN_PRESS		0x0000000D
#define KEY_ESC_PRESS		0x0000000B
#define KEY_ENT_PRESS		0x00000007
#define KEY_UP_DN_ENT_PRESS 0x00000008
#define TIME_PRESS_DLY		50			// in millisecond
#define LONG_PRESS_DLY		2000		// in millisecond
#define UP_SHORT			0x01
#define UP_LONG				0x11
#define DN_SHORT			0x02
#define DN_LONG				0x22
#define ENT_SHORT			0x04
#define ENT_LONG			0x44
#define ESC_SHORT			0x08
#define ESC_LONG			0x88
#define TIMEOUT_SERVICE		1200		// in second -1
#define TIMEOUT_AUTOMAT		10			// in second -1
#define COUNT_AUTO_PUSH		150			// in mSec.

#define REGIM_RED			0x04
#define REGIM_GREEN			0x02
#define REGIM_YELLOW		0x06
#define REGIM_OFF			0
#define STATE_GREEN			0x40
#define STATE_RED			0x20
#define STATE_YELLOW		0x60
#define STATE_OFF			0

#define	FLASH_OFF			0
#define	FLASH_DIGIT			0x80  // 7
#define FLASH_REGIM			0x40  // 6
#define	FLASH_REGIM_RG		0x20  // 5
#define	FLASH_STATE_RG		0x10  // 4
#define FLASH_STATE			0x08  // 3
#define	FLASH_STATE_1		0x09  // pulse1, 1 short
#define	FLASH_STATE_2		0x0A  // pulse2, 3 short
#define	FLASH_STATE_3		0x0C  // pulse3, meandr
#define	FLASH_STATE_4		0x0B  // pulse4, inv. 3 short
#define FLASH_PERIOD		100			// in mSec*3.
#define DIGIT_POINT			0x80
#define FLASH_PULSE_1		10   // cntStFlash steps
#define FLASH_PAUSE_1	    20
#define FLASH_PULSE_2   	30
#define FLASH_PAUSE_2   	40
#define FLASH_PULSE_3   	50
#define FLASH_PAUSE_3   	60
#define FLASH_PERIOD_LEN    200

#define BEEP_PULSE_1		1			// short beep
#define BEEP_PULSE_2		2			// middle beep
#define BEEP_PULSE_3		3			// long beep
#define BEEP_PULSE_4		4			// 3 long beep
#define BEEP_PULSE_5		5			// 5 x 3 long beep

#define BEEP_SHORT			10			// in mSec
#define BEEP_MIDLE			25			// in mSec
#define BEEP_LONG			500			// in mSec
#define BEEP_PAUSE			200			// in mSec
#define BEEP_SERIES_PAUSE	1000		// in mSec

#define SHNECK_WAIT			0
#define	SHNECK_COOL			1

#define PUMP_RUN_ON			1
#define PUMP_RUN_OFF		0
#define SHNECK_COOL_ON		1
#define SHNECK_COOL_OFF		0

// MACROS BITS
#define	BIT_SET(port, n)	(port |= (1 << n))
#define BIT_CLR(port, n) 	(port &= ~(1 << n))
#define BIT_INV(port, n) 	(port ^= (1 << n))
#define BIT_TEST(port, n) 	(port & (1 << n))

extern UART_HandleTypeDef huart1;
extern RTC_HandleTypeDef hrtc;

RTC_TimeTypeDef time;
RTC_DateTypeDef date;
HAL_StatusTypeDef res;
uint32_t secLogCnt;

uint16_t countSample;			// for ADC
uint8_t  countADC;
uint8_t  trueValue;
uint16_t ADC_result[8];
uint16_t UIN[ADC_BUFF_LEN];
uint16_t NTC_Hot[ADC_BUFF_LEN];
uint16_t NTC_Cold[ADC_BUFF_LEN];
uint16_t NTC_gor[ADC_BUFF_LEN];
uint16_t NTC_sg[ADC_BUFF_LEN];
uint16_t NTC_vyh[ADC_BUFF_LEN];
int      U_input;
int      T_hot;
int      T_cold;
int      T_gor;
int      T_sg;
int      T_vyh;

uint8_t  event_1mS_drv;
uint8_t  event_1sec_drv;
uint8_t  Tick10ms;
uint8_t  Tick50ms;
uint16_t Tick250ms;
uint16_t timeoutService;	// in second
uint16_t timeoutAutomat;	// in second

uint16_t keyNow;
uint16_t keyOld;
uint16_t keyPress;
uint16_t cntPress;
uint16_t cntLongPress;
uint8_t  keyboard;		// 0,1,2,3-short, 4,5,6,7-long
uint8_t  tmp_pump;

uint8_t  inputData;
uint8_t  relayData;			// storage current settings for data output

uint8_t  rm_counter;
uint16_t cntEeRamAddr;
uint16_t cntPresetAddr;
uint16_t defPRaddr;
uint16_t cntDebugAddr;

uint8_t  sifuTestFlag; 	// flag for service only, 0-off, 1-test
uint8_t  sifuTestCntr;	// control for service only, 0-up, 1-down, 2-relay on

uint8_t  log_debug;

typedef struct
{
	uint8_t	Digit1;
	uint8_t	Digit2;
	uint8_t Digit3;
	uint8_t LedRegim;	  // 0-off, 0x02-red, 0x04-green, 0x06-yellow
	uint8_t LedState;	  // 0-off, 0x40-red, 0x20-green, 0x60-yellow
	uint8_t stateInd;	  // current visible, 0-off, 1-digit1, .....
	uint8_t Flashing;     // flashing mode
	uint32_t periodFlash; // frequency flashing
	uint32_t flagFlash;    // flag flasing for all
	uint32_t cntStFlash;  // flag-counter flasing for led state
	uint8_t  datSt;		  // flag for led state
	uint32_t pulseCnt;
} display;

typedef struct
{
	uint16_t Lengh;
	uint16_t Pause;
	uint8_t  cnt;			// series beeper
	uint8_t  State;
} beeper;

typedef struct
{
	uint8_t  state;
	uint16_t delayCnt;
	uint16_t cycleCnt;
} shneck_t;

shneck_t Shneck;

display ledDisplay;
beeper  beepPick;

void InitDrivers(void);
void Drivers(void);
//void PWM_Pin(uint8_t);
void Ventilator(uint8_t st, uint8_t val);
void TestVentilator(void);
void Working(void);
void Nasos(void);
void CoolShneck(void);
void LEDs(void);
void Relays(uint8_t chan, uint8_t state);
uint8_t LoadData(uint8_t led, uint8_t rel);
void ReadKeys(void);
uint16_t Keyboard(void);
uint8_t Decode(uint8_t);
void Display(char*, uint8_t, uint8_t, uint8_t);
void Beep(uint8_t pulse);
void BeepRun(void);
void Buzzer(uint8_t state);
int ConvTemperature(int vadc);
int ConvTermopara(int);
int TestNTCsensor(int, uint16_t);
void Delays(void);
void Meassure(void);
void OutputToRegister(void);
void OffAllRelays(void);
void InitEEPROM(void);
void ReadEEtoRAM(uint32_t, uint8_t*, uint16_t);
void WriteRAMtoEE(uint32_t, uint8_t*, uint16_t);
void CompareEEpromRAM(void);
void CompareEEpresetRAM(void);
void CompareEEdebugRAM(void);
uint16_t GetPresetAddr(uint16_t pr);
void PrintTick(void);
void Println1(char _out[]);
void Println3(char _out[]);

#endif /* INC_DRIVERS_H_ */
