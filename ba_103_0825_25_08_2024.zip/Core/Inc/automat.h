/*
 * automat.h
 *
 *  Created on: 25 февр. 2023 г.
 *      Author: vitaly
 */

#ifndef INC_AUTOMAT_H_
#define INC_AUTOMAT_H_

#define    _AUTOMAT_OUTPUT_UART

//#define		_MEMORY_25_SERIES		// for save local parameters
#define		_MEMORY_24_SERIES		// for save local parameters

#define		CURRENT_VERSION		    825		//  25/08/2024

//#define		RAM_CONFIG_LEN_BYTES	0x0100	// 140 bytes -> 70 words,

#define		RR_BIT_REMOTE			0		//
#define		RR_BIT_LOCAL			1		//
#define		RR_BIT_CLEAR			2		//
#define		RR_LOCAL				0x0002	//

#define		RC_DEFAULT				0x0004

#define		PERIOD_PI				10		// in sec.

#define		T_HOT_IND_MIN			0		// in (C)
#define		T_HOT_IND_MAX			100		// in (C)

#define		DEFAULT_t1				300		// 0...1200  sec.
#define		MAX_t1					1200	// 0...1200  sec.
#define		DEFAULT_t2				60		// 0...120  sec.
#define		MAX_t2					120		// 0...120  sec.
#define		DEFAULT_t3				60		// 0...120  sec.
#define		MAX_t3					120		// 0...120  sec.
#define		DEFAULT_t4				20		// 0...120  sec.
#define		MAX_t4					120		// 0...120  sec.
#define		DEFAULT_t5				60		// 0...120  sec.
#define		MAX_t5					120		// 0...120  sec.
#define		DEFAULT_t6				20		// 0...60  sec.
#define		MAX_t6					60		// 0...60  sec.
#define		DEFAULT_t7				40		// 5...120  sec.
#define		MAX_t7					120		// 5...120  sec.
#define		MIN_t7					5		// 5...120  sec.
#define		DEFAULT_t8				120		// 5...400  sec.
#define		MAX_t8					400		// 5...400  sec.
#define		MIN_t8					5		// 5...400  sec.
#define		DEFAULT_t9				120		// 0...2400  sec.
#define		MAX_t9					2400	// 0...2400  sec.
#define		DEFAULT_t10				180		// 0...2400  sec.
#define		MAX_t10					2400	// 0...2400  sec.
#define		DEFAULT_t11				60		// 0...120  sec.
#define		MAX_t11					120		// 0...120  sec.
#define		DEFAULT_t12				180		// 0...300  sec.
#define		MAX_t12					300		// 0...300  sec.
#define		DEFAULT_t13				2		// 1...20  sec.
#define		MAX_t13					20		// 1...20  sec.
#define		MIN_t13					1		// 1...20  sec.
#define		DEFAULT_t14				8		// 1...30  sec.
#define		MAX_t14					30		// 1...30  sec.
#define		MIN_t14					1		// 1...30  sec.
#define		DEFAULT_t15				30		// 0...240  sec.
#define		MAX_t15					240		// 0...240  sec.
#define		DEFAULT_t16				30		// 0...600  sec.
#define		MAX_t16					600		// 0...600  sec.
#define		DEFAULT_t17				60		// 0...600  sec.
#define		MAX_t17					600		// 0...600  sec.
#define		DEFAULT_t18				40		// 0...600  sec.
#define		MAX_t18					600		// 0...600  sec.
#define		DEFAULT_t20				600		// 0...2400  sec.
#define		MAX_t20					2400	// 0...2400  sec.
#define		DEFAULT_t21				300		// 0...2400  sec.
#define		MAX_t21					2400	// 0...2400  sec.
#define		DEFAULT_t22				40		// 5...120  sec.
#define		MAX_t22					120		// 5...120  sec.
#define		MIN_t22					5		// 5...120  sec.
#define		DEFAULT_t23				120		// 5...400  sec.
#define		MAX_t23					400		// 5...400  sec.
#define		MIN_t23					5		// 5...400  sec.
#define		DEFAULT_t24				600		// 0...1800  sec.
#define		MAX_t24					1800	// 0...1800  sec.
#define		DEFAULT_t25				60		// 0...180  sec.
#define		MAX_t25					180		// 0...180  sec.
#define		DEFAULT_t26				30		// 0...240  sec.
#define		MAX_t26					240		// 0...240  sec.

#define		DEFAULT_T1				50		// 40...75
#define		MAX_T1					75		// 40...75
#define		MIN_T1					40		// 40...75
#define		DEFAULT_T4				400		// 0...700
#define		MAX_T4					700		// 0...700
#define		DEFAULT_T5				40		// 20...60, 40
#define		MIN_T5					20		// 20...60
#define		MAX_T5					60		// 20...60
#define		DEFAULT_T6				75		// 40...75
#define		MAX_T6					75		// 40...75
#define		MIN_T6					40		// 40...75
#define		DEFAULT_T7				85		// 0...100
#define		MAX_T7					100		// 0...100
#define		DEFAULT_T8				55		// 0...100
#define		MAX_T8					100		// 0...100
#define		DEFAULT_T9				80		// 0...100
#define		MAX_T9					100		// 0...100
#define		DEFAULT_T10				95		// 0...100
#define		MAX_T10					100		// 0...100
#define		DEFAULT_T11				50		// 0...100
#define		MAX_T11					100		// 0...100
#define		DEFAULT_T12				65		// 0...100
#define		MAX_T12					100		// 0...100
#define		DEFAULT_T13				NTC_SENSOR_OPEN		// 100...200
#define		MAX_T13					200		// 100...200
#define		MIN_T13					100		// 100...200
#define		DEFAULT_T14				NTC_SENSOR_SHORT	// -20...0
#define		MAX_T14					0		// -20...0
#define		MIN_T14					-20		// -20...0
#define		DEFAULT_T19				5		//  const

#define		DEFAULT_KI				1000		// 0...65535
#define		DEFAULT_KP				1000		// 0...65535

#define		DEFAULT_N1				5		// 1...10
#define		MAX_N1					10		// 1...10
#define		MIN_N1					1		// 1...10
#define		DEFAULT_N2				3		// 0...5
#define		MAX_N2					5		// 0...5
#define		DEFAULT_N3				2
#define		DEFAULT_N4				5
#define		DEFAULT_N5				5		// 1...10
#define		MAX_N5					10		// 1...10
#define		MIN_N5					1		// 1...10

#define		DEFAULT_Q1				32		// 0...100  %
#define		DEFAULT_Q2				15		// 0...100  %
#define		DEFAULT_Q3				50		// 0...100  %
#define		DEFAULT_Q4				37		// 0...100  %
#define		DEFAULT_Q7				30		// 0...100  %
#define		DEFAULT_Q8				30		// 0...100  %
#define		MAX_QQ					100		// %
#define		MIN_QQ					10		// %

#define		DEFAULT_DELTA_T1		3		// 0...10
#define		MAX_DELTA_T1			10		// 0...10
#define		DEFAULT_DELTA_T4		100		// 0...500
#define		MAX_DELTA_T4			500		// 0...500
#define		DEFAULT_DELTA_T3		5		// 5...20
#define		MAX_DELTA_T3			20		// 5...20
#define		MIN_DELTA_T3			5		// 5...20
#define		DEFAULT_DELTA_T19		2
#define		DEFAULT_PRESET			0
#define		MAX_PRESET				4

#define		MISMATCH_PI_ARR_LEN		16

//#define		PINTYPE_NO				0
//#define		PINTYPE_NC				1
//#define		DEFAULT_CFG_TYPE		0			// type only, NO
#define		DEFAULT_CFG_DELAY		0x0002		// delay only, 3 sec.

#define		DISPLAY_AVARY_MIN		0
#define		DISPLAY_AVARY_MAX		12

// menu constant
#define		CURR_AUTH				0x0
#define		RUN_MENU				0x01
#define		SUB_RUN_MENU			0x02
#define		AVARY_MENU				0x04
#define		CURR_SERVICE			0x40
#define		SUB_MENU_SERVICE		0x41
#define		IN_TO_SERVICE			0x80	// display "CPВ" one second
// menu automat
#define		RUN_MENU_MIN			1
#define		RUN_ACTIVE				1
#define		RUN_SET_UST				2
#define		RUN_SET_ADDR			3
#define		RUN_SET_MODE			4
#define		RUN_MENU_MAX			4
/// menu service
#define		SERVICE_MIN				101
#define		SERVICE_UGO				101		// колосники открыты
#define     SERVICE_UGZ				102		// колосники закрыты
#define		SERVICE_UZO				103		// удаление золы
#define		SERVICE_GO1				104		// горючее 1
#define		SERVICE_GO2				105		// горючее 2
#define		SERVICE_NAG				106		// нагреватель
#define		SERVICE_NAS				107		// насос
#define		SERVICE_VEN				108		// вентилятор
#define		SERVICE_LOCK			109		// Блокиров. подачи горючего
#define		SERVICE_TPOD			110		// температура подачи
#define		SERVICE_TOBR			111		// температура обратки
#define		SERVICE_TGOR			112		// температура горючего
#define		SERVICE_TSG				113		// температура сгорания
#define		SERVICE_TVYH			114		// температура выхлопа
#define		SERVICE_CC				115		// светодиод Состояние
#define		SERVICE_CR				116		// светодиод Режим
#define		SERVICE_7C				117		// 7-ми сегментный
#define		SERVICE_PV				118		// подача воды
#define		SERVICE_PG				119		// подача горючего
#define		SERVICE_PR				120		// проток
#define		SERVICE_MAX				120

#define		STOP_STATE				0	// dejurny, after Initialize
#define		GO_WAIT_STATE			1
#define		WAIT_STATE_TIMEOUT		2
#define		WAIT_STATE				3	//
#define     GO_IGNITION_STATE		4
#define		IGNITION_STATE			5
#define		GO_STABLE_STATE			6
#define		STABLE_STATE			7
#define		GO_WORK_STATE			8	//
#define		WORK_STATE				9
#define		WARMDOWN_STATE			11
#define		GO_AVARY_STATE			12
#define		AVARY_STATE				13
#define		CLEAR_STATE				14
#define		GO_STOP_STATE			15	//
//#define		UNDEF_STATE				16	//
//#define		SERVICE_STATE			20	// service state

#define		CLEAR_WAIT				0
#define		BEGIN_CLEAR				1
#define		END_CLEAR				10

#define		WARMDOWN_WAIT			0
#define		BEGIN_WARMDOWN			1
#define		END_WARMDOWN			10

#define		IGNITION_WAIT			0
#define		BEGIN_IGNITION			1
#define		IGNITION_CYCLE_ONE		3
#define		IGNITION_CYCLE_TWO		8
#define		MANUAL_IGNITION			15
#define		END_IGNITION			20
#define		FAIL_IGNITION			25

#define		KOLOSNIK_WAIT			0
#define		KOLOSNIK_RUN			1
#define		KOLOSNIK_STOP			10

#define		PODACHA_WAIT			0
#define		PODACHA_RUN				1
#define		PODACHA_STOP			10

#define		ZOLODEL_WAIT			0
#define		ZOLODEL_RUN				1
#define		ZOLODEL_STOP			10

#define		RR_BIT_REMOTE			0  // bits of rr register
#define		RR_BIT_AUTONOM			1
#define		RR_BIT_CLEAR			2
#define		RR_ALL_PARAM_MASK		0x0007  //

#define		RC_BIT_CLR_AVARY		0  // bits of rc register
#define		RC_BIT_START_STOP		1
#define		RC_BIT_AUTO_IGNITION	2
#define		RC_BIT_ON_KOLOSNIK		3
#define		RC_BIT_PCONST_0			4
#define		RC_BIT_IGNITION_TOPKA	5	// 1-topka DT4, 0-dymohod DT5
#define		RC_BIT_POS_KILISNIK		6	// 1-one, 0-two
#define		RC_BIT_PCONST_1			7
#define		RC_BIT_ZOLO_DEL			8	// flag zolo delete

#define		SRK_BIT_STOP			0	// bits of srk register
#define		SRK_BIT_WAIT			1
#define		SRK_BIT_IGNITION		2
#define		SRK_BIT_STABLE			3
#define		SRK_BIT_WORK			4
#define		SRK_BIT_WARMDOWN		5
#define		SRK_BIT_AVARY			6
#define		SRK_BIT_CLEAR			7
#define		SRK_BIT_SERVICE			8
#define		SRK_BITS_WORK			2	// 2 and greather - is work

#define		DC_INIT					0
//#define		SRK_INIT				0x0001
#define		SRK_DEJURNY				0x0002
#define		SRK_WORK				0x0004
#define		SRK_SERVICE				0x0008
#define		SRK_ALARM				0x0010
#define		SRK_CONFIG				0x0020

#define		WRN_BIT_OPEN_DT2		0
#define		WRN_BIT_SHORT_DT2		1
#define		WRN_BIT_OPEN_DT3		2
#define		WRN_BIT_SHORT_DT3		3
#define		WRN_BIT_PODACHA			4
#define		WRN_BIT_SHNECK			5
#define		WRN_BIT_FROZE			6
#define		WRN_BIT_OVERLOAD		7
#define		WRN_BIT_HOT_DOWN		8
#define		WRN_BIT_LINK			9

#define		ALR_BIT_PODACHA			0
#define		ALR_BIT_SHNECK			1
#define		ALR_BIT_PROTOK			2
#define		ALR_BIT_SENSOR_PODACHA	3
#define		ALR_BIT_SENSOR_PODACHA2	4
#define		ALR_BIT_SENSOR_SHNECK	5
#define		ALR_BIT_SENSOR_SHNECK2	6
#define		ALR_BIT_IGNITION		7
#define		ALR_BIT_NO_PROTOK		8
#define		ALR_BIT_OPEN_HOT		9
#define		ALR_BIT_SHORT_HOT		10
#define		ALR_DT1_MASK			0x0608

#define		BA_AVARY_MASK_SCS_0		0x0CFF		// bit 0...7,10,11 select
#define		BA_AVARY_MASK_SCS_1		0x00FF		// bit 0...7 select

#define		PV_INPUT_BIT			1
#define		PG_INPUT_BIT			2
#define		PR_INPUT_BIT			3

#define  	DIO_SHNEK3				0
#define  	DIO_SHNEK1				1
#define  	DIO_SHNEK2				2
#define  	DIO_HEATER				3
#define  	DIO_PUMP				4
#define  	DIO_FAN					5		// DIO

#define		PV_DIO_BIT				6
#define		PG_DIO_BIT				7
#define		PR_DIO_BIT				8

typedef struct
{
	uint8_t  State;			// current state
	uint8_t  clrState;		// clear state
	uint8_t  Regim;			// create from RC[4],RC[7]
	uint8_t  ignitionState;
	uint8_t  warmDownState;
	uint8_t  kolosnikCntr;
	uint16_t kolosnikOnTime;
	uint16_t kolosnikOffTime;
	uint8_t  podachaCntr;
	uint16_t podachaOnTime;
	uint16_t podachaOffTime;
	uint16_t N1_cnt;
	uint16_t N5_cnt;
	uint8_t  zolodelCntr;
	uint16_t zolodelTime;
	uint16_t timeCounter;
	uint16_t t1_cnt;
	uint16_t t2_cnt;
	uint32_t sifu;
	uint8_t  sifuCnt;
	uint8_t  keyIgnition;
	uint16_t t15_cnt;
	uint16_t dlyWarmDown;
	uint16_t t18_cnt;
	uint8_t  cycleKolosnik;
	uint16_t periodPI;
	uint16_t kolosnikOnPI;
	uint16_t kolosnikOffPI;
	uint16_t podachaOnPI;
	uint16_t podachaOffPI;
	int16_t  mismatchPI[MISMATCH_PI_ARR_LEN]; // unit array for PI regulation
	uint8_t  mismatchCnt;
} unit_t;

unit_t Unit;

typedef struct
{
	uint8_t   RunMenu;			// automatic menu pointer
//	uint8_t   SubRunMenu;		//
	uint8_t   ServiceMenu;		// service menu pointer
	uint16_t  Param;
	uint8_t   CurrMenu;			// 0-no menu, 1,2-service menu, 3,4-run menu, 0x80-input to service menu
} main_menu_t;

main_menu_t		Menu;

typedef struct
{
	uint8_t  state;			// pin current state
	uint16_t delay;			// delay counter
	uint8_t	 type;			// input type, read from registers
} input_t;

input_t		DT1A;      // _PV podacha vody
input_t		DT3A;      // _PG
input_t		DDP1;      // _PR

typedef struct 				// memory RAM in microcontroller
{	// PARAMS_LEN+PRESET_LEN+DEBUG_LEN = 90 + 38 + 16 = 144
	uint16_t  alr;						// 1, alarms, 0-1 eeprom
	uint16_t  alrMemory;				// 2, 2-3 eeprom
	uint16_t  wrn;						// 3, 4-5 warnings
	uint16_t  srk;						// 4, 6-7 state BA103
	uint16_t  rr;						// 5,
	uint16_t  rc;						// 6,
	uint16_t  t15;						// 7,
	uint16_t  Q1;						// 8,
	uint16_t  t1;						// 9
	uint16_t  t2;						// 10,
	uint16_t  t3;						// 11,
	uint16_t  t4;						// 12,
	uint16_t  t5;						// 13,
	uint16_t  t6;						// 14,
	uint16_t  T4;						// 15,
	uint16_t  Q4;						// 16,
	uint16_t  T5;						// 17,
	uint16_t  t10;						// 18,
	uint16_t  t12;						// 19,
	uint16_t  t13;						// 20,
	uint16_t  t14;						// 21,
	uint16_t  t16;						// 22,
	uint16_t  t17;						// 23,
	uint16_t  T6;						// 24,
	uint16_t  N2;						// 25,
	uint16_t  delta_T1;					// 26,
	uint16_t  delta_T4;					// 27,
	uint16_t  t25;						// 28,
	uint16_t  T13;						// 29,
	uint16_t  T14;						// 30,
	uint16_t  addr;						// 31,
	uint16_t  t26;						// 32,
	uint16_t  T10;						// 33,
	uint16_t  T7;						// 34,
	uint16_t  T11;						// 35,
	uint16_t  T12;						// 36,
	uint16_t  T9;						// 37,
	uint16_t  T8;						// 38,
	uint16_t  preset;					// 39,
	uint16_t  t18;						// 40,
	uint16_t  T19;						// 41,
	uint16_t  delta_T19;				// 42,
	uint16_t  N3;						// 43,
	uint16_t  N4;						// 44,
	uint16_t  N5;						// 45, PARAMS_LEN - 90 bytes
///////////// presets ////////////////////
	uint16_t  t7;					// 46 -> 1
	uint16_t  t8;					// 47 -> 2
	uint16_t  t22;					// 48 -> 3,
	uint16_t  t23;					// 49 -> 4,
	uint16_t  T1;					// 50 -> 5,
	uint16_t  T21;					// 51 -> 6,
	uint16_t  t9;					// 52 -> 7,
	uint16_t  t20;					// 53 -> 8,
	uint16_t  t21;					// 54 -> 9,
	uint16_t  t11;					// 55 -> 10,
	uint16_t  Q2;					// 56 -> 11,
	uint16_t  Q3;					// 57 -> 12
	uint16_t  N1;					// 58 -> 13
	uint16_t  Kp;					// 59 -> 14
	uint16_t  Ki;					// 60 -> 15
	uint16_t  t24;					// 61 -> 16
	uint16_t  delta_T3;				// 62 -> 17
	uint16_t  Q7;					// 63 -> 18
	uint16_t  Q8;					// 64 -> 19, PRESET_LEN - 38 bytes
//////////////////////////////////////////
	uint16_t  state;				// 65,
	uint16_t  version;				// 66,
	uint16_t  log_debug_state;		/// debug
	uint16_t  flagAvary;			// 68
	uint16_t  null;					// 69, DEBUG_LEN - 10 bytes
} Registers_var;

union CLOCKRAM
{
	Registers_var		config;
	uint8_t				data8[PARAMS_LEN+PRESET_LEN+DEBUG_LEN];
} ClockRAM;

typedef struct
{
	uint16_t  t7;					//
	uint16_t  t8;					//
	uint16_t  t22;					//
	uint16_t  t23;					//
	uint16_t  T1;					//
	uint16_t  T21;					//
	uint16_t  t9;					//
	uint16_t  t20;					//
	uint16_t  t21;					//
	uint16_t  t11;					//
	uint16_t  Q2;					//
	uint16_t  Q3;					//
	uint16_t  N1;					//
	uint16_t  Kp;					//
	uint16_t  Ki;					//
	uint16_t  t24;					//
	uint16_t  delta_T3;				//
	uint16_t  Q7;					//
	uint16_t  Q8;					//
} preset_t;

preset_t PR0;
preset_t PR1;
preset_t PR2;
preset_t PR3;
preset_t PR4;

char 	 buff[16];
uint16_t ustPodachi;
uint16_t cntDisplayAvary;
uint8_t  indPoints;			// 0-no point, 1-display points
uint16_t T1;
uint16_t T2;
uint16_t T3;
uint16_t T4;
uint16_t T5;
uint16_t Q0;
uint16_t ALR;				// ALR = ClockRAM.config.alr | ClockRAM.config.alrMemory;
uint16_t DIO;				// input/output state, i/o bits,  0-7bits DA1x sensors,
uint16_t tempDIO;			// 0-1bits DT11 sensors
uint16_t alarmState_old;
uint16_t alarm_old;			//
uint16_t warning_old;
uint16_t dc_old;
char strDisp[8];
uint8_t  ledRegim;
uint8_t  ledState;
uint8_t  ledFlash;
float    tmpSifu;

uint8_t  bu_state_old;		/// debug
uint16_t di_old;			/// debug
uint16_t ustPodachi_old;	/// debug
uint8_t  log_debug;			/// debug
uint32_t sifuOld;			/// debug

void InitAutomat(void);
void SetState(void);
void InitState(void);
void ReadEEtoRegisters(void);
void RefreshEEpromData(void);
void RefreshEEpromPreset(uint16_t addr);
void RefreshEEpromDebug(uint16_t addr);
void CheckReadData(void);
void LoadSettings(void);
void SaveSettings(void);
void SetConfigDefault(void);
void RunMenu(void);
char* ToDisplay(int16_t);
void IndexingRegisters(void);
void InitInputs(void);
void TestInputs(void);
void InitD(input_t*);
void TestD(input_t*, uint16_t, uint16_t, uint16_t);
void SetAvary(void);
void Warnings(void);
void WarningWarmDown(void);
void Avary1DT1A(void);  // 1, APV
void Avary2DT3A(void);  // 2, APG
void Avary3DP1(void);   // 3, NPR
void Avary4DT1(void);   // 4, NtP
void Avary5DT1A(void);  // 5, NPV
void Avary6DT3(void);   // 6, NtG
void Avary7DT3A(void);  // 7, NPG
void Avary8(void); 		// 8, AP3
void Avary9DP1(void); 	// 9, AПР
void Avary10DT1(void);  // 10, OtP
void Avary11DT1(void);  // 11, 3tP
void DisplayAvary(uint16_t);
void DispRunMenu(void);
uint16_t GetCntDisplayAvary(uint16_t, uint8_t);
void WaitingMode(void);
uint8_t BitCalc(uint16_t);
void Ignition(void);
void WarmDown(void);
void Podacha(void);
void Kolosnik(void);
void ZoloDel(void);
void Clearing(void);
void PIpower(void);     // PI regulation function
void ClearMismatch(void);
void CalculatePI(void); // calculate times for kolosniki & zolodel from sifuPersent
void UnitOff(uint8_t vn, uint8_t osh);
void SetSRK(uint8_t bit);
void SetRR(uint8_t bit);
void InitUnit(void);

#endif /* INC_AUTOMAT_H_ */
