/*
 * bu_103_bus.h
 *
 *  Created on: 21 янв. 2023 г.
 *      Author: vitaly
 */

#ifndef INC_BU_103_BUS_H_
#define INC_BU_103_BUS_H_

/// Variables
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart3;

/* Private defines -----------------------------------------------------------*/
#define _BUS_OUTPUT_UART			// debug output to UART1

#define			BA103_ADDR				1
#define			BA103_MAX_ADDR			10
#define			BA103_MIN_ADDR			1
#define 		TIMEOUT_I2C				50

#define			MODBUS_OK							0
#define			MODBUS_FUNCTION_NOT_SUPPORT			1
#define			MODBUS_ADDRESS_REGISTERS_ERROR		2
#define			MODBUS_LENGTH_REGISTERS_ERROR		3
#define			MODBUS_READ_WRITE_FAIL				4
//#define			MODBUS_CHECK_SUM_ERROR				5

#define		NO_ERRORS						0
#define		ERROR_REGISTER_NUMBER			1		// modBus standart value
#define		ERROR_BUS_SET_DATA				2		// modBus standart value
#define		ERROR_INCORRECT_WRITING			3		// modBus standart value
#define		ERROR_ADDRESS					0x80	// custom value

#define			MESSAGE_OFF				0
#define			MESSAGE_BUS				1

#define			MEM_ADDR				0xA0		// 24C256
#define			MAX_ADDR				0x7FF0		// 24C256
#define			START_ADDR				0x0000					// 0x000...0x080 - registers, max 64 words
#define			DEBUG_LEN				10			// 10 -> 5 word, debug lenght in bytes
#define			PARAMS_LEN				90			// 90 -> 45 word, params lenght in bytes
#define			PRESET_LEN				38			// 38 -> 19 word, preset lenght in bytes
#define			PR0_ADDR				START_ADDR + PARAMS_LEN		// preset 0, 90...127
#define			PR1_ADDR				PR0_ADDR + PRESET_LEN		// preset 1, 128...165
#define			PR2_ADDR				PR1_ADDR + PRESET_LEN		// preset 2, 166...203
#define			PR3_ADDR				PR2_ADDR + PRESET_LEN		// preset 3, 204...241
#define			PR4_ADDR				PR3_ADDR + PRESET_LEN		// preset 4, 242...279
#define			DEBUG_EE_ADDR			PR4_ADDR + PRESET_LEN		// debug,    280...287

#define			READ_HOLD_REG				0x03
#define			READ_IN_REG					0x04
#define			WRITE_ONE_COIL				0x05
#define			WRITE_ONE_REG				0x06
#define			LOOP_TEST					0x08
#define			WRITE_MULTI_REG				0x10
#define			REPORT_ID					0x11
#define			READ_WRITE					0x17
#define			TEST_CMD_0					0xA0	//
#define			TEST_CMD_1					0xA2	// clear memory units
#define			TEST_CMD_2					0xA4	// status
#define			TEST_CMD_3					0xA6	//
#define			TEST_CMD_4					0xA8	// off all units
#define			TEST_CMD_5					0xAA	// debug message on/off
#define			TEST_CMD_6					0xAC	// read param unit
#define			TEST_CMD_7					0xAE	// client GET to server

#define 	UART_INPUT_LEN					200		// max 27 registers to write (9 bytes cmd)
#define 	UART_OUTPUT_LEN					200		// 75 words -> 150 bytes, uint8_t
#define 	SMBUS_BUFFER_LEN				32		// only for send cmd to BA103, uint16_t
#define 	UART_TIMEOUT					500		// in mS
#define		TEST_LINE_TIMEOUT				5		// 20 * n(ba103-x) sec.
#define		I2C_CONFIG_LEN_BYTES			64
#define		WAITPERIOD1						10		// 2 for 115200
#define		WAITPERIOD3						10		// 10 for 9600

#define 	BA_REGISTERS			72		// counter BA103 registers

typedef struct
{
	uint16_t cntBytes;
	uint16_t cntReceive;
	uint16_t waitTimer;
	uint16_t cntTimeOut;
	uint16_t startReg;						// for cmd, start data registers index
	uint16_t lenReg;						// for cmd, data lengh
	uint16_t cntTestLine;					// counter time errors
	uint8_t	 tstLine;						// testing line avary control
	uint8_t  input_buff[UART_INPUT_LEN];
	uint8_t  output_buff[UART_OUTPUT_LEN];
	uint8_t  num;							// number uart port
	char dataReady;
	char dataOver;
	char ok;
} config_uart_t;

uint8_t  AddressBA103;
uint16_t smBus_buff[SMBUS_BUFFER_LEN];

uint8_t input_bf[UART_INPUT_LEN];			/// debug
uint8_t len_bf;								/// debug
uint16_t cnt;								/// debug

uint8_t beginInputFlag;
uint8_t buff_i2c[I2C_CONFIG_LEN_BYTES];

config_uart_t UART_1;
config_uart_t UART_3;

uint16_t *ptr_reg[BA_REGISTERS];

void InitializeBus(void);
void Setup_UARTs(void);
void TimeOutReceive_10ms(void);
void ReadUART1(void);
void ReadUART3(void);
void UARTsend(config_uart_t*,uint16_t);
void ClearUartBuff(config_uart_t*);
void ParseInputSlave(config_uart_t*);			// host to BA
void GetReportId(config_uart_t*);
uint8_t WriteRegister(uint16_t, uint16_t);
uint16_t CalculateCRC16(uint8_t*, uint16_t);
void SendCMDtoBA(uint8_t, uint8_t, uint16_t, uint16_t);
uint8_t CheckAddress(uint8_t, uint16_t, uint16_t);

#endif /* INC_BU_103_BUS_H_ */
