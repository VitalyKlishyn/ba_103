/*
 * drivers.c
 * buttons input, LED output, data serial input (597), data serial output (595)
 *  Created on: 6 дек. 2022 г.
 *      Author: vitaly
 */

#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "adc_stm32.h"
#include "drivers.h"
#include "ba_103_bus.h"
#include "automat.h"
#include "at25df.h"

extern I2C_HandleTypeDef	hi2c1;

void InitDrivers(void)
{
	secLogCnt = 0;
	event_1sec_drv = 0;
	event_1mS_drv = 0;
	trueValue = 0;		// for ADC meassure

	relayData = 0;
	countADC = 1;

	OE_LED_UNSET();
	OE_OUT_UNSET();
	OE_IN_LOAD();
	SDLED_CLR();
	SDOUT_CLR();
	SCLOCK();
	SLATCH();

	ledDisplay.LedRegim = REGIM_OFF;
	ledDisplay.LedState = STATE_OFF;
	ledDisplay.Flashing = 0;
	ledDisplay.pulseCnt = 0;
	ledDisplay.stateInd = 1;

	adcInit();
	InitEEPROM();
	InitAutomat();			// 1-ste! read memory to ram
	InitializeBus();
}

void Drivers(void)
{ // 1 mSec running
//	LEDs();		//indication in stm32f0xx_it.c
	ReadKeys();
	BeepRun();
	Meassure(); 		// adc conversion
	OutputToRegister(); // control outputs
	if(Tick10ms > 9)
	{ 	// 10 mSec.
		Tick10ms = 0;
		CompareEEpromRAM();		// write params RAM memory to EEprom
		CompareEEpresetRAM();	// write current preset RAM memory to EEprom
		CompareEEdebugRAM();	// write debug RAM memory to EEprom
		if(Menu.CurrMenu < CURR_SERVICE)
		{
			TimeOutReceive_10ms();		// reading UARTs
		}
	}
	if(Tick50ms > 49)
	{ 	// 50 mSec.
		Tick50ms = 0;
		if(Menu.CurrMenu >= CURR_SERVICE)
		{ // service
			TestVentilator();		//
		}
	}
	if(Tick250ms > 249)
	{ 	// 250 mSec.
		Tick250ms = 0;
		RunMenu();
		Display(strDisp, ledRegim, ledState, ledFlash);
	}
	Tick10ms++;
	Tick50ms++;
	Tick250ms++;
}

void Working(void)
{ // 1 second running
	Delays();
	if((Menu.CurrMenu < CURR_SERVICE) && (trueValue > TRUE_VALUE_DELAY))
	{
		TestInputs();
		SetState();
		Nasos();
		CoolShneck();
		Ignition();
		WarmDown();
		Podacha();
		Kolosnik();
		ZoloDel();
		Clearing();
		SetAvary();
	}
}

void Nasos(void)
{
	switch(Unit.State)
	{
	case STOP_STATE: // dejurny state
		if((ClockRAM.config.flagAvary & ALR_DT1_MASK) || (ClockRAM.config.alr & ALR_DT1_MASK) || (ClockRAM.config.alrMemory & ALR_DT1_MASK))
		{
			Relays(RELAY_PUMP, 0);
		}
		else
		{
			if(BIT_TEST(ClockRAM.config.wrn, WRN_BIT_FROZE == 0) && (T_hot < ClockRAM.config.T6))
			{
				Relays(RELAY_PUMP, 0);
			}
			if((T_hot >= ClockRAM.config.T6) || BIT_TEST(ClockRAM.config.alr, ALR_BIT_PODACHA) || BIT_TEST(ClockRAM.config.wrn, WRN_BIT_FROZE))
			{
				Relays(RELAY_PUMP, 1);
			}
			if(BIT_TEST(ClockRAM.config.wrn, WRN_BIT_SHNECK) || BIT_TEST(ClockRAM.config.alr, ALR_BIT_SHNECK))
			{
				Shneck.state = SHNECK_COOL;
			}
		}
		break;

	case WAIT_STATE:
	case IGNITION_STATE:
		if((ClockRAM.config.flagAvary & ALR_DT1_MASK) || (ClockRAM.config.alr & ALR_DT1_MASK) || (ClockRAM.config.alrMemory & ALR_DT1_MASK))
		{
			Relays(RELAY_PUMP, 0);
		}
		else
		{
			if(BIT_TEST(ClockRAM.config.wrn, WRN_BIT_FROZE == 0) && (T_hot < ClockRAM.config.T5))
			{
				Relays(RELAY_PUMP, 0);
			}
			if((T_hot >= ClockRAM.config.T5) || BIT_TEST(ClockRAM.config.wrn, WRN_BIT_PODACHA) || BIT_TEST(ClockRAM.config.wrn, WRN_BIT_FROZE))
			{
				Relays(RELAY_PUMP, 1);
			}
			if(BIT_TEST(ClockRAM.config.wrn, WRN_BIT_SHNECK))
			{
				Shneck.state = SHNECK_COOL;
			}
		}
		break;

	case WORK_STATE:
	case STABLE_STATE:
		if((ClockRAM.config.flagAvary & ALR_DT1_MASK) || (ClockRAM.config.alr & ALR_DT1_MASK) || (ClockRAM.config.alrMemory & ALR_DT1_MASK))
		{
			Relays(RELAY_PUMP, 0);
		}
		else
		{
			if(T_hot < ClockRAM.config.T5)
			{
				Relays(RELAY_PUMP, 0);
			}
			if((T_hot >= ClockRAM.config.T5) || BIT_TEST(ClockRAM.config.wrn, WRN_BIT_FROZE))
			{
				Relays(RELAY_PUMP, 1);
			}
			if(BIT_TEST(ClockRAM.config.wrn, WRN_BIT_SHNECK))
			{
				Shneck.state = SHNECK_COOL;
			}
		}
		break;

	case CLEAR_STATE:
		if(T_hot >= ClockRAM.config.T5)		Relays(RELAY_PUMP, 1);
		else								Relays(RELAY_PUMP, 0);
		break;

	case AVARY_STATE:
		if((ClockRAM.config.flagAvary & ALR_DT1_MASK) || (ClockRAM.config.alr & ALR_DT1_MASK) || (ClockRAM.config.alrMemory & ALR_DT1_MASK))
		{
			Relays(RELAY_PUMP, 0);
		}
		else
		{
			if(BIT_TEST(ClockRAM.config.wrn, WRN_BIT_FROZE == 0) && (T_hot < ClockRAM.config.T5))
			{
				Relays(RELAY_PUMP, 0);
			}
			if((T_hot >= ClockRAM.config.T5) || BIT_TEST(ClockRAM.config.wrn, WRN_BIT_FROZE))
			{
				Relays(RELAY_PUMP, 1);
			}
		}
		break;

	case WARMDOWN_STATE:
		if(Unit.dlyWarmDown)		Unit.dlyWarmDown--;
		if((ClockRAM.config.flagAvary & ALR_DT1_MASK) || (ClockRAM.config.alr & ALR_DT1_MASK) || (ClockRAM.config.alrMemory & ALR_DT1_MASK))
		{
			Relays(RELAY_PUMP, 1);
		}
		else
		{
			if((T_hot >= ClockRAM.config.T5) && (Unit.dlyWarmDown == 0) && ((ClockRAM.config.flagAvary & ALR_DT1_MASK) == 0))
			{
				Relays(RELAY_PUMP, 1);
				Unit.dlyWarmDown = ClockRAM.config.t12+1;
			}
			if(Unit.dlyWarmDown == 1)
			{
				Unit.dlyWarmDown = 0;
				if(T_hot < ClockRAM.config.T6)		Relays(RELAY_PUMP, 0);
			}
			if(BIT_TEST(ClockRAM.config.wrn, WRN_BIT_FROZE) || BIT_TEST(ClockRAM.config.wrn, WRN_BIT_PODACHA))		Relays(RELAY_PUMP, 1);
		}
		break;

	default:
		break;
	}
}

void CoolShneck(void)
{
	if(Shneck.delayCnt)		Shneck.delayCnt--;
	switch(Shneck.state)
	{ // for start -> Shneck.state = SHNECK_COOL;
	case SHNECK_COOL:  // 1
		Relays(RELAY_SHNEK2, 0);  // dop. podacha off
		Shneck.cycleCnt = ClockRAM.config.N4;
		Shneck.state++;
		break;

	case 2:
		Relays(RELAY_SHNEK1, 1);  // podacha on
		Shneck.delayCnt = ClockRAM.config.t13;
		Shneck.state++;
		break;

	case 3:
		if(Shneck.delayCnt == 0)
		{
			Relays(RELAY_SHNEK1, 0);  // podacha off
			Shneck.delayCnt = ClockRAM.config.t14;
			Shneck.state++;
		}
		break;

	case 4:
		if(Shneck.delayCnt == 0)
		{
			if(Shneck.cycleCnt)		Shneck.cycleCnt--;
			if(Shneck.cycleCnt)		Shneck.state = 2;
			else					Shneck.state = SHNECK_WAIT;
		}
		break;

	case SHNECK_WAIT:
	default:
		break;
	}
}

void Delays(void)
{
	if(UART_1.cntTestLine)	UART_1.cntTestLine--;
	if(UART_3.cntTestLine)	UART_3.cntTestLine--;
	if((Menu.CurrMenu == CURR_SERVICE) || (Menu.CurrMenu == SUB_MENU_SERVICE))
	{
		if(timeoutService)		timeoutService--;
		if(timeoutService == 1)
		{ /// off timeout for debug
			OffAllRelays();
			timeoutService = 0;
			Menu.CurrMenu = CURR_AUTH;
			Beep(BEEP_PULSE_2);
		}
	}
	if((Menu.CurrMenu == RUN_MENU) || (Menu.CurrMenu == SUB_RUN_MENU))
	{
		if(timeoutAutomat)		timeoutAutomat--;
		if(timeoutAutomat == 1)
		{ /// off timeout for debug
			if(Menu.RunMenu != RUN_MENU_MIN)
			{
				Menu.CurrMenu = RUN_MENU;
				Beep(BEEP_PULSE_2);
			}
			if(Menu.CurrMenu == RUN_MENU)		Menu.RunMenu = RUN_MENU_MIN;
		}
	}
	if(DT1A.delay)					DT1A.delay--;
	if(DT3A.delay)					DT3A.delay--;
	if(DDP1.delay)					DDP1.delay--;
	if(Unit.timeCounter > 1)		Unit.timeCounter--;
	if(Unit.t15_cnt)				Unit.t15_cnt--;
}

void Display(char *buff, uint8_t regim, uint8_t state, uint8_t flash)
{
	ledDisplay.LedRegim = regim;
	ledDisplay.LedState = state;
	ledDisplay.Flashing = flash;

	ledDisplay.Digit1 = Decode(buff[0]);
	if((indPoints) && (Menu.CurrMenu == AVARY_MENU))		ledDisplay.Digit1 |= DIGIT_POINT;
	ledDisplay.Digit2 = Decode(buff[1]);
//	if(Menu.ServiceMenu == SERVICE_UIN && Menu.CurrMenu == SUB_MENU_SERVICE)	ledDisplay.Digit2 |= DIGIT_POINT;
	if((indPoints) && (Menu.CurrMenu == AVARY_MENU))		ledDisplay.Digit2 |= DIGIT_POINT;
	ledDisplay.Digit3 = Decode(buff[2]);
	if((indPoints) && (Menu.CurrMenu == AVARY_MENU))		ledDisplay.Digit3 |= DIGIT_POINT;
	if((Menu.CurrMenu == SUB_RUN_MENU) && (Menu.RunMenu == RUN_SET_UST))	ledDisplay.Digit1 = Decode('t');
	if((Menu.CurrMenu == RUN_MENU) && (Menu.RunMenu == RUN_SET_UST))		ledDisplay.Digit1 = Decode('t');
	if((Menu.CurrMenu == SUB_RUN_MENU) && (Menu.RunMenu == RUN_SET_ADDR))	ledDisplay.Digit1 = Decode('A');
	if((Menu.CurrMenu == RUN_MENU) && (Menu.RunMenu == RUN_SET_ADDR))		ledDisplay.Digit1 = Decode('A');
	if((Menu.CurrMenu == SUB_MENU_SERVICE) && (Menu.ServiceMenu == SERVICE_TVYH) && (T_vyh >= 1000))
	{
		ledDisplay.Digit1 |= DIGIT_POINT;
		ledDisplay.Digit2 |= DIGIT_POINT;
		ledDisplay.Digit3 |= DIGIT_POINT;
	}
	if((Menu.CurrMenu == SUB_MENU_SERVICE) && (Menu.ServiceMenu == SERVICE_TSG) && (T_sg >= 1000))
	{
		ledDisplay.Digit1 |= DIGIT_POINT;
		ledDisplay.Digit2 |= DIGIT_POINT;
		ledDisplay.Digit3 |= DIGIT_POINT;
	}
}

void Relays(uint8_t chan, uint8_t state)
{
	switch(chan)
	{
	case 0:
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
		if(state)	BIT_SET(relayData, chan);
		else		BIT_CLR(relayData, chan);
		break;

	case 8:
		if(state)	HAL_GPIO_WritePin(LOCK_GPIO_Port, LOCK_Pin, GPIO_PIN_SET);   // lock pin on
		else		HAL_GPIO_WritePin(LOCK_GPIO_Port, LOCK_Pin, GPIO_PIN_RESET); // lock pin off
		break;

	default:
		break;
	}
}

void LEDs(void)
{ // flasing bit0,1,2-display, bit4-state, bit5-regim
	if(ledDisplay.pulseCnt)		ledDisplay.pulseCnt--;
	else
	{ // 3 mSec.
		ledDisplay.pulseCnt = IND_PULSE_LEN;
		if(ledDisplay.periodFlash)			ledDisplay.periodFlash--;
		else
		{ // 3 x 100 mSec
			ledDisplay.periodFlash = FLASH_PERIOD;
			ledDisplay.flagFlash++;
		}
		switch(ledDisplay.stateInd)
		{
			case 1:
			if((ledDisplay.flagFlash & 0x01) && ((ledDisplay.Flashing & FLASH_DIGIT) == FLASH_DIGIT))
			{
				inputData = LoadData(0, relayData);
			}
			else
			{
				inputData = LoadData(ledDisplay.Digit1, relayData);
			}
			HAL_GPIO_WritePin(DIG5_GPIO_Port, DIG5_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG1_GPIO_Port, DIG1_Pin, DIGIT_SET);
			break;

			case 2:
			if((ledDisplay.flagFlash & 0x01) && ((ledDisplay.Flashing & FLASH_DIGIT) == FLASH_DIGIT))
			{
				inputData = LoadData(0, relayData);
			}
			else
			{
				inputData = LoadData(ledDisplay.Digit2, relayData);
			}
			HAL_GPIO_WritePin(DIG1_GPIO_Port, DIG1_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG2_GPIO_Port, DIG2_Pin, DIGIT_SET);
			break;

			case 3:
			if((ledDisplay.flagFlash & 0x01) && ((ledDisplay.Flashing & FLASH_DIGIT) == FLASH_DIGIT))
			{
				inputData = LoadData(0, relayData);
			}
			else
			{
				inputData = LoadData(ledDisplay.Digit3, relayData);
			}
			HAL_GPIO_WritePin(DIG2_GPIO_Port, DIG2_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG3_GPIO_Port, DIG3_Pin, DIGIT_SET);
			break;

			case 4:
			if((ledDisplay.Flashing & FLASH_STATE) == FLASH_STATE)
			{
				ledDisplay.cntStFlash++;
				if(ledDisplay.cntStFlash > FLASH_PERIOD_LEN)		ledDisplay.cntStFlash = 0;
				switch(ledDisplay.Flashing)
				{
				case FLASH_STATE_1: // pulse 1, 1 short
					if(ledDisplay.cntStFlash == 0)					ledDisplay.datSt = 1;
					if(ledDisplay.cntStFlash == FLASH_PULSE_1)		ledDisplay.datSt = 0;
					break;

				case FLASH_STATE_2: // pulse 2, 3 short
					if(ledDisplay.cntStFlash == 0)					ledDisplay.datSt = 1;
					if(ledDisplay.cntStFlash == FLASH_PULSE_1)		ledDisplay.datSt = 0;
					if(ledDisplay.cntStFlash == FLASH_PAUSE_1)		ledDisplay.datSt = 1;
					if(ledDisplay.cntStFlash == FLASH_PULSE_2)		ledDisplay.datSt = 0;
					if(ledDisplay.cntStFlash == FLASH_PAUSE_2)		ledDisplay.datSt = 1;
					if(ledDisplay.cntStFlash == FLASH_PULSE_3)		ledDisplay.datSt = 0;
					break;

				case FLASH_STATE_4: // pulse 4, inv. 3 short
					if(ledDisplay.cntStFlash == 0)					ledDisplay.datSt = 0;
					if(ledDisplay.cntStFlash == FLASH_PULSE_1)		ledDisplay.datSt = 1;
					if(ledDisplay.cntStFlash == FLASH_PAUSE_1)		ledDisplay.datSt = 0;
					if(ledDisplay.cntStFlash == FLASH_PULSE_2)		ledDisplay.datSt = 1;
					if(ledDisplay.cntStFlash == FLASH_PAUSE_2)		ledDisplay.datSt = 0;
					if(ledDisplay.cntStFlash == FLASH_PULSE_3)		ledDisplay.datSt = 1;
					break;

				default:
				case FLASH_STATE_3: // meandr, pulse 3
					if(ledDisplay.flagFlash & 0x01)		ledDisplay.datSt = 1;
					else								ledDisplay.datSt = 0;
					break;
				}
				if(ledDisplay.datSt)							inputData = LoadData(ledDisplay.LedState, relayData);
				else											inputData = LoadData(0, relayData);
			}
			else if((ledDisplay.Flashing & FLASH_STATE_RG) == FLASH_STATE_RG)
			{
				if(ledDisplay.flagFlash & 0x01)		inputData = LoadData(STATE_RED, relayData);
				else								inputData = LoadData(STATE_GREEN, relayData);
			}
			else									inputData = LoadData(ledDisplay.LedState, relayData);
			HAL_GPIO_WritePin(DIG3_GPIO_Port, DIG3_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG4_GPIO_Port, DIG4_Pin, DIGIT_SET);
			break;

			case 5:
			if((ledDisplay.Flashing & FLASH_REGIM) == FLASH_REGIM)
			{
				if(ledDisplay.flagFlash & 0x01) 	inputData = LoadData(0, relayData);
				else								inputData = LoadData(ledDisplay.LedRegim, relayData);
			}
			else if((ledDisplay.Flashing & FLASH_REGIM_RG) == FLASH_REGIM_RG)
			{
				if(ledDisplay.flagFlash & 0x01) 	inputData = LoadData(REGIM_RED, relayData);
				else								inputData = LoadData(REGIM_GREEN, relayData);
			}
			else									inputData = LoadData(ledDisplay.LedRegim, relayData);
			HAL_GPIO_WritePin(DIG4_GPIO_Port, DIG4_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG5_GPIO_Port, DIG5_Pin, DIGIT_SET);
			break;

			default:
			HAL_GPIO_WritePin(DIG5_GPIO_Port, DIG5_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG1_GPIO_Port, DIG1_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG2_GPIO_Port, DIG2_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG3_GPIO_Port, DIG3_Pin, DIGIT_CLR);
			HAL_GPIO_WritePin(DIG4_GPIO_Port, DIG4_Pin, DIGIT_CLR);

			break;
		}
		if(ledDisplay.stateInd)				ledDisplay.stateInd++;
		if(ledDisplay.stateInd > IND_DIGIT)	ledDisplay.stateInd = 1;

	}
}

uint8_t LoadData(uint8_t led, uint8_t rel)
{
	uint8_t ci, rez;

	rez = 0;
	OE_IN_LOAD();
	OE_LED_UNSET();
	OE_OUT_UNSET();
	for(ci=0; ci<8; ci++)
	{
		rez = rez << 1;			// input, 597
		if(HAL_GPIO_ReadPin(SDIN_GPIO_Port, SDIN_Pin))
		{
			rez |= 0x01;
		}
		if (led & 0x80)  SDLED_SET();
		else             SDLED_CLR();
		if (rel & 0x80)  SDOUT_SET();
		else             SDOUT_CLR();
		SCLOCK();
		led = led << 1;			// output, 595
		rel = rel << 1;			// output, 595
	}
	SLATCH();
	OE_LED_SET();
	OE_OUT_SET();
	return rez;
}

void ReadKeys(void)
{
	switch(Keyboard())
	{
	// short press
	    case 0x01:	// short up
    	keyboard = 0x01;
    	keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		case CURR_AUTH:
    		break;

    		case AVARY_MENU:
    		cntDisplayAvary	= GetCntDisplayAvary(cntDisplayAvary, 1);
    		DisplayAvary(cntDisplayAvary);	// 1-increment
    		break;

    		case RUN_MENU:
    		if(Menu.RunMenu >= RUN_MENU_MIN)		Menu.RunMenu--;
    		if(Menu.RunMenu < RUN_MENU_MIN)			Menu.RunMenu = RUN_MENU_MAX;
    		timeoutAutomat = TIMEOUT_AUTOMAT;
    		break;

    		case SUB_RUN_MENU:
    		switch(Menu.RunMenu)
    		{
    			case RUN_ACTIVE:
    			break;

    			case RUN_SET_ADDR:
    			ClockRAM.config.addr++;
    			if(ClockRAM.config.addr > BA103_MAX_ADDR)		ClockRAM.config.addr = BA103_MAX_ADDR;
    			break;

    			case RUN_SET_UST:
    			ClockRAM.config.T1++;
    			if(ClockRAM.config.T1 > MAX_T1)		ClockRAM.config.T1 = MAX_T1;
    			break;

    			case RUN_SET_MODE:
    			Menu.Param++;
    			if(Menu.Param > 2)		Menu.Param = 2;
    			SetRR(Menu.Param);
    			break;

    			default:
    			break;
    		}
    		timeoutAutomat = TIMEOUT_AUTOMAT;
    		break;

    		case CURR_SERVICE:
       		if(Menu.ServiceMenu >= SERVICE_MIN)		Menu.ServiceMenu--;
       		if(Menu.ServiceMenu < SERVICE_MIN)		Menu.ServiceMenu = SERVICE_MAX;
    		timeoutService = TIMEOUT_SERVICE;
    		break;

    		case SUB_MENU_SERVICE:
       		switch(Menu.ServiceMenu)
       		{
       			case SERVICE_UGO:  // outputs
				case SERVICE_UGZ:
				case SERVICE_UZO:
				case SERVICE_GO1:
				case SERVICE_GO2:
				case SERVICE_NAG:
				case SERVICE_NAS:
				case SERVICE_VEN:
				case SERVICE_LOCK:
	       		Menu.Param = 1;
	       		break;

       			default:
       			break;
       		}
       		timeoutService = TIMEOUT_SERVICE;
    		break;

       		default:
       		break;
    	}
		break;

		case 0x02:	// short down
		keyboard = 0x02;
		keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		case CURR_AUTH:
    		break;

    		case AVARY_MENU:
        	cntDisplayAvary	= GetCntDisplayAvary(cntDisplayAvary, 2);
        	DisplayAvary(cntDisplayAvary);	// 2-decrement
    		break;

    		case RUN_MENU:
    		Menu.RunMenu++;
    		if(Menu.RunMenu > RUN_MENU_MAX)			Menu.RunMenu = RUN_MENU_MIN;
    		timeoutAutomat = TIMEOUT_AUTOMAT;
    		break;

    		case SUB_RUN_MENU:
    		switch(Menu.RunMenu)
    		{
    			case RUN_ACTIVE:
    			break;

    			case RUN_SET_ADDR:
    			if(ClockRAM.config.addr > BA103_MIN_ADDR)	ClockRAM.config.addr--;
    			break;

    			case RUN_SET_UST:
    			if(ClockRAM.config.T1 > MIN_T1)		ClockRAM.config.T1--;
    			if(ClockRAM.config.T1 < MIN_T1)		ClockRAM.config.T1 = MIN_T1;
    			break;

    			case RUN_SET_MODE:
       			if(Menu.Param)		Menu.Param--;
        		SetRR(Menu.Param);
    			break;

    			default:
    			break;
    		}
    		timeoutAutomat = TIMEOUT_AUTOMAT;
    		break;

    		case CURR_SERVICE:
        	Menu.ServiceMenu++;
        	if(Menu.ServiceMenu > SERVICE_MAX)		Menu.ServiceMenu = SERVICE_MIN;
    		timeoutService = TIMEOUT_SERVICE;
    		break;

    		case SUB_MENU_SERVICE:
    		switch(Menu.ServiceMenu)
    		{
				case SERVICE_UGO:  // outputs
				case SERVICE_UGZ:
				case SERVICE_UZO:
				case SERVICE_GO1:
				case SERVICE_GO2:
				case SERVICE_NAG:
				case SERVICE_NAS:
				case SERVICE_VEN:
				case SERVICE_LOCK:
    			Menu.Param = 0;
    			break;

				default:
				break;
    		}
    		timeoutService = TIMEOUT_SERVICE;
    		break;

    		default:
    		break;
    	}
		break;

		case 0x03:		// short enter
		keyboard = 0x04;
		keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		default:
    		case CURR_AUTH:
    		break;

    		case CURR_SERVICE:
    		break;

    		case SUB_MENU_SERVICE:
    		Menu.CurrMenu = CURR_SERVICE;
    		timeoutService = TIMEOUT_SERVICE;
    		break;

    		case SUB_RUN_MENU:
       		switch(Menu.RunMenu)
       		{
       			case RUN_SET_MODE:
       			if(BIT_TEST(ClockRAM.config.rr, RR_BIT_REMOTE) || BIT_TEST(ClockRAM.config.rr, RR_BIT_LOCAL))
       			{
       				if(Unit.clrState)		Unit.clrState = END_CLEAR;
       			}
       			if(BIT_TEST(ClockRAM.config.rr, RR_BIT_CLEAR))
       			{
       				Unit.clrState = BEGIN_CLEAR;
       			}
       			break;

       			case RUN_SET_ADDR:
       			break;

        		default:
        		break;
        	}
        	Menu.CurrMenu = RUN_MENU;
        	timeoutAutomat = TIMEOUT_AUTOMAT;
    		break;
    	}
		break;

		case 0x04:		// short escape
		keyboard = 0x08;
		keyPress = 0;
		beepPick.State = 2;		// beep off
		if(ClockRAM.config.alr == 0)
		{	// reset avary memory
			BIT_CLR(ClockRAM.config.alrMemory, cntDisplayAvary);
			BIT_CLR(ClockRAM.config.flagAvary, cntDisplayAvary);
		}
		if(Unit.ignitionState >= MANUAL_IGNITION)
		{
			Unit.keyIgnition = 1;
		}
		break;

		// long press
		case 0x11:		// long up
		keyboard = 0x11;
		keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		default:
    		case CURR_AUTH:
    		break;

    		case AVARY_MENU:
    		break;

    		case CURR_SERVICE:
    		Menu.CurrMenu = SUB_MENU_SERVICE;
    		Menu.Param = 0;
    		timeoutService = TIMEOUT_SERVICE;
    		break;

    		case RUN_MENU:
    		Menu.CurrMenu = SUB_RUN_MENU;
    		timeoutAutomat = TIMEOUT_AUTOMAT;
    		break;

    		case SUB_RUN_MENU:
    		switch(Menu.RunMenu)
    		{
    			case RUN_SET_UST:
    			if(cntLongPress == 0)
    			{
    				cntLongPress = COUNT_AUTO_PUSH;
        			ClockRAM.config.T1++;
        			if(ClockRAM.config.T1 > MAX_T1)		ClockRAM.config.T1 = MAX_T1;
    			}
    			break;

       			default:
        		break;
        	}
        	timeoutAutomat = TIMEOUT_AUTOMAT;
        	break;

    	}
		break;

		case 0x12:		// long down
		keyboard = 0x22;
		keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		default:
    		case CURR_AUTH:
    		break;

    		case AVARY_MENU:
    		break;

    		case CURR_SERVICE:
    		Menu.CurrMenu = SUB_MENU_SERVICE;
    		Menu.Param = 0;
    		timeoutService = TIMEOUT_SERVICE;
    		break;

    		case RUN_MENU:
    		Menu.CurrMenu = SUB_RUN_MENU;
     		timeoutAutomat = TIMEOUT_AUTOMAT;
    		break;

    		case SUB_RUN_MENU:
    		switch(Menu.RunMenu)
    		{
    			case RUN_SET_UST:
    			if(cntLongPress == 0)
    			{
    				cntLongPress = COUNT_AUTO_PUSH;
    				ClockRAM.config.T1--;
    				if(ClockRAM.config.T1 < MIN_T1)		ClockRAM.config.T1 = MIN_T1;
    			}
     			break;

       			default:
        		break;
        	}
        	timeoutAutomat = TIMEOUT_AUTOMAT;
        	break;
    	}
		break;

		case 0x13:	// long enter
		keyboard = 0x44;
		keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		case CURR_AUTH:
    		Menu.CurrMenu = RUN_MENU;
    		Menu.RunMenu = RUN_MENU_MIN;
    		BIT_SET(ClockRAM.config.rc, 1); // on unit
    		Unit.State = GO_WAIT_STATE;
    		timeoutAutomat = TIMEOUT_AUTOMAT;
    		break;

    		case RUN_MENU:  // 1PR01
    		Menu.CurrMenu = CURR_AUTH;
    		BIT_CLR(ClockRAM.config.rc, 1); // off unit
    		Unit.State = GO_STOP_STATE;
    		break;

    		case AVARY_MENU:
    		Menu.CurrMenu = CURR_AUTH;
    		Unit.State = GO_WAIT_STATE;	//
    		break;

    		case CURR_SERVICE:
    		Menu.CurrMenu = CURR_AUTH;
    		OffAllRelays();
    		timeoutService = 0;
    		break;

    		case SUB_MENU_SERVICE:
    		break;
    	}
		break;

		case 0x14:	// long escape
		keyboard = 0x88;
		keyPress = 0;
		if(ClockRAM.config.alr == 0)
		{	// reset avary memory
			ClockRAM.config.alrMemory = 0;
		}
		if(Unit.ignitionState >= MANUAL_IGNITION)
		{
			Unit.keyIgnition = 2;
		}
		break;

		case 0x15:	// long up+dn+ent
		keyPress = 0;
    	switch(Menu.CurrMenu)
    	{
    		case CURR_AUTH:  // 1PR02
    		Menu.CurrMenu = IN_TO_SERVICE;
    		SetSRK(SRK_BIT_SERVICE);
    		rm_counter = 0;
    		break;

    		case CURR_SERVICE:
    		break;

    		case SUB_MENU_SERVICE:
    		break;
    	}
		break;

		default:
		break;
	}
}

uint16_t Keyboard(void)
{ //0-no press, 1-press up, 2-press down, 3-press escape, 4-press enter
	uint16_t keyCode;

	keyCode = 0;
	keyNow = KEY_RELEASED;
	if(HAL_GPIO_ReadPin(KB_UP_GPIO_Port, KB_UP_Pin) == GPIO_PIN_RESET)		BIT_CLR(keyNow, 0);		// port A
	if(HAL_GPIO_ReadPin(KB_DOWN_GPIO_Port, KB_DOWN_Pin) == GPIO_PIN_RESET) 	BIT_CLR(keyNow, 1);		// port A
	if(HAL_GPIO_ReadPin(KB_ESC_GPIO_Port, KB_ESC_Pin) == GPIO_PIN_RESET)   	BIT_CLR(keyNow, 2);		// port C
	if(HAL_GPIO_ReadPin(KB_ENT_GPIO_Port, KB_ENT_Pin) == GPIO_PIN_RESET)   	BIT_CLR(keyNow, 3);		// port A
	if(keyNow != keyOld)
	{
		if(keyNow == KEY_RELEASED)
		{ // all keys released
			cntPress = 0;
			cntLongPress = 0;
			if(keyPress)			keyCode = keyPress;
		}
		else
		{
			cntPress = TIME_PRESS_DLY;
			cntLongPress = LONG_PRESS_DLY;
			keyPress = 0;
		}
		keyOld = keyNow;
	}
	else
	{
		if(cntPress == 1)
		{
			cntPress = 0;
			if(keyNow == KEY_UP_PRESS)
			{ // key up pressed
				keyPress = 0x01;
			}
			if(keyNow == KEY_DN_PRESS)
			{ // key down pressed
				keyPress = 0x02;
			}
			if(keyNow == KEY_ESC_PRESS)
			{ // key escape pressed
				keyPress = 0x03;
			}
			if(keyNow == KEY_ENT_PRESS)
			{ // key enter pressed
				keyPress = 0x04;
			}
			Beep(BEEP_PULSE_1);
		}
		if(cntLongPress == 1)
		{
			cntLongPress = 0;
			if(keyNow == KEY_UP_PRESS)
			{ // key up pressed
				keyCode = 0x11;
			}
			if(keyNow == KEY_DN_PRESS)
			{ // key down pressed
				keyCode = 0x12;
			}
			if(keyNow == KEY_ESC_PRESS)
			{ // key escape pressed
				keyCode = 0x13;
			}
			if(keyNow == KEY_ENT_PRESS)
			{ // key enter pressed
				keyCode = 0x14;
			}
			if(keyNow == KEY_UP_DN_ENT_PRESS)
			{ // key up, down, enter pressed
				keyCode = 0x15;
			}
			if(Menu.RunMenu != RUN_SET_UST)		Beep(BEEP_PULSE_1);
		}
	}
	if(cntPress)			cntPress--;
	if(cntLongPress)		cntLongPress--;
	return keyCode;
}

uint8_t Decode(uint8_t val)
{ // hgfe dcba
	uint8_t rez;

	switch(val)
	{
		case 0x30:
		rez = 0x3F;			// 0
		break;

		case 0x31:
		rez = 0x06;			// 1
		break;

		case 0x32:
		rez = 0x5B;			// 2
		break;

		case 0x33:
		rez = 0x4F;			// 3
		break;

		case 0x34:
		rez = 0x66;			// 4
		break;

		case 's':
		case 'S':
		case 0x35:
		rez = 0x6D;			// 5, S
		break;

		case 0x36:
		rez = 0x7D;			// 6
		break;

		case 0x37:
		rez = 0x07;			// 7
		break;

		case 0x38:
		case 'V':
		case 'v':
		rez = 0x7F;			// 8
		break;

		case 0x39:
		rez = 0x6F;			// 9
		break;

		case 0x20:
		rez = DIGIT_OFF;	// space
		break;

		case '-':
		rez = 0x40;			// -
		break;

		case '_':
		rez = 0x08;			// _
		break;

		case 'a':
		case 'A':
		rez = 0x77;			// A
		break;

		case 'b':
		case 'B':
		rez = 0x7C;			// b
		break;

		case 'c':
		case 'C':
		rez = 0x39;			// C
		break;

		case 'd':
		case 'D':
		rez = 0x5E;			// d
		break;

		case 'e':
		case 'E':
		rez = 0x79;			// E
		break;

		case 'f':
		case 'F':
		rez = 0x71;			// F
		break;

		case 'g':
		case 'G':
		rez = 0x31;			// Г
		break;

		case 'h':
		rez = 0x74;			// h
		break;

		case 'H':
		rez = 0x76;			// H
		break;

		case 'i':
		case 'I':
		rez = 0x04;			// i
		break;

		case 'n':
		case 'N':
		rez = 0x54;			// n
		break;

		case 'o':
		case 'O':
		rez = 0x5C;			// o
		break;

		case 'p':
		case 'P':
		rez = 0x73;			// P
		break;

		case 'r':
		case 'R':
		rez = 0x50;			// r
		break;

		case 't':
		case 'T':
		rez = 0x78;			// t
		break;

		case 'u':
		rez = 0x1C;			// u
		break;

		case 'U':
		rez = 0x3E;			// U
		break;

		case 'y':
		case 'Y':
		rez = 0x6E;			// Y
		break;

		case 'z':
		rez = 0x54;			// п
		break;

		case 'Z':
		rez = 0x37;			// П
		break;

		default:
		rez = DIGIT_OFF;
		break;
	}
	return rez;
}

int ConvTemperature(int vadc)
{
	double tmp;
	int rez;

	if (vadc >= 1700)
	{	// y(x)=x/10.65-122
		tmp = vadc / 10.65;
		rez = (int)(tmp - 122);
	}
	if ((vadc < 1700) && (vadc > 1230))
	{	// y(x)=x/10-132
		tmp = vadc / 10;
		rez = (int)(tmp - 132);
	}
	if (vadc <= 1230)
	{	// y(x)=x/8.6-152
		tmp = vadc / 8.6;
		rez = (int)(tmp - 152);
	}
	return rez;
}

int ConvTermopara(int vadc)
{ // 2,767 - 1300 C
	double tmp;
	int rez;

	tmp = vadc / ADC_KU_KTYPE;
	rez = (int)tmp;

	return rez;
}

void Meassure(void)
{
	int ci;
	uint32_t tmp0, tmp1, tmp2, tmp3, tmp4, tmp5;
	double rez;

	Single(); // adc conversion
	if(countSample > 6)
	{ // one cycle measuring
		UIN[countADC] = ADC_result[0];
		NTC_Hot[countADC] = ADC_result[1];
		NTC_Cold[countADC] = ADC_result[2];
		NTC_gor[countADC] = ADC_result[3];
		NTC_sg[countADC] = ADC_result[4];
		NTC_vyh[countADC] = ADC_result[5];
		countADC++;
		if(countADC > (ADC_BUFF_LEN-2))
		{
			countADC = 1;
			trueValue++;
			if(trueValue > 100)		trueValue = 100;
		}
		tmp0 = 0;
		tmp1 = 0;
		tmp2 = 0;
		tmp3 = 0;
		tmp4 = 0;
		tmp5 = 0;
		for(ci = 1; ci < (ADC_BUFF_LEN-1); ci++)
		{
			tmp0 += UIN[ci];
			tmp1 += NTC_Hot[ci];
			tmp2 += NTC_Cold[ci];
			tmp3 += NTC_gor[ci];
			tmp4 += NTC_sg[ci];
			tmp5 += NTC_vyh[ci];
		}
		NTC_Hot[0] = tmp1 >> 4;
		NTC_Cold[0] = tmp2 >> 4;
		NTC_gor[0] = tmp3 >> 4;
		NTC_sg[0] = tmp4 >> 4;
		NTC_vyh[0] = tmp5 >> 4;
		tmp1 = 0;
		tmp2 = 0;
		tmp3 = 0;
		tmp4 = 0;
		tmp5 = 0;
		for(ci = 1; ci < (ADC_BUFF_LEN-1); ci++)
		{ // not used value greather ADC_FILTER_VAL
			if(abs(NTC_Hot[ci] - NTC_Hot[0]) < ADC_FILTER_VAL)		tmp1 += NTC_Hot[ci];
			else													tmp1 += NTC_Hot[0];
			if(abs(NTC_Cold[ci] - NTC_Cold[0]) < ADC_FILTER_VAL)	tmp2 += NTC_Cold[ci];
			else													tmp2 += NTC_Cold[0];
			if(abs(NTC_gor[ci] - NTC_gor[0]) < ADC_FILTER_VAL)		tmp3 += NTC_gor[ci];
			else													tmp3 += NTC_gor[0];
			if(abs(NTC_sg[ci] - NTC_sg[0]) < ADC_FILTER_VAL)		tmp4 += NTC_sg[ci];
			else													tmp4 += NTC_sg[0];
			if(abs(NTC_vyh[ci] - NTC_vyh[0]) < ADC_FILTER_VAL)		tmp5 += NTC_vyh[ci];
			else													tmp5 += NTC_vyh[0];
		}
		UIN[0] = tmp0 >> 4;
		rez = ADC_KU_12 * UIN[0];
//		rez += 300;				// +300 mV compensation shottky diode
		rez = rez / 100;
		U_input = (uint16_t)rez;
		NTC_Hot[0] = tmp1 >> 4;
		rez = NTC_Hot[0] * ADC_KU_3;
		ci = ConvTemperature((int)rez);
		T_hot = TestNTCsensor(ci, 1);		// DT1, podacha
		NTC_Cold[0] = tmp2 >> 4;
		rez = NTC_Cold[0] * ADC_KU_3;
		ci = ConvTemperature((int)rez);
		T_cold = TestNTCsensor(ci, 2);		// DT2, obratka
		NTC_gor[0] = tmp3 >> 4;
		rez = NTC_gor[0] * ADC_KU_3;
		ci = ConvTemperature((int)rez);
		T_gor = TestNTCsensor(ci, 3);		// DT3, drova v sheke
		NTC_sg[0] = tmp4 >> 4;
		rez = NTC_sg[0] * ADC_KU_3;
		ci = ConvTermopara((int)rez);
		T_sg = TestNTCsensor(ci, 4);		// DT4, camera sgoranija
		NTC_vyh[0] = tmp5 >> 4;
		rez = NTC_vyh[0] * ADC_KU_3;
		ci = ConvTermopara((int)rez);
		T_vyh = TestNTCsensor(ci, 5);		// DT5, dym v trube
	}
}

void OutputToRegister(void)
{
	if(BIT_TEST(relayData, RELAY_SHNEK3))		BIT_SET(DIO, DIO_SHNEK3);
	else										BIT_CLR(DIO, DIO_SHNEK3);
	if(BIT_TEST(relayData, RELAY_SHNEK1))		BIT_SET(DIO, DIO_SHNEK1);
	else										BIT_CLR(DIO, DIO_SHNEK1);
	if(BIT_TEST(relayData, RELAY_SHNEK2))		BIT_SET(DIO, DIO_SHNEK2);
	else										BIT_CLR(DIO, DIO_SHNEK2);
	if(BIT_TEST(relayData, RELAY_HEATER))		BIT_SET(DIO, DIO_HEATER);
	else										BIT_CLR(DIO, DIO_HEATER);
	if(BIT_TEST(relayData, RELAY_PUMP))			BIT_SET(DIO, DIO_PUMP);
	else										BIT_CLR(DIO, DIO_PUMP);
	if(BIT_TEST(relayData, RELAY_FAN))			BIT_SET(DIO, DIO_FAN);
	else										BIT_CLR(DIO, DIO_FAN);

}

int TestNTCsensor(int val, uint16_t nbit)
{
	if(trueValue > TRUE_VALUE_DELAY)
	{
		switch(nbit)
		{
			case 1:	// DT1
			if(val <= (int16_t)ClockRAM.config.T13) 	BIT_CLR(ClockRAM.config.flagAvary, ALR_BIT_OPEN_HOT);
			if((val > (int16_t)ClockRAM.config.T13) && (BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_OPEN_HOT) == 0))
			{ // open
				BIT_SET(ClockRAM.config.flagAvary, ALR_BIT_OPEN_HOT);
				UnitOff(PUMP_RUN_ON, SHNECK_COOL_OFF);		// off unit, ВН+АО
			}
			else
			{
				if(BIT_TEST(ClockRAM.config.alr, ALR_BIT_OPEN_HOT))
				{
					BIT_CLR(ClockRAM.config.alr, ALR_BIT_OPEN_HOT);
					BIT_SET(ClockRAM.config.alrMemory, ALR_BIT_OPEN_HOT);
				}
			}
			if(val >= (int16_t)ClockRAM.config.T14)		BIT_CLR(ClockRAM.config.flagAvary, ALR_BIT_SHORT_HOT);
			if((val < (int16_t)ClockRAM.config.T14) && (BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SHORT_HOT) == 0))
			{ // short
				BIT_SET(ClockRAM.config.flagAvary, ALR_BIT_SHORT_HOT);
				UnitOff(PUMP_RUN_ON, SHNECK_COOL_OFF);		// off unit, ВН+АО
			}
			else
			{
				if(BIT_TEST(ClockRAM.config.alr, ALR_BIT_SHORT_HOT))
				{
					BIT_CLR(ClockRAM.config.alr, ALR_BIT_SHORT_HOT);
					BIT_SET(ClockRAM.config.alrMemory, ALR_BIT_SHORT_HOT);
				}
			}

			break;

			case 2:	// DT2
			if(val > (int16_t)ClockRAM.config.T13)	BIT_SET(ClockRAM.config.wrn, WRN_BIT_OPEN_DT2);
			else									BIT_CLR(ClockRAM.config.wrn, WRN_BIT_OPEN_DT2);
			if(val < (int16_t)ClockRAM.config.T14)	BIT_SET(ClockRAM.config.wrn, WRN_BIT_SHORT_DT2);
			else									BIT_CLR(ClockRAM.config.wrn, WRN_BIT_SHORT_DT2);
			break;

			case 3:	// DT3
			if(val > (int16_t)ClockRAM.config.T13)	BIT_SET(ClockRAM.config.wrn, WRN_BIT_OPEN_DT3);
			else									BIT_CLR(ClockRAM.config.wrn, WRN_BIT_OPEN_DT3);
			if(val < (int16_t)ClockRAM.config.T14)	BIT_SET(ClockRAM.config.wrn, WRN_BIT_SHORT_DT3);
			else									BIT_CLR(ClockRAM.config.wrn, WRN_BIT_SHORT_DT3);
			break;

			case 4:

			break;

			case 5:

			break;

			default:
			break;
		}
	}
	return val;
}

void InitEEPROM(void)
{
#ifdef _MEMORY_25_SERIES
///	at25df_bulkErase();
	at25df_init();
#endif

#ifdef _MEMORY_24_SERIES
	uint8_t buf[8], tst, cnt;

#ifdef _BUS_OUTPUT_UART
	Println1("\ninit 24 series memory");
#endif
	cnt = 0;
	while(tst != HAL_OK)
	{
		tst = HAL_I2C_Master_Receive(&hi2c1, MEM_ADDR, buf, 4, TIMEOUT_I2C);
		HAL_Delay(500);
		cnt++;
		if(cnt > 10)	break;
	}
	if(cnt > 10)
	{
#ifdef _BUS_OUTPUT_UART
		Println1(" fail!");
#endif
	}
	else
	{
#ifdef _BUS_OUTPUT_UART
		Println1(" ok...");
#endif
	}
#endif
}

void ReadEEtoRAM(uint32_t addr, uint8_t *buf, uint16_t len)
{
#ifdef _MEMORY_24_SERIES
	uint32_t cnt;

	cnt = 10;	//
	while(cnt)
	{
		if(HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, buf, len, TIMEOUT_I2C) == HAL_OK)	break;
		cnt--;
	}
#endif

#ifdef _MEMORY_25_SERIES
	at25df_read(addr, buf, len);
#endif
}

void WriteRAMtoEE(uint32_t addr, uint8_t *buf, uint16_t len)
{
#ifdef _MEMORY_24_SERIES
	while(len)
	{
		if(len >= 64)
		{
			HAL_I2C_Mem_Write(&hi2c1, MEM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, buf, 64, TIMEOUT_I2C);
			HAL_Delay(TIMEOUT_I2C);
			addr += 64;
			len -= 64;
		}
		else
		{
			HAL_I2C_Mem_Write(&hi2c1, MEM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, buf, len, TIMEOUT_I2C);
			HAL_Delay(TIMEOUT_I2C);
			len = 0;
		}
	}
#endif

#ifdef _MEMORY_25_SERIES
//	sectorUnprotect(START_ADDR);
	at25df_eraseSector(START_ADDR);
	at25df_write(addr, buf, len);
#endif
}

void CompareEEpromRAM(void)
{
#ifdef _MEMORY_24_SERIES

	uint8_t val[6];

	memset(val, 0, sizeof(val));
	ReadEEtoRAM((cntEeRamAddr+START_ADDR), val, 2);
	if(val[0] != ClockRAM.data8[cntEeRamAddr])
	{
		val[0] = ClockRAM.data8[cntEeRamAddr];
		WriteRAMtoEE((cntEeRamAddr+START_ADDR), val, 1);
//		HAL_Delay(TIMEOUT_I2C);
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println1("\neeprom_24 [");
			itoa((cntEeRamAddr+START_ADDR), buff, 10);
			Println1(buff);
			Println1("] = ");
			itoa(val[0], buff, 10);
			Println1(buff);
		}
#endif
	}
#endif

#ifdef _MEMORY_25_SERIES

	uint8_t  buff_at25df[PARAMS_LEN];

	ReadEEtoRAM(START_ADDR, buff_at25df, PARAMS_LEN);
	if(buff_at25df[cntEeRamAddr] != ClockRAM.data8[cntEeRamAddr])
	{
		RefreshEEpromData();
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println1("\neeprom_25 [0x");
			itoa((cntEeRamAddr+START_ADDR), buff, 16);
			Println1(buff);
			Println1("] = ");
			itoa(buff_at25df[cntEeRamAddr], buff, 10);
			Println1(buff);
		}
#endif
	}
#endif
	cntEeRamAddr++;
	if(cntEeRamAddr >= PARAMS_LEN)	cntEeRamAddr = 0;
}

void CompareEEpresetRAM(void)
{
	defPRaddr = GetPresetAddr(ClockRAM.config.preset);
#ifdef _MEMORY_24_SERIES

	uint8_t val[6];

	memset(val, 0, sizeof(val));
	ReadEEtoRAM((cntPresetAddr+defPRaddr), val, 2);
	if(val[0] != ClockRAM.data8[PARAMS_LEN+cntPresetAddr])
	{
		val[0] = ClockRAM.data8[PARAMS_LEN+cntPresetAddr];
		WriteRAMtoEE((cntPresetAddr+defPRaddr), val, 1);
//		HAL_Delay(TIMEOUT_I2C);
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println1("\npreset_eeprom_24 [");
			itoa((cntPresetAddr+defPRaddr), buff, 10);
			Println1(buff);
			Println1("] = ");
			itoa(val[0], buff, 10);
			Println1(buff);
		}
#endif
	}
#endif

#ifdef _MEMORY_25_SERIES

	uint8_t  buff_at25df[PRESET_LEN];

	ReadEEtoRAM(defPRaddr, buff_at25df, PRESET_LEN);
	if(buff_at25df[cntPresetAddr] != ClockRAM.data8[PARAMS_LEN+cntPresetAddr])
	{
		RefreshEEpresetData();
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println1("\npreset_eeprom_25 [0x");
			itoa((cntPresetAddr+defPRaddr), buff, 16);
			Println1(buff);
			Println1("] = ");
			itoa(buff_at25df[cntPresetAddr], buff, 10);
			Println1(buff);
		}
#endif
	}
#endif
	cntPresetAddr++;
	if(cntPresetAddr >= PRESET_LEN)	cntPresetAddr = 0;
}

void CompareEEdebugRAM(void)
{
#ifdef _MEMORY_24_SERIES

	uint8_t val[6];

	memset(val, 0, sizeof(val));
	ReadEEtoRAM((cntDebugAddr+DEBUG_EE_ADDR), val, 2);
	if(val[0] != ClockRAM.data8[cntDebugAddr+PARAMS_LEN+PRESET_LEN])
	{
		val[0] = ClockRAM.data8[cntDebugAddr+PARAMS_LEN+PRESET_LEN];
		WriteRAMtoEE((cntDebugAddr+DEBUG_EE_ADDR), val, 1);
//		HAL_Delay(TIMEOUT_I2C);
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println1("\ndebug_eeprom_24 [");
			itoa((cntDebugAddr+DEBUG_EE_ADDR), buff, 10);
			Println1(buff);
			Println1("] = ");
			itoa(val[0], buff, 10);
			Println1(buff);
		}
#endif
	}
#endif

#ifdef _MEMORY_25_SERIES

	uint8_t  buff_at25df[DEBUG_LEN];

	ReadEEtoRAM(DEBUG_EE_ADDR, buff_at25df, DEBUG_LEN);
	if(buff_at25df[cntDebugAddr] != ClockRAM.data8[cntDebugAddr+PARAMS_LEN+PRESET_LEN])
	{
		RefreshEEpromData();
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println1("\neeprom_25 [0x");
			itoa((cntDebugAddr+DEBUG_EE_ADDR), buff, 16);
			Println1(buff);
			Println1("] = ");
			itoa(buff_at25df[cntDebugAddr], buff, 10);
			Println1(buff);
		}
#endif
	}
#endif
	cntDebugAddr++;
	if(cntDebugAddr >= DEBUG_LEN)	cntDebugAddr = 0;
}

uint16_t GetPresetAddr(uint16_t pr)
{
	uint16_t pr_addr;

	switch(ClockRAM.config.preset)
	{
	default:
		ClockRAM.config.preset = DEFAULT_PRESET;
	case 0:
		pr_addr = PR0_ADDR;
		break;

	case 1:
		pr_addr = PR1_ADDR;
		break;

	case 2:
		pr_addr = PR2_ADDR;
		break;

	case 3:
		pr_addr = PR3_ADDR;
		break;

	case 4:
		pr_addr = PR4_ADDR;
		break;
	}

	return pr_addr;
}

void Beep(uint8_t pulse)
{
	if(beepPick.State)	return;
	switch(pulse)
	{
		case BEEP_PULSE_1:		// short beep
		beepPick.Lengh = BEEP_SHORT;
		beepPick.State = 1;
		break;

		case BEEP_PULSE_2:		// middle beep
		beepPick.Lengh = BEEP_MIDLE;
		beepPick.State = 1;
		break;

		case BEEP_PULSE_3:		// long beep
		beepPick.Lengh = BEEP_LONG;
		beepPick.State = 1;
		break;

		case BEEP_PULSE_4:
		beepPick.Lengh = BEEP_LONG;
		beepPick.cnt = 0;
		beepPick.State = 3;
		break;

		case BEEP_PULSE_5:
		beepPick.Lengh = BEEP_LONG;
		beepPick.cnt = 5;
		beepPick.State = 16;
		break;

		default:
		beepPick.State = 2;		// beep off
		break;
	}
}

void BeepRun(void)
{
	switch(beepPick.State)
	{
	case 1:
		if(beepPick.Lengh)
		{
			Buzzer(BUZZER_PIN_ON);
			beepPick.Lengh--;
		}
		else				beepPick.State++;
		break;

	case 2:
		Buzzer(BUZZER_PIN_OFF);
		beepPick.State = 0;
		break;

	case 3:
		beepPick.Lengh = BEEP_LONG;
		beepPick.State++;
		break;

	case 4:		// 1-st pulse
		Buzzer(BUZZER_PIN_ON);
		if(beepPick.Lengh)	beepPick.Lengh--;
		else				beepPick.State++;
		break;

	case 5:
		beepPick.Pause = BEEP_PAUSE;
		beepPick.State++;
		break;

	case 6:
		Buzzer(BUZZER_PIN_OFF);
		if(beepPick.Pause)	beepPick.Pause--;
		else				beepPick.State++;
		break;

	case 7:
		beepPick.Lengh = BEEP_LONG;
		beepPick.State++;
		break;

	case 8:		// 2-st pulse
		Buzzer(BUZZER_PIN_ON);
		if(beepPick.Lengh)	beepPick.Lengh--;
		else				beepPick.State++;
		break;

	case 9:
		beepPick.Pause = BEEP_PAUSE;
		beepPick.State++;
		break;

	case 10:
		Buzzer(BUZZER_PIN_OFF);
		if(beepPick.Pause)	beepPick.Pause--;
		else				beepPick.State++;
		break;

	case 11:
		beepPick.Lengh = BEEP_LONG;
		beepPick.State++;
		break;

	case 12:		// 3-st pulse
		Buzzer(BUZZER_PIN_ON);
		if(beepPick.Lengh)	beepPick.Lengh--;
		else				beepPick.State++;
		break;

	case 13:
		beepPick.Pause = BEEP_PAUSE;
		beepPick.State++;
		break;

	case 14:
		Buzzer(BUZZER_PIN_OFF);
		if(beepPick.cnt == 0)
		{
			if(beepPick.Pause)	beepPick.Pause--;
			else				beepPick.State++;
		}
		else if(beepPick.cnt == 1)
		{		// end series
			beepPick.Pause = 0;
			beepPick.State = 2;
		}
		else if(beepPick.cnt > 1)
		{		// next series
			beepPick.Pause = BEEP_SERIES_PAUSE;
			beepPick.State = 16;
		}
		if(beepPick.cnt)		beepPick.cnt--;
		break;

	case 15:
		beepPick.State = 0;
		break;

	case 16:
		if(beepPick.Pause)	beepPick.Pause--;
		else				beepPick.State = 3;
		break;

	case 0:
	default:
		break;
	}
}

void OffAllRelays(void)
{
	Relays(RELAY_KOLOSNIK_OFF, 0);
	Relays(RELAY_KOLOSNIK_ON, 0);
	Relays(RELAY_FAN, 0);
	Relays(RELAY_HEATER, 0);
	Relays(RELAY_PUMP, 0);
	Relays(RELAY_SHNEK3, 0);
	Relays(RELAY_SHNEK2, 0);
	Relays(RELAY_SHNEK1, 0);
	Relays(RELAY_LOCK, 0);
}

void Ventilator(uint8_t st, uint8_t val)
{
	Relays(RELAY_FAN, st);
	Unit.sifu = val;
}

void TestVentilator(void)
{ // for servise menu
	switch(sifuTestFlag)
	{
	default:
	case 0:
		Unit.sifu = 0;
		sifuTestCntr = 2; // go to relay on
		Relays(RELAY_FAN, 0);
		break;

	case 1:
		switch(sifuTestCntr)
		{
		default:
		case 2:
			if(HAL_GPIO_ReadPin(FAN_GPIO_Port, FAN_Pin) == GPIO_PIN_RESET)
			{
				sifuTestCntr = 0;
				Unit.sifu = SIFU_MINIMAL_VALUE;
				Relays(RELAY_FAN, 1);
			}
			break;

		case 0:	// up
			Unit.sifu++;
			if(Unit.sifu >= SIFU_BEGIN_VALUE)
			{
				Unit.sifu--;
				sifuTestCntr = 1;
			}
			break;

		case 1: // down
			if(Unit.sifu > SIFU_MINIMAL_VALUE)	Unit.sifu--;
			if(Unit.sifu <= SIFU_MINIMAL_VALUE)	sifuTestCntr = 0;
			break;
		}
		break;
	}
}
/*
void PWM_Pin(uint8_t state)
{
	if(state == PWM_ON)
	{
		HAL_GPIO_WritePin(FAN_GPIO_Port, FAN_Pin, GPIO_PIN_SET); // sifu pin on
	}
	else
	{
		HAL_GPIO_WritePin(FAN_GPIO_Port, FAN_Pin, GPIO_PIN_RESET); // sifu pin off
	}
}
*/
void Buzzer(uint8_t state)
{
	if(state == BUZZER_PIN_ON)
	{
		HAL_GPIO_WritePin(BUZ_GPIO_Port, BUZ_Pin, BUZZER_PIN_ON); // buzzer on
	}
	else
	{
		HAL_GPIO_WritePin(BUZ_GPIO_Port, BUZ_Pin, BUZZER_PIN_OFF); // buzzer off
	}
}

void PrintTick(void)
{ // send socond tick
	char str[16];

	str[0] = '\0';
	strcat(str, "\ntick: ");
	itoa(secLogCnt, buff, 10);
	strcat(str, buff);
	Println1(str);
}

void Println1(char _out[])
{
	HAL_GPIO_WritePin(DIR1_GPIO_Port, DIR1_Pin, GPIO_PIN_SET);
	HAL_UART_Transmit(&huart1, (uint8_t *) _out, strlen(_out), UART_TIMEOUT);
	HAL_GPIO_WritePin(DIR1_GPIO_Port, DIR1_Pin, GPIO_PIN_RESET);
}

void Println3(char _out[])
{
	HAL_GPIO_WritePin(DIR3_GPIO_Port, DIR3_Pin, GPIO_PIN_SET);
	HAL_UART_Transmit(&huart3, (uint8_t *) _out, strlen(_out), UART_TIMEOUT);
	HAL_GPIO_WritePin(DIR3_GPIO_Port, DIR3_Pin, GPIO_PIN_RESET);
}
