/*
 * bu_103_bus.c
 *
 *  Created on: 21 янв. 2023 г.
 *      Author: vitaly
 */
#include <string.h>
#include <stdlib.h>
#include "stm32f0xx_hal.h"
#include "main.h"
#include "adc_stm32.h"
#include "drivers.h"
#include "ba_103_bus.h"
#include "at25df.h"
#include "automat.h"

extern I2C_HandleTypeDef hi2c1;
extern UART_HandleTypeDef 	huart3;

void InitializeBus(void)
{
	Setup_UARTs();
	AddressBA103 = ClockRAM.config.addr;

	Println1("\nba_103_version: ");
	itoa(ClockRAM.config.version, buff, 10);
	Println1(buff);
	Println1("\nba_103_addr: 0x");
	itoa(ClockRAM.config.addr, buff, 16);
	Println1(buff);
}

void Setup_UARTs(void)
{
	USART1->CR1 |= USART_CR1_RXNEIE;
	UART_1.input_buff[0] = USART1->RDR;
	USART3->CR1 |= USART_CR1_RXNEIE;
	UART_3.input_buff[0] = USART3->RDR;

	HAL_GPIO_WritePin(DIR3_GPIO_Port, DIR3_Pin, GPIO_PIN_RESET);
// slave port
	UART_1.cntReceive = 0;
	UART_1.dataReady = 0;
	UART_1.dataOver = 0;
	UART_1.waitTimer = 0;
//	UART_1.cntTestLine = ClockRAM.config.t11;
	UART_1.tstLine = 0;
// master port
	UART_3.cntReceive = 0;
	UART_3.dataReady = 0;
	UART_3.dataOver = 0;
	UART_3.waitTimer = 0;
	UART_3.cntTestLine = 0;
	UART_3.tstLine = 0;
}

void TimeOutReceive_10ms(void)
{
	if(UART_1.waitTimer)		UART_1.waitTimer--;
	if(UART_1.waitTimer == 1)	UART_1.dataReady++;
	if(UART_3.waitTimer)		UART_3.waitTimer--;
	if(UART_3.waitTimer == 1)	UART_3.dataReady++;
	ReadUART1();
	ReadUART3();
	if(UART_1.cntTimeOut)	UART_1.cntTimeOut--;
	if(UART_1.cntTimeOut == 1)
	{
		UART_1.cntTimeOut = 0;
		UART_1.dataReady = 0;
	}
	if(UART_3.cntTimeOut)	UART_3.cntTimeOut--;
	if(UART_3.cntTimeOut == 1)
	{
		UART_3.cntTimeOut = 0;
		UART_3.dataReady = 0;
	}
}

void ReadUART1(void)
{
	if(UART_1.dataReady)
	{
		UART_1.num = 1;
		ParseInputSlave(&UART_1);
		UART_1.dataReady = 0;
	}
}

void ReadUART3(void)
{
	if(UART_3.dataReady)
	{
		UART_3.num = 3;
		ParseInputSlave(&UART_3);
		UART_3.dataReady = 0;
	}
}

void ClearUartBuff(config_uart_t *uart)
{
	uart->cntReceive = 0;
	uart->input_buff[2] = 0;
	uart->input_buff[3] = 0;
	uart->input_buff[4] = 0;
	uart->input_buff[5] = 0;
}

void ParseInputSlave(config_uart_t *uart)
{ // from host to BU
	uint32_t cb, cv;
	uint16_t ci, cval;
	uint8_t  errcode;

	if(uart->cntReceive < 4)
	{
		ClearUartBuff(uart);
		return;
	}

	errcode = MODBUS_OK;
#ifdef _BUS_OUTPUT_UART
	len_bf = uart->cntReceive;
	if(log_debug)
	{
		memcpy(input_bf, uart->input_buff, len_bf);
	}
#endif
	ci = uart->cntReceive;
	cv = uart->input_buff[ci-1];
	cv = cv << 8;
	cv |= uart->input_buff[ci-2];
	cb = CalculateCRC16(uart->input_buff, ci-2);
	if(cv != cb)
	{
#ifdef _BUS_OUTPUT_UART
		if(log_debug)
		{
			cval = cv >> 8;
			cv = cv << 8;
			cval |= cv;
			itoa(cval, buff, 16);
			Println1("\nInput check sum cv: 0x");
			Println1(buff);
			cval = cb >> 8;
			cb = cb << 8;
			cval |= cb;
			itoa(cval, buff, 16);
			Println1("\nCalculate check sum: 0x");
			Println1(buff);

			itoa(uart->cntReceive, buff, 10);
			Println1("\ndata len: ");
			Println1(buff);

			Println1("\nInput buff: ");
			for(cval=0; cval<len_bf; cval++)
			{
				itoa(input_bf[cval], buff, 16);
				if(strlen(buff) == 1)	Println1("0");
				Println1(buff);
				Println1(" ");
			}
		}
#endif
		ClearUartBuff(uart);
		return;
	}
//	uart->cntTestLine = ClockRAM.config.t11;		// reload counter for test line
	if((uart->input_buff[0] == (AddressBA103 & 0xFF)) || (uart->input_buff[0] == 0))
	{
		uart->startReg = (uart->input_buff[2]) << 8;
		uart->startReg |= uart->input_buff[3];
		uart->lenReg = (uart->input_buff[4]) << 8;
		uart->lenReg |= uart->input_buff[5];
		switch(uart->input_buff[1])
		{
			case READ_HOLD_REG:			// cmd	0x03 read register
//			Println1("\ncmd 0x03 send.");
			case READ_IN_REG:			// cmd	0x04 read register
//			Println1("\ncmd 0x04 send.");
				errcode = CheckAddress(uart->input_buff[1], uart->startReg, uart->lenReg);
				uart->output_buff[0] = AddressBA103;
				uart->output_buff[1] = uart->input_buff[1];
				uart->output_buff[2] = 0;		// bytes counter
				cb = 3;							// index output_buff data
				if(errcode == NO_ERRORS)
				{	// read BA103 registers
					for(ci=0; ci<uart->lenReg; ci++)
					{
						if((ClockRAM.config.rr == WAIT_STATE) && (((uart->startReg)+ci == 2) || ((uart->startReg)+ci == 3)))
						{		// wrn & alr answer zero
							uart->output_buff[cb++] = 0;
							uart->output_buff[cb++] = 0;
						}
						else
						{
							cval = *ptr_reg[(uart->startReg)+ci];
							uart->output_buff[cb++] = (uint8_t)((cval >> 8) & 0xFF);
							uart->output_buff[cb++] = (uint8_t)(cval & 0xFF);
						}
					}
					uart->output_buff[2] = ci << 1;
					CalculateCRC16(uart->output_buff, cb);
					UARTsend(uart, cb+2);
				}
				else
				{
					uart->output_buff[0] = AddressBA103;
					uart->output_buff[1] = uart->input_buff[1] | 0x80;
					uart->output_buff[2] = errcode;
					CalculateCRC16(uart->output_buff, 3);
					UARTsend(uart, 5);
				}
				break;

			case WRITE_ONE_REG:			// cmd	0x06
	//			Println1("\ncmd 0x06 send.");
				if(CheckAddress(WRITE_ONE_REG, uart->startReg, 1) == NO_ERRORS)
				{
					errcode = WriteRegister(uart->startReg, uart->lenReg);
				}
				if(errcode == MODBUS_OK)
				{
					uart->output_buff[0] = AddressBA103;
					uart->output_buff[1] = uart->input_buff[1];
					uart->output_buff[2] = (uart->startReg) >> 8;			// bytes to answer
					uart->output_buff[3] = uart->startReg;
					uart->output_buff[4] = (uart->lenReg) >> 8;
					uart->output_buff[5] = uart->lenReg;
					CalculateCRC16(uart->output_buff, 6);
					UARTsend(uart, 8);
				}
				else
				{
					uart->output_buff[0] = AddressBA103;
					uart->output_buff[1] = uart->input_buff[1] | 0x80;
					uart->output_buff[2] = errcode;
					CalculateCRC16(uart->output_buff, 3);
					UARTsend(uart, 5);
				}
				break;

			case LOOP_TEST:				// cmd 	0x08
	//			Println1("\ncmd 0x08 send.");
				for(ci=0; ci<uart->cntReceive; ci++)
				{
					uart->output_buff[ci] = uart->input_buff[ci];
				}
				UARTsend(uart, ci);
				break;

			case WRITE_MULTI_REG:		// cmd	0x10
	//			Println1("\ncmd 0x10 send.");
				errcode = CheckAddress(WRITE_MULTI_REG, uart->startReg, uart->lenReg);
				if(errcode == NO_ERRORS)
				{ // write BA registers
					cv = 0;		// bytes counter
					for(ci=0; ci<uart->lenReg; ci++)
					{
						cval = uart->input_buff[7+cv] << 8;
						cv++;
						cval |= uart->input_buff[7+cv];
						cv++;
						errcode = WriteRegister(uart->startReg+ci, cval);
						if(cv > uart->input_buff[6])		break;
					}
				}
				if(errcode == MODBUS_OK)
				{
					uart->output_buff[0] = AddressBA103;
					uart->output_buff[1] = uart->input_buff[1];
					uart->output_buff[2] = (uart->startReg) >> 8;
					uart->output_buff[3] = uart->startReg;
					uart->output_buff[4] = ci >> 8;
					uart->output_buff[5] = ci;
					CalculateCRC16(uart->output_buff, 6);
					UARTsend(uart, 8);
				}
				else
				{
					uart->output_buff[0] = AddressBA103;
					uart->output_buff[1] = WRITE_MULTI_REG | 0x80;
					uart->output_buff[2] = errcode;
					CalculateCRC16(uart->output_buff, 3);
					UARTsend(uart, 5);
				}
				break;

			case REPORT_ID:				// cmd	0x11
				GetReportId(uart);
				break;

	//////////////// Debug command //////////////////////////////////////////

			case TEST_CMD_0:		// cmd 0xA0, 01 a0 00 58
			// set default settings
				SetConfigDefault();
				Println1("\nrestore_default_data...");
				break;

			case TEST_CMD_1:			// cmd	0xA2
	// clear all units
#ifdef _BUS_OUTPUT_UART

#endif
					break;

			case TEST_CMD_2:			// cmd	0xA4, 01 A4 01 9B
	// read input data
				itoa(inputData, buff, 16);
				Println1("\nInput data: 0x");
				Println1(buff);
				itoa(DIO, buff, 16);
				Println1("\ndio: 0x");
				Println1(buff);
				itoa(ALR, buff, 16);
				Println1("\nalr: 0x");
				Println1(buff);
				itoa(U_input, buff, 10);
				Println1("\nInput voltage: ");
				Println1(buff);
				itoa(T_hot, buff, 10);
				Println1("\nTemperatura podachi: ");
				Println1(buff);
				Println1(" *C");
				itoa(T_cold, buff, 10);
				Println1("\nTemperatura obratki: ");
				Println1(buff);
				Println1(" *C");
				itoa(T_gor, buff, 10);
				Println1("\nTemperatura shneka podachi: ");
				Println1(buff);
				Println1(" *C");
				itoa(T_sg, buff, 10);
				Println1("\nTemperatura v topke: ");
				Println1(buff);
				Println1(" *C");
				itoa(T_vyh, buff, 10);
				Println1("\nTemperatura vyhlopa: ");
				Println1(buff);
				Println1(" *C");
				itoa(ClockRAM.config.preset, buff, 10);
				Println1("\npreset: ");
				Println1(buff);
				itoa(ClockRAM.config.srk, buff, 16);
				Println1("\nsrk: 0x");
				Println1(buff);
				break;

			case TEST_CMD_4:			// cmd	0xA8; 01 A8 00 01 41 f8
// set SIFU percent
				Unit.sifu = uart->startReg;
				if(Unit.sifu > SIFU_BEGIN_VALUE)	Unit.sifu = SIFU_BEGIN_VALUE;
				if(Unit.sifu < SIFU_START_VALUE)
				{
					Ventilator(0, SIFU_START_VALUE);
				}
				else
				{
					Ventilator(1, Unit.sifu);
				}
				if(log_debug)
				{
					Println1("\nVentilator_PWM: ");
					itoa(Unit.sifu, buff, 10);
					Println1(buff);
				}
				break;

			case TEST_CMD_5:			// cmd	0xAA, 01 AA 00 01
#ifdef _BUS_OUTPUT_UART
				// control output log
				log_debug = uart->input_buff[3];
				ClockRAM.config.log_debug_state = log_debug;
				if(log_debug)
				{
					Println1("\nDebug message ON");
				}

				else
				{
					Println1("\nDebug message OFF");
				}
#endif
			break;

			case TEST_CMD_6:			// cmd	0xAC; 01 AC 00 01 SRC
	//
				break;

			case TEST_CMD_7: // 0xAE
// client GET to server

				break;

			default:
				uart->output_buff[0] = AddressBA103;
				uart->output_buff[1] = uart->input_buff[1] | 0x80;
				uart->output_buff[2] = MODBUS_FUNCTION_NOT_SUPPORT;	// errcode command
				CalculateCRC16(uart->output_buff, 3);
				UARTsend(uart, 5);
				break;
		}
		ClearUartBuff(uart);
	}
	else
	{ // no match address
		ClearUartBuff(uart);
	}
}

void GetReportId(config_uart_t *uart)
{
	uart->output_buff[0] = AddressBA103;
	uart->output_buff[1] = REPORT_ID;
	uart->output_buff[2] = 8;		// length
	uart->output_buff[3] = '"';
	uart->output_buff[4] = 'B';
	uart->output_buff[5] = 'A';
	uart->output_buff[6] = '-';
	uart->output_buff[7] = '1';
	uart->output_buff[8] = '0';
	uart->output_buff[9] = '3';
	uart->output_buff[10] = '"';
	CalculateCRC16(uart->output_buff, 11);
	UARTsend(uart, 13);
}

uint8_t WriteRegister(uint16_t addr, uint16_t val)
{ // write register BU103
	switch(addr)
	{
		case 0x0:	// not used
		case 0x01:	// DIO
		case 0x02:	// alarms
		case 0x03:	// warnings
		case 0x04:	// srk
		case 0x05:	// rr
		case 0x07:	// DT1
		case 0x08:	// DT2
		case 0x09:	// DT3
		case 0x0A:	// DT4
		case 0x0B:	// DT5
		case 0x0E:	// Q
			return ERROR_INCORRECT_WRITING;
			break;

		case 0x06: // rc
			if(BIT_TEST(ClockRAM.config.rr, RR_BIT_REMOTE))
			{ // remote only
				if(BIT_TEST(val, RC_BIT_CLR_AVARY))
				{ // clear avary
					ClockRAM.config.alr = 0;
					ClockRAM.config.alrMemory = 0;
					ClockRAM.config.wrn = 0;
					BIT_CLR(val, RC_BIT_CLR_AVARY);
				}
				if((ClockRAM.config.srk < SRK_BITS_WORK) && BIT_TEST(val, RC_BIT_START_STOP))
				{ // on unit
					Unit.State = GO_WAIT_STATE;
				}
				if((ClockRAM.config.srk >= SRK_BITS_WORK) && !BIT_TEST(val, RC_BIT_START_STOP))
				{ // off unit
					Unit.State = GO_STOP_STATE;
				}
			}
			ClockRAM.config.rc = val;
			break;

		case 0x0C:	// TSP, T1
		case 0x0D:	// TSP, T21
			if((val < MIN_T1) || (val > MAX_T1))	return ERROR_BUS_SET_DATA;
			else									*ptr_reg[addr] = val;
			break;

		case 0x0F:	// Kp
		case 0x10:	// Ki
			*ptr_reg[addr] = val;
			break;

		case 0x11: // DTO
			if(val > MAX_t15)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x12: // ZFR
			if(val > MAX_QQ)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x13:	// t1, DTCR
			if(val > MAX_t1)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x14:	// t2, DTPP1
		case 0x15:	// t3, DTTon
		case 0x16:	// t4, DTToff
		case 0x17:	// t5, DTPCR
			if(val > MAX_t2)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x18:	// t6, DTPP2
			if(val > MAX_t6)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x19:	// T4, TTR
			if(val > MAX_T4)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x1A:	// Q4, ZFS
			if(val > MAX_QQ)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x1B:	// T5, TPH
			if((val < MIN_T5) || (val > MAX_T5))	return ERROR_BUS_SET_DATA;
			else									*ptr_reg[addr] = val;
			break;

		case 0x1C:	// t7, DTSTon
			if((val < MIN_t7) || (val > MAX_t7))	return ERROR_BUS_SET_DATA;
			else									*ptr_reg[addr] = val;
			break;

		case 0x1D:	// t8, DTSToff
			if((val < MIN_t8) || (val > MAX_t8))	return ERROR_BUS_SET_DATA;
			else									*ptr_reg[addr] = val;
			break;

		case 0x1E:	// t9, DTKon
		case 0x1F:	// t10, DTKoff
			if(val > MAX_t9)	 	return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x20:	// t11, DTSZ
			if(val > MAX_t11)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x21:	// Q2, ZFmin
		case 0x22:	// Q2, ZFmax
			if(val > MAX_QQ)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x23:	// N, ZSS2
			if((val < MIN_N1) || (val > MAX_N1))	return ERROR_BUS_SET_DATA;
			else									*ptr_reg[addr] = val;
			break;

		case 0x24:	// delta_T3, PP
			if((val < MIN_DELTA_T3) || (val > MAX_DELTA_T3))	return ERROR_BUS_SET_DATA;
			else												*ptr_reg[addr] = val;
			break;

		case 0x25:	// t12, DTVN
			if(val > MAX_t12)	return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x26:	// t13, DTSTAon
			if((val < MIN_t13) || (val > MAX_t13))	return ERROR_BUS_SET_DATA;
			else									*ptr_reg[addr] = val;
			break;

		case 0x27:	// t14, DTSTAoff
			if((val < MIN_t14) || (val > MAX_t14))	return ERROR_BUS_SET_DATA;
			else									*ptr_reg[addr] = val;
			break;

		case 0x28:	// t16, DTAKon
		case 0x29:	// t17, DTAKoff
			if(val > MAX_t16)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x2A:	// T6, TPP
			if((val < MIN_T6) || (val > MAX_T6))	return ERROR_BUS_SET_DATA;
			else									*ptr_reg[addr] = val;
			break;

		case 0x2B:	// N2, ZSZT
			if(val > MAX_N2)	return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x2C:	// delta_T1,
			if(val > MAX_DELTA_T1)		return ERROR_BUS_SET_DATA;
			else						*ptr_reg[addr] = val;
			break;

		case 0x2D:	// delta_T4,
			if(val > MAX_DELTA_T4)		return ERROR_BUS_SET_DATA;
			else						*ptr_reg[addr] = val;
			break;

		case 0x2E:	// t20, DTKMAon
		case 0x2F:	// t21, DTKMAoff
			if(val > MAX_t20)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x30:	// t25,
			if(val > MAX_t25)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x31:	// T13, TPO
			if((val < MIN_T13) || (val > MAX_T13))	return ERROR_BUS_SET_DATA;
			else									*ptr_reg[addr] = val;
			break;

		case 0x32:	// T14, TPK
			if(((int16_t)val < MIN_T14) || ((int16_t)val > MAX_T14))	return ERROR_BUS_SET_DATA;
			else														*ptr_reg[addr] = val;
			break;

		case 0x33:	// address BA
			if((val < 1) || (val > 255))	return ERROR_BUS_SET_DATA;
			else							*ptr_reg[addr] = val;
			break;

		case 0x34:	// t26,
			if(val > MAX_t26)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x35:	// Q7,
		case 0x36:	// Q8,
			if(val > MAX_QQ)		return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x37:	// T10
		case 0x38:	// T7
		case 0x39:	// T11
		case 0x3A:	// T12
		case 0x3B:	// T9
		case 0x3C:	// T8
			if(val < MAX_T10)	return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x3D:	// t24
			if(val < MAX_t24)	return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x3E:	// preset
			if(val < MAX_PRESET)	return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x3F:	// t18
			if(val < MAX_t18)	return ERROR_BUS_SET_DATA;
			else				*ptr_reg[addr] = val;
			break;

		case 0x40: // T19
			if(val != DEFAULT_T19)	return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x41: // delta_T19
			if(val != DEFAULT_DELTA_T19)	return ERROR_BUS_SET_DATA;
			else							*ptr_reg[addr] = val;
			break;

		case 0x42: // N3,
			if(val != DEFAULT_N3)	return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x43: // N4,
			if(val != DEFAULT_N4)	return ERROR_BUS_SET_DATA;
			else					*ptr_reg[addr] = val;
			break;

		case 0x44:	// N5
			if((val < MIN_N5) || (val > MAX_N5))	return ERROR_BUS_SET_DATA;
			else									*ptr_reg[addr] = val;
			break;

		case 0x45:	// t22
			if((val < MIN_t22) || (val > MAX_t22))	return ERROR_BUS_SET_DATA;
			else									*ptr_reg[addr] = val;
			break;

		case 0x46:	// t23
			if((val < MIN_t23) || (val > MAX_t23))	return ERROR_BUS_SET_DATA;
			else									*ptr_reg[addr] = val;
			break;

		default:
			return ERROR_INCORRECT_WRITING;
			break;
		}
	return NO_ERRORS;
}

uint8_t CheckAddress(uint8_t cmd, uint16_t reg, uint16_t len)
{ // test input command and range registers address, 0x80 - fail

	uint8_t res;

	res = ERROR_ADDRESS;

	if((reg > 0) && (reg < BA_REGISTERS))
	{
		if((reg + len) > BA_REGISTERS)
		{ // error check
			res = ERROR_ADDRESS;
		}
		else
		{
			switch(cmd)
			{
			case READ_HOLD_REG:
			case READ_IN_REG:
			case WRITE_ONE_COIL:
			case WRITE_ONE_REG:
			case WRITE_MULTI_REG:
				res = 0;		// 0 - ok
				break;

			default:
				res = ERROR_ADDRESS;
				break;
			}
		}
	}
	else
	{ // error check
		res = ERROR_ADDRESS;
	}

	return res;
}

void UARTsend(config_uart_t *uart, uint16_t len)
{
	switch(uart->num)
	{
	default:
		break;

	case 1:
		HAL_GPIO_WritePin(DIR1_GPIO_Port, DIR1_Pin, GPIO_PIN_SET);
		HAL_UART_Transmit(&huart1, uart->output_buff, len, UART_TIMEOUT);
		HAL_GPIO_WritePin(DIR1_GPIO_Port, DIR1_Pin, GPIO_PIN_RESET);
		break;

	case 3:
		HAL_GPIO_WritePin(DIR3_GPIO_Port, DIR3_Pin, GPIO_PIN_SET);
		HAL_UART_Transmit(&huart3, uart->output_buff, len, UART_TIMEOUT);
		HAL_GPIO_WritePin(DIR3_GPIO_Port, DIR3_Pin, GPIO_PIN_RESET);
		break;
	}
}

void SendCMDtoBA(uint8_t addr, uint8_t cmd, uint16_t reg, uint16_t len)
{ // ansver/data in smBus_buff[]
	uint16_t ci, cb;

//	memset(UART_3.input_buff, 0xFF, sizeof(UART_3.input_buff));
	switch(cmd)
	{
		case READ_HOLD_REG:			// cmd	0x03 read registers
		case READ_IN_REG:			// cmd	0x04 read registers
		case WRITE_ONE_COIL:		// cmd	0x05
		case WRITE_ONE_REG:			// cmd	0x06
		UART_3.num = 3;
		UART_3.output_buff[0] = addr;
		UART_3.output_buff[1] = cmd;
		UART_3.output_buff[2] = reg >> 8;
		UART_3.output_buff[3] = reg;
		UART_3.output_buff[4] = len >> 8;
		UART_3.output_buff[5] = len;
		CalculateCRC16(UART_3.output_buff, 6);
		UARTsend(&UART_3, 8);
		break;

		case WRITE_MULTI_REG:			// cmd	0x10
		// before write data to smBus_buff[]!!!
		UART_3.num = 3;
		UART_3.output_buff[0] = addr;
		UART_3.output_buff[1] = cmd;
		UART_3.output_buff[2] = reg >> 8;	// start register
		UART_3.output_buff[3] = reg;
		UART_3.output_buff[4] = len >> 8;	// lengh words
		UART_3.output_buff[5] = len;
		UART_3.output_buff[6] = len << 1;	// lengh bytes
		cb = 6;
		for(ci=0; ci<len; ci++)
		{
			cb++;
			UART_3.output_buff[cb] = (smBus_buff[ci] >> 8);
			cb++;
			UART_3.output_buff[cb] = (uint8_t)smBus_buff[ci];
		}
		cb++;
		CalculateCRC16(UART_3.output_buff, cb);
		cb += 2;
		UARTsend(&UART_3, cb);
		break;

		default:
		break;
	}
}

uint16_t CalculateCRC16(uint8_t * line, uint16_t len)
{
    uint8_t  j;
    uint16_t CRC16, tmp, i;

    CRC16 = 0xFFFF; // CRC - начальное значение
    for (i = 0; i < len; i++)
    {
        CRC16 ^= line[i];
        for (j = 0; j < 8; j++)
        {
            tmp = CRC16 & 0x0001;
            CRC16 >>= 1;
            if (tmp == 1)
            {
                CRC16 ^= 0xA001; // тоже или полиномиальный
            }
        }
    }
    line[i++] = (uint8_t)CRC16;
    line[i++] = (uint8_t)(CRC16 >> 8);
	return CRC16;
}



