/*
 * automat.c
 *
 *  Created on: 25 февр. 2023 г.
 *      Author: vitaly
 */

#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "adc_stm32.h"
#include "drivers.h"
#include "ba_103_bus.h"
#include "automat.h"
#include "at25df.h"

extern UART_HandleTypeDef huart1;
extern I2C_HandleTypeDef hi2c1;
extern display ledDisplay;
extern uint8_t keyboard;

void InitAutomat(void)
{
	ReadEEtoRegisters();
	IndexingRegisters();
	LoadSettings();			// load data from EEPROM
	InitInputs();
	InitState();
	InitUnit();
	alarmState_old = 0xFF;
	alarm_old = 0xFF;
	log_debug = ClockRAM.config.log_debug_state;	/// debug 1
}

void InitState(void)
{
	OffAllRelays();
	Unit.clrState = CLEAR_WAIT;
	Unit.warmDownState = WARMDOWN_WAIT;
	Unit.ignitionState = IGNITION_WAIT;
	if(BIT_TEST(ClockRAM.config.srk, SRK_BIT_AVARY))
	{ // avary state, 0PA01
		SetSRK(SRK_BIT_AVARY);
		Unit.State = GO_AVARY_STATE;
	}
	else if(BIT_TEST(ClockRAM.config.srk, SRK_BIT_STOP) || BIT_TEST(ClockRAM.config.srk, SRK_BIT_SERVICE) || BIT_TEST(ClockRAM.config.srk, SRK_BIT_CLEAR))
	{ // dejurny state, 0PS01
		SetSRK(SRK_BIT_STOP);
		Unit.State = GO_STOP_STATE;
	}
	else
	{ // wait state, 0PS02
		SetSRK(SRK_BIT_WAIT);
		Unit.State = GO_WAIT_STATE;
	}
	if(BIT_TEST(ClockRAM.config.rr, RR_BIT_CLEAR))		SetRR(RR_BIT_REMOTE);
}

void SetState(void)
{
	T1 = (uint16_t)T_hot;
	T2 = (uint16_t)T_cold;
	T3 = (uint16_t)T_gor;
	T4 = (uint16_t)T_sg;
	T5 = (uint16_t)T_vyh;

	switch(Unit.State)
	{
	case GO_STOP_STATE:  // dejurny state
		Menu.CurrMenu = CURR_AUTH;
		ledState = STATE_OFF;
		timeoutAutomat = 0;
		Unit.kolosnikCntr = KOLOSNIK_WAIT;		// kolosnik off
		Unit.podachaCntr = PODACHA_WAIT;		// podacha off
		Unit.State = STOP_STATE;
		SetSRK(SRK_BIT_STOP);
		OffAllRelays();
		Beep(BEEP_PULSE_3);
		break;

	case STOP_STATE:
		Menu.CurrMenu = CURR_AUTH;
		break;

	case GO_WAIT_STATE:
		Menu.CurrMenu = RUN_MENU;
		Menu.RunMenu = RUN_ACTIVE;
		Unit.State = WAIT_STATE_TIMEOUT;
		Unit.t15_cnt = ClockRAM.config.t15;
		if(BIT_TEST(ClockRAM.config.rr, RR_BIT_REMOTE))		ustPodachi = ClockRAM.config.T21;
		else												ustPodachi = ClockRAM.config.T1;
		SetSRK(SRK_BIT_WAIT);
		OffAllRelays();
		Beep(BEEP_PULSE_3);
		break;

	case WAIT_STATE_TIMEOUT:
		if(Unit.t15_cnt == 0)		Unit.State = WAIT_STATE;
		break;

	case WAIT_STATE:
		if((ClockRAM.config.flagAvary & ALR_DT1_MASK) || (ClockRAM.config.alr & ALR_DT1_MASK) || (ClockRAM.config.alrMemory & ALR_DT1_MASK))
		{

		}
		else
		{
			if((T_hot <= (ustPodachi - ClockRAM.config.delta_T1)) && (BIT_TEST(ClockRAM.config.wrn, WRN_BIT_PODACHA) == 0) && (BIT_TEST(ClockRAM.config.wrn, WRN_BIT_FROZE) == 0))  //
			{ // zapros na teplo
				Unit.State = GO_IGNITION_STATE;
			}
		}
		break;

	case GO_IGNITION_STATE:
		BIT_CLR(ClockRAM.config.wrn, WRN_BIT_HOT_DOWN);
		Unit.State = IGNITION_STATE;		// on Unit;
		Unit.ignitionState = BEGIN_IGNITION;
		break;

	case IGNITION_STATE:
		if((T_sg >= ClockRAM.config.T4) || (T_vyh >= ClockRAM.config.T4) || (Unit.keyIgnition == 2))
		{
			Unit.ignitionState = END_IGNITION;
		}
		break;

	case GO_STABLE_STATE:
		Relays(RELAY_HEATER, 0);
		Relays(RELAY_SHNEK2, 1);  // dop.podacha on
		Ventilator(1, ClockRAM.config.Q4);
		Unit.kolosnikCntr = KOLOSNIK_RUN;
		Unit.podachaCntr = PODACHA_RUN;
		SetSRK(SRK_BIT_STABLE);
		Unit.State = STABLE_STATE;
		break;

	case STABLE_STATE:
		if((ClockRAM.config.flagAvary & ALR_DT1_MASK) || (ClockRAM.config.alr & ALR_DT1_MASK) || (ClockRAM.config.alrMemory & ALR_DT1_MASK))
		{

		}
		else
		{
			if(T_hot >= ClockRAM.config.T5)
			{
				Relays(RELAY_PUMP, 1);
				Unit.State = GO_WORK_STATE;
			}
		}
		break;

	case GO_WORK_STATE:
	    Menu.CurrMenu = RUN_MENU;
	    Menu.RunMenu = RUN_MENU_MIN;
	    Unit.kolosnikCntr = KOLOSNIK_RUN;
	    Unit.podachaCntr = PODACHA_RUN;
	    Relays(RELAY_HEATER, 0);  // TEH off
	    Relays(RELAY_PUMP, 1);	  // nasos on
	    Relays(RELAY_SHNEK2, 1);  // dop.podacha on
	    SetSRK(SRK_BIT_WORK);
	    ClearMismatch();
	    Unit.State = WORK_STATE;
		break;

	case WORK_STATE:
		if(Unit.periodPI)			Unit.periodPI--;
		if(Unit.periodPI == 0)
		{
			Unit.periodPI = PERIOD_PI;
			PIpower();
			CalculatePI();
		}
		break;

	case WARMDOWN_STATE:

		break;

	case GO_AVARY_STATE:
		Menu.CurrMenu = AVARY_MENU;
		Unit.State = AVARY_STATE;
		Unit.kolosnikCntr = KOLOSNIK_STOP;
		Unit.zolodelCntr = ZOLODEL_STOP;
		Unit.podachaCntr = PODACHA_STOP;
		Ventilator(0, 0);
		Relays(RELAY_HEATER, 0);
		SetSRK(SRK_BIT_AVARY);
		cntDisplayAvary = GetCntDisplayAvary(DISPLAY_AVARY_MIN, 1);
		DisplayAvary(cntDisplayAvary);
		break;

	case AVARY_STATE:
		if((ClockRAM.config.alr == 0) && (ClockRAM.config.alrMemory == 0))
		{
			Unit.State = GO_WAIT_STATE;
		}
		if(BIT_TEST(ClockRAM.config.wrn, WRN_BIT_SHNECK) || BIT_TEST(ClockRAM.config.alr, ALR_BIT_SHNECK))		Shneck.state = SHNECK_COOL;
		break;

	default:
		break;
	}
	if((ClockRAM.config.alr || ClockRAM.config.alrMemory) && (Unit.State != AVARY_STATE))
	{
		Unit.State = GO_AVARY_STATE;
	}
}

void PIpower(void)
{
	int32_t pwr;
	float   valP;
	float   valI;
	int32_t mismatchSum;
	uint8_t  ci;

	Unit.mismatchPI[Unit.mismatchCnt] = ustPodachi - T_hot;
	mismatchSum = 0;
	for(ci=0; ci<MISMATCH_PI_ARR_LEN; ci++)
	{
		mismatchSum += Unit.mismatchPI[ci];
	}
	valP = ClockRAM.config.Kp;
	valP = Unit.mismatchPI[Unit.mismatchCnt] / valP;
	valI = ClockRAM.config.Ki;
	valI = mismatchSum / valI;
	pwr = (int32_t)(valP + valI);
	if(pwr > MAX_QQ)		Unit.sifu = MAX_QQ;
	else if(pwr < MIN_QQ)	Unit.sifu = MIN_QQ;
	else					Unit.sifu = pwr;
	Unit.mismatchCnt++;
	if(Unit.mismatchCnt >= MISMATCH_PI_ARR_LEN)		Unit.mismatchCnt = 0;
}

void ClearMismatch(void)
{
	memset(Unit.mismatchPI, 0, sizeof(Unit.mismatchPI));
	Unit.mismatchCnt = 0;
}

void CalculatePI(void)
{// calculate times for Unit.kolosnikOnPI, Unit.kolosnikOffPI, Unit.podachaOnPI, Unit.podachaOffPI
	float tmpRez;

	Unit.Regim = 0;
	if(BIT_TEST(ClockRAM.config.rc, RC_BIT_PCONST_0))	BIT_SET(Unit.Regim, 0);
	if(BIT_TEST(ClockRAM.config.rc, RC_BIT_PCONST_1))	BIT_SET(Unit.Regim, 1);
	switch(Unit.Regim)
	{
	case 0:
	case 3:
	default:  // PI-regulate mode, // (t_max - t_min) * sifuPercent / 100
		Ventilator(1, Unit.sifu);
		tmpRez = Unit.sifu / 100;
		tmpRez = tmpRez * (ClockRAM.config.t9 - ClockRAM.config.t20);
		Unit.kolosnikOnPI = (uint16_t)tmpRez;
		tmpRez = Unit.sifu / 100;
		tmpRez = tmpRez * (ClockRAM.config.t10 - ClockRAM.config.t21);
		Unit.kolosnikOffPI = (uint16_t)tmpRez;
		tmpRez = Unit.sifu / 100;
		tmpRez = tmpRez * (ClockRAM.config.t7 - ClockRAM.config.t22);
		Unit.podachaOnPI = (uint16_t)tmpRez;
		tmpRez = Unit.sifu / 100;
		tmpRez = tmpRez * (ClockRAM.config.t8 - ClockRAM.config.t23);
		Unit.podachaOffPI = (uint16_t)tmpRez;
		break;

	case 1:  // P-nominal mode
		Ventilator(1, ClockRAM.config.Q7);
		break;

	case 2: // P-min mode
		Ventilator(1, ClockRAM.config.Q8);
		break;
	}
}

void Ignition(void)
{
	float tmpf;

	if(Unit.t1_cnt)			Unit.t1_cnt--;
	if(Unit.t2_cnt)			Unit.t2_cnt--;
	switch(Unit.ignitionState)
	{
	case BEGIN_IGNITION:  // 1
		Unit.zolodelCntr = ZOLODEL_STOP;
		Unit.kolosnikCntr = KOLOSNIK_STOP;
		Relays(RELAY_SHNEK2, 1);		// dop. podacha on
		SetSRK(SRK_BIT_IGNITION);
		Unit.keyIgnition = 0;  // 0-no press, 1-short press, 2-long press
		Unit.ignitionState++;
		break;

	case 2:  //
		Unit.t2_cnt = ClockRAM.config.t2;
		Relays(RELAY_SHNEK1, 1);		// podacha on
		if(BIT_TEST(ClockRAM.config.rc, RC_BIT_AUTO_IGNITION))
		{
			Unit.t1_cnt = ClockRAM.config.t1;
			Unit.ignitionState++;
		}
		else	Unit.ignitionState = MANUAL_IGNITION;
		break;

	case IGNITION_CYCLE_ONE:  // 3  // 1st cycle
		if(Unit.t1_cnt == 0)	Unit.ignitionState = IGNITION_CYCLE_TWO;
		if(Unit.t2_cnt == 0)
		{
			Ventilator(1, ClockRAM.config.Q1);  // podduff on
			Unit.t2_cnt = ClockRAM.config.t3;
			Relays(RELAY_HEATER, 1);		// TEH on
			Relays(RELAY_SHNEK1, 0);		// podacha off
			Unit.ignitionState++;
		}
		break;

	case 4:
		if(Unit.t1_cnt == 0)	Unit.ignitionState = IGNITION_CYCLE_TWO;
		if(Unit.t2_cnt == 0)
		{
			Unit.t2_cnt = ClockRAM.config.t4;
			Relays(RELAY_HEATER, 0);		// TEH off
			Unit.ignitionState++;
		}
		break;

	case 5:
		if(Unit.t1_cnt == 0)	Unit.ignitionState++;
		if(Unit.t2_cnt == 0)	Unit.ignitionState = IGNITION_CYCLE_ONE;
		break;

	case 6:  // 6
		Ventilator(1, 0);  // podduff off
		Unit.t2_cnt = ClockRAM.config.t5;  // pause
		Unit.ignitionState++;
		break;

	case 7:  // 7
		if(Unit.t2_cnt == 0)
		{
			Unit.t1_cnt = ClockRAM.config.t1;
			Unit.t2_cnt = ClockRAM.config.t6;
			Relays(RELAY_SHNEK1, 1);		// podacha on
			Unit.ignitionState++;
		}
		break;

	case IGNITION_CYCLE_TWO:  // 8, 2st cycle
		if(Unit.t1_cnt == 0)	Unit.ignitionState = FAIL_IGNITION;
		if(Unit.t2_cnt == 0)
		{
			Ventilator(1, ClockRAM.config.Q1);  // podduff on
			Unit.t2_cnt = ClockRAM.config.t3;
			Relays(RELAY_HEATER, 1);		// TEH on
			Relays(RELAY_SHNEK1, 0);		// podacha off
			Unit.ignitionState++;
		}
		break;

	case 9:
		if(Unit.t1_cnt == 0)	Unit.ignitionState = FAIL_IGNITION;
		if(Unit.t2_cnt == 0)
		{
			Unit.t2_cnt = ClockRAM.config.t4;
			Relays(RELAY_HEATER, 0);		// TEH off
			Unit.ignitionState++;
		}
		break;

	case 10:
		if(Unit.t1_cnt == 0)	Unit.ignitionState = FAIL_IGNITION;
		if(Unit.t2_cnt == 0)	Unit.ignitionState = IGNITION_CYCLE_TWO;
		break;

	case MANUAL_IGNITION:  // 15
		if(Unit.t2_cnt == 0)
		{
			Relays(RELAY_SHNEK1, 0);		// podacha off
			Unit.ignitionState++;
		}
		break;

	case MANUAL_IGNITION+1:  // 16, wait short esc.
		if(Unit.keyIgnition == 1)		Unit.ignitionState++;
		break;

	case MANUAL_IGNITION+2:  // 17
		tmpSifu = SIFU_MINIMAL_VALUE;
		Ventilator(1, SIFU_MINIMAL_VALUE);
		Unit.t2_cnt = ClockRAM.config.t25;
		Unit.ignitionState++;
		break;

	case MANUAL_IGNITION+3:  // 18
		tmpf = ClockRAM.config.Q1 - SIFU_MINIMAL_VALUE;
		tmpf = tmpf / ClockRAM.config.t25;
		tmpSifu += tmpf;
		if((uint32_t)tmpSifu > ClockRAM.config.Q1)	Unit.sifu = ClockRAM.config.Q1;
		else										Unit.sifu = (uint32_t)tmpSifu;
		Ventilator(1, Unit.sifu);
		if(Unit.t2_cnt == 0)
		{
			Ventilator(1, ClockRAM.config.Q1);
			Unit.ignitionState++;  // wait long press esc.
		}
		break;

	case MANUAL_IGNITION+4:  // 19 // wait long press esc.
		if(Unit.keyIgnition == 2)		Unit.ignitionState = END_IGNITION;
		break;

	case END_IGNITION:	// 20
		Unit.State = GO_STABLE_STATE;
		Unit.ignitionState = IGNITION_WAIT;
		break;

	case FAIL_IGNITION:  // 25,  // Avary8();
		Ventilator(1, 0);  // podduff off
		BIT_SET(ClockRAM.config.flagAvary, ALR_BIT_IGNITION);
		Unit.ignitionState = IGNITION_WAIT;
		UnitOff(PUMP_RUN_OFF, SHNECK_COOL_OFF);		// off unit
		break;

	default:
	case IGNITION_WAIT:  // 0
		break;
	}
}

void Clearing(void)
{
	switch(Unit.clrState)
	{
	default:
	case CLEAR_WAIT: // 0
		break;

	case BEGIN_CLEAR: // 1
		SetSRK(SRK_BIT_CLEAR);
		Unit.State = CLEAR_STATE;
		OffAllRelays();
		Unit.clrState++;
		break;

	case 2:
		Relays(RELAY_SHNEK2, 1);	// dop.podacha on
		Relays(RELAY_SHNEK3, 1);	// zolo del on
		Unit.clrState++;
		break;

	case 3:
		break;

	case END_CLEAR: // 10
		Unit.State = GO_WAIT_STATE;
		Unit.clrState = CLEAR_WAIT;
		break;
	}
}

void WarmDown(void)
{ // run warming down -> Unit.warmDownState = BEGIN_WARMDOWN;
	if(Unit.t18_cnt)		Unit.t18_cnt--;
	switch(Unit.warmDownState)
	{
	case BEGIN_WARMDOWN:  // 1
		BIT_CLR(ClockRAM.config.wrn, WRN_BIT_HOT_DOWN);
		Ventilator(0, 0);
		Relays(RELAY_HEATER, 0);
		Unit.State = WARMDOWN_STATE;
		Unit.ignitionState = IGNITION_WAIT;
		SetSRK(SRK_BIT_WARMDOWN);
		Unit.warmDownState++;
		break;

	case 2:
		Relays(RELAY_SHNEK1, 1);	// on podacha
		Unit.cycleKolosnik = ClockRAM.config.N2;
		Unit.t18_cnt = ClockRAM.config.t18;
		Unit.warmDownState++;
		break;

	case 3:
		if(Unit.t18_cnt == 0)
		{
			Relays(RELAY_SHNEK2, 1);		// on dop. podacha
			if(BIT_TEST(ClockRAM.config.rc, RC_BIT_ON_KOLOSNIK))	Unit.warmDownState++;
			else													Unit.warmDownState = 7;
		}
		break;

	case 4:
		Relays(RELAY_KOLOSNIK_ON, 1);   // slojenny kolosnyk
		Relays(RELAY_KOLOSNIK_OFF, 0);
		Unit.t18_cnt = ClockRAM.config.t16;
		Unit.warmDownState++;
		break;

	case 5:
		if(Unit.t18_cnt == 0)
		{
			Relays(RELAY_KOLOSNIK_OFF, 1);   // razlojenny kolosnyk
			Relays(RELAY_KOLOSNIK_ON, 0);
			Unit.t18_cnt = ClockRAM.config.t17;
			Unit.warmDownState++;
		}
		break;

	case 6:
		if(Unit.t18_cnt == 0)
		{
			Relays(RELAY_KOLOSNIK_OFF, 0);   // kolosnyki off
			Relays(RELAY_KOLOSNIK_ON, 0);
			if(Unit.cycleKolosnik)			Unit.cycleKolosnik--;
			if(Unit.cycleKolosnik == 0)		Unit.warmDownState++;
			else							Unit.warmDownState = 4;
		}
		break;

	case 7:
		Relays(RELAY_SHNEK3, 1);	// zolo del on
		Unit.t18_cnt = ClockRAM.config.t11;
		Unit.warmDownState++;
		break;

	case 8:
		if(Unit.t18_cnt == 0)	Unit.warmDownState = END_WARMDOWN;
		break;

	case END_WARMDOWN:  // 10
		if(ClockRAM.config.flagAvary)
		{
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_PODACHA))			BIT_SET(ClockRAM.config.alr, ALR_BIT_PODACHA);   		// 0
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SHNECK))				BIT_SET(ClockRAM.config.alr, ALR_BIT_SHNECK);    		// 1
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_PROTOK))				BIT_SET(ClockRAM.config.alr, ALR_BIT_PROTOK);	 		// 2
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_PODACHA))		BIT_SET(ClockRAM.config.alr, ALR_BIT_SENSOR_PODACHA);   // 3
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_PODACHA2))	BIT_SET(ClockRAM.config.alr, ALR_BIT_SENSOR_PODACHA2);  // 4
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_SHNECK))		BIT_SET(ClockRAM.config.alr, ALR_BIT_SENSOR_SHNECK);	// 5
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_SHNECK2))		BIT_SET(ClockRAM.config.alr, ALR_BIT_SENSOR_SHNECK2);	// 6
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_IGNITION))			BIT_SET(ClockRAM.config.alr, ALR_BIT_IGNITION);		    // 7
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_NO_PROTOK))			BIT_SET(ClockRAM.config.alr, ALR_BIT_NO_PROTOK);		// 8
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_OPEN_HOT))			BIT_SET(ClockRAM.config.alr, ALR_BIT_OPEN_HOT);			// 9
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SHORT_HOT))			BIT_SET(ClockRAM.config.alr, ALR_BIT_SHORT_HOT);		// 10
			Unit.State = GO_AVARY_STATE;
		}
		Unit.warmDownState = WARMDOWN_WAIT;
		break;

	default:
	case WARMDOWN_WAIT:
		break;
	}
}

void SetConfigDefault(void)
{
//		memset(ClockRAM.data8, 0, RAM_CONFIG_LEN_BYTES);
	ClockRAM.config.version = CURRENT_VERSION;
	ClockRAM.config.addr = BA103_ADDR;
	ClockRAM.config.alr = 0;
	ClockRAM.config.alrMemory = 0;
	ClockRAM.config.wrn = 0;
	ClockRAM.config.rr = RR_LOCAL;
	ClockRAM.config.rc = RC_DEFAULT;
	ClockRAM.config.srk = WAIT_STATE;
	ClockRAM.config.t1 = DEFAULT_t1;
	ClockRAM.config.t2 = DEFAULT_t2;
	ClockRAM.config.t3 = DEFAULT_t2;
	ClockRAM.config.t4 = DEFAULT_t4;
	ClockRAM.config.t5 = DEFAULT_t2;
	ClockRAM.config.t6 = DEFAULT_t6;
	ClockRAM.config.t10 = DEFAULT_t10;
	ClockRAM.config.t12 = DEFAULT_t12;
	ClockRAM.config.t13 = DEFAULT_t13;
	ClockRAM.config.t14 = DEFAULT_t14;
	ClockRAM.config.t15 = DEFAULT_t15;
	ClockRAM.config.t16 = DEFAULT_t16;
	ClockRAM.config.t17 = DEFAULT_t17;
	ClockRAM.config.t18 = DEFAULT_t18;
	ClockRAM.config.T4 = DEFAULT_T4;
	ClockRAM.config.T5 = DEFAULT_T5;
	ClockRAM.config.T6 = DEFAULT_T6;
	ClockRAM.config.T7 = DEFAULT_T7;
	ClockRAM.config.T8 = DEFAULT_T8;
	ClockRAM.config.T9 = DEFAULT_T9;
	ClockRAM.config.T10 = DEFAULT_T10;
	ClockRAM.config.T11 = DEFAULT_T11;
	ClockRAM.config.T12 = DEFAULT_T12;
	ClockRAM.config.T13 = NTC_SENSOR_OPEN;
	ClockRAM.config.T14 = NTC_SENSOR_SHORT;
	ClockRAM.config.N2 = DEFAULT_N2;
	ClockRAM.config.N3 = DEFAULT_N3;
	ClockRAM.config.N4 = DEFAULT_N4;
	ClockRAM.config.N5 = DEFAULT_N5;
	ClockRAM.config.Q1 = DEFAULT_Q1;
	ClockRAM.config.Q4 = DEFAULT_Q4;
	ClockRAM.config.delta_T1 = DEFAULT_DELTA_T1;
	ClockRAM.config.delta_T4 = DEFAULT_DELTA_T4;
	ClockRAM.config.delta_T19 = DEFAULT_DELTA_T19;
	ClockRAM.config.preset = DEFAULT_PRESET;

	RefreshEEpromData();	// write data to EEPROM memory

	ClockRAM.config.t7 = DEFAULT_t7;
	ClockRAM.config.t8 = DEFAULT_t8;
	ClockRAM.config.t22 = DEFAULT_t7;
	ClockRAM.config.t23 = DEFAULT_t8;
	ClockRAM.config.T1 = DEFAULT_T1;
	ClockRAM.config.T21 = DEFAULT_T1;
	ClockRAM.config.t9 = DEFAULT_t9;
	ClockRAM.config.t20 = DEFAULT_t20;
	ClockRAM.config.t21 = DEFAULT_t21;
	ClockRAM.config.t11 = DEFAULT_t11;
	ClockRAM.config.Q2 = DEFAULT_Q2;
	ClockRAM.config.Q3 = DEFAULT_Q3;
	ClockRAM.config.N1 = DEFAULT_N1;
	ClockRAM.config.Ki = DEFAULT_KI;
	ClockRAM.config.Kp = DEFAULT_KP;
	ClockRAM.config.t24 = DEFAULT_t24;
	ClockRAM.config.delta_T3 = DEFAULT_DELTA_T3;
	ClockRAM.config.Q7 = DEFAULT_Q7;
	ClockRAM.config.Q8 = DEFAULT_Q7;

	RefreshEEpromPreset(PR0_ADDR);	// write data to EEPROM memory
}

void ReadEEtoRegisters(void)
{ // reading bytes from EEPROM to ClockRAM.config structure
	cntEeRamAddr = 0;
	cntPresetAddr = 0;
	cntDebugAddr = 0;

	ReadEEtoRAM(START_ADDR, ClockRAM.data8, PARAMS_LEN); //	ReadEEtoRAM param
	ReadEEtoRAM(DEBUG_EE_ADDR, ClockRAM.data8+PARAMS_LEN+PRESET_LEN, DEBUG_LEN); //	ReadEEtoRAM debug

	if(ClockRAM.config.version == 0xFFFF)
	{
		SetConfigDefault(); // load params and preset 0 (default)
		defPRaddr = PR0_ADDR;
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println1("\nrestore_data_default, preset_0_default");
		}
#endif
	}
	else
	{
		defPRaddr = GetPresetAddr(ClockRAM.config.preset);
		if(ClockRAM.config.version != CURRENT_VERSION)
		{
			ClockRAM.config.version = CURRENT_VERSION;
			RefreshEEpromData();	// write data to EEPROM memory
		}
		ReadEEtoRAM(defPRaddr, ClockRAM.data8+PARAMS_LEN, PRESET_LEN); //	ReadEEtoRAM preset
		CheckReadData();
	}
}

void RefreshEEpromData(void)
{ // writing data to EEPROM memory, params only
	WriteRAMtoEE(START_ADDR, ClockRAM.data8, PARAMS_LEN);
}

void RefreshEEpromPreset(uint16_t addr)
{ // writing data to EEPROM memory, current preset only
	WriteRAMtoEE(addr, ClockRAM.data8+PARAMS_LEN, PRESET_LEN);
}

void RefreshEEpromDebug(uint16_t addr)
{ // writing data to EEPROM memory, debug only
	WriteRAMtoEE(addr, ClockRAM.data8+PARAMS_LEN+PRESET_LEN, DEBUG_LEN);
}

void CheckReadData(void)
{
	if(ClockRAM.config.addr > 0x00FF)		ClockRAM.config.addr = BA103_ADDR;
	if(ClockRAM.config.rr == 0xFFFF)		ClockRAM.config.rr = RR_LOCAL;
	if(ClockRAM.config.srk == 0xFFFF)		ClockRAM.config.srk = WAIT_STATE;
	if(ClockRAM.config.preset > MAX_PRESET) ClockRAM.config.preset = DEFAULT_PRESET;
	if(ClockRAM.config.t1 > MAX_t1)			ClockRAM.config.t1 = DEFAULT_t1;
	if(ClockRAM.config.t2 > MAX_t2)			ClockRAM.config.t2 = DEFAULT_t2;
	if(ClockRAM.config.t3 > MAX_t3)			ClockRAM.config.t3 = DEFAULT_t3;
	if(ClockRAM.config.t4 > MAX_t4)			ClockRAM.config.t4 = DEFAULT_t4;
	if(ClockRAM.config.t5 > MAX_t5)			ClockRAM.config.t5 = DEFAULT_t5;
	if(ClockRAM.config.t6 > MAX_t6)			ClockRAM.config.t6 = DEFAULT_t6;
	if(ClockRAM.config.t7 > MAX_t7)			ClockRAM.config.t7 = DEFAULT_t7;		// preset 1
	if(ClockRAM.config.t7 < MIN_t7)			ClockRAM.config.t7 = DEFAULT_t7;		// preset 1
	if(ClockRAM.config.t8 > MAX_t8)			ClockRAM.config.t8 = DEFAULT_t8;		// preset 2
	if(ClockRAM.config.t8 < MIN_t8)			ClockRAM.config.t8 = DEFAULT_t8;		// preset 2
	if(ClockRAM.config.t9 > MAX_t9)			ClockRAM.config.t9 = DEFAULT_t9;		// preset 7
	if(ClockRAM.config.t10 > MAX_t10)		ClockRAM.config.t10 = DEFAULT_t10;
	if(ClockRAM.config.t11 > MAX_t11)		ClockRAM.config.t11 = DEFAULT_t11;		// preset 10
	if(ClockRAM.config.t12 > MAX_t12)		ClockRAM.config.t12 = DEFAULT_t12;
	if(ClockRAM.config.t13 > MAX_t13)		ClockRAM.config.t13 = DEFAULT_t13;
	if(ClockRAM.config.t13 < MIN_t13)		ClockRAM.config.t13 = DEFAULT_t13;
	if(ClockRAM.config.t14 > MAX_t14)		ClockRAM.config.t14 = DEFAULT_t14;
	if(ClockRAM.config.t14 < MIN_t14)		ClockRAM.config.t14 = DEFAULT_t14;
	if(ClockRAM.config.t15 > MAX_t15)		ClockRAM.config.t15 = DEFAULT_t15;
	if(ClockRAM.config.t16 > MAX_t16)		ClockRAM.config.t16 = DEFAULT_t16;
	if(ClockRAM.config.t17 > MAX_t17)		ClockRAM.config.t17 = DEFAULT_t17;
	if(ClockRAM.config.t18 > MAX_t18)		ClockRAM.config.t18 = DEFAULT_t18;
	if(ClockRAM.config.t20 > MAX_t20)		ClockRAM.config.t20 = DEFAULT_t20;		// preset 8
	if(ClockRAM.config.t21 > MAX_t21)		ClockRAM.config.t21 = DEFAULT_t21;		// preset 9
	if(ClockRAM.config.t22 > MAX_t22)		ClockRAM.config.t22 = DEFAULT_t22;		// preset 3
	if(ClockRAM.config.t22 < MIN_t22)		ClockRAM.config.t22 = DEFAULT_t22;		// preset 3
	if(ClockRAM.config.t23 > MAX_t23)		ClockRAM.config.t23 = DEFAULT_t23;		// preset 4
	if(ClockRAM.config.t23 < MIN_t23)		ClockRAM.config.t23 = DEFAULT_t23;		// preset 4
	if(ClockRAM.config.t24 > MAX_t24)		ClockRAM.config.t24 = DEFAULT_t24;		// preset 16
	if(ClockRAM.config.t25 > MAX_t25)		ClockRAM.config.t25 = DEFAULT_t25;
	if(ClockRAM.config.t26 > MAX_t26)		ClockRAM.config.t26 = DEFAULT_t26;
	if(ClockRAM.config.T1 > MAX_T1)			ClockRAM.config.T1 = DEFAULT_T1;		// preset 5
	if(ClockRAM.config.T1 < MIN_T1)			ClockRAM.config.T1 = DEFAULT_T1;		// preset 5
	if(ClockRAM.config.T4 > MAX_T4)			ClockRAM.config.T4 = DEFAULT_T4;
	if(ClockRAM.config.T5 > MAX_T5)			ClockRAM.config.T5 = DEFAULT_T5;
	if(ClockRAM.config.T5 < MIN_T5)			ClockRAM.config.T5 = DEFAULT_T5;
	if(ClockRAM.config.T6 > MAX_T6)			ClockRAM.config.T6 = DEFAULT_T6;
	if(ClockRAM.config.T6 < MIN_T6)			ClockRAM.config.T6 = DEFAULT_T6;
	if(ClockRAM.config.T7 > MAX_T7)			ClockRAM.config.T7 = DEFAULT_T7;
	if(ClockRAM.config.T8 > MAX_T8)			ClockRAM.config.T8 = DEFAULT_T8;
	if(ClockRAM.config.T9 > MAX_T9)			ClockRAM.config.T9 = DEFAULT_T9;
	if(ClockRAM.config.T10 > MAX_T10)		ClockRAM.config.T10 = DEFAULT_T10;
	if(ClockRAM.config.T11 > MAX_T11)		ClockRAM.config.T11 = DEFAULT_T11;
	if(ClockRAM.config.T12 > MAX_T12)		ClockRAM.config.T12 = DEFAULT_T12;
	if(ClockRAM.config.T13 > MAX_T13)		ClockRAM.config.T13 = DEFAULT_T13;
	if(ClockRAM.config.T13 < MIN_T13)		ClockRAM.config.T13 = DEFAULT_T13;
	if((int16_t)ClockRAM.config.T14 > (int16_t)MAX_T14)		ClockRAM.config.T14 = (uint16_t)DEFAULT_T14;
	if((int16_t)ClockRAM.config.T14 < (int16_t)MIN_T14)		ClockRAM.config.T14 = (uint16_t)DEFAULT_T14;
	ClockRAM.config.T19 = DEFAULT_T19;	// 5 - const
	if(ClockRAM.config.T21 > MAX_T1)		ClockRAM.config.T21 = DEFAULT_T1;		// preset 6
	if(ClockRAM.config.T21 < MIN_T1)		ClockRAM.config.T21 = DEFAULT_T1;		// preset 6
	if(ClockRAM.config.N1 > MAX_N1)			ClockRAM.config.N1 = DEFAULT_N1;		// preset 13
	if(ClockRAM.config.N1 < MIN_N1)			ClockRAM.config.N1 = DEFAULT_N1;		// preset 13
	if(ClockRAM.config.N2 > MAX_N2)			ClockRAM.config.N2 = DEFAULT_N2;
	ClockRAM.config.N3 = DEFAULT_N3;				// 2 - const
	ClockRAM.config.N4 = DEFAULT_N4;				// 5 - const
	if(ClockRAM.config.N5 > MAX_N5)			ClockRAM.config.N5 = DEFAULT_N5;
	if(ClockRAM.config.N5 < MIN_N5)			ClockRAM.config.N5 = DEFAULT_N5;
	if(ClockRAM.config.Q1 > MAX_QQ)			ClockRAM.config.Q1 = DEFAULT_Q1;
	if(ClockRAM.config.Q2 > MAX_QQ)			ClockRAM.config.Q2 = DEFAULT_Q2;		// preset 11
	if(ClockRAM.config.Q3 > MAX_QQ)			ClockRAM.config.Q3 = DEFAULT_Q3;		// preset 12
	if(ClockRAM.config.Q4 > MAX_QQ)			ClockRAM.config.Q4 = DEFAULT_Q4;
	if(ClockRAM.config.Q7 > MAX_QQ)			ClockRAM.config.Q7 = DEFAULT_Q7;		// preset 18
	if(ClockRAM.config.Q8 > MAX_QQ)			ClockRAM.config.Q8 = DEFAULT_Q7;		// preset 19
	if(ClockRAM.config.delta_T1 > MAX_DELTA_T1)	ClockRAM.config.delta_T1 = DEFAULT_DELTA_T1;
	if(ClockRAM.config.delta_T3 > MAX_DELTA_T3)	ClockRAM.config.delta_T3 = DEFAULT_DELTA_T3;	// preset 17
	if(ClockRAM.config.delta_T3 < MIN_DELTA_T3)	ClockRAM.config.delta_T3 = DEFAULT_DELTA_T3;	// preset 17
	if(ClockRAM.config.delta_T4 > MAX_DELTA_T4)	ClockRAM.config.delta_T4 = DEFAULT_DELTA_T4;
	ClockRAM.config.delta_T19 = DEFAULT_DELTA_T19;	// 2 - const
}

void RunMenu(void)
{
	rm_counter++;
	switch(Menu.CurrMenu)
	{
		default:
		case CURR_AUTH:
		ledRegim = REGIM_OFF;
		ledState = STATE_OFF;
		memcpy(strDisp, "---", sizeof(strDisp));
		if(Unit.State == STOP_STATE)	ledFlash = FLASH_OFF;
		else							ledFlash = FLASH_DIGIT;
		break;

		case AVARY_MENU:
		cntDisplayAvary = GetCntDisplayAvary(cntDisplayAvary, 0);
		DisplayAvary(cntDisplayAvary);
		break;

		case RUN_MENU:
		DispRunMenu();
		switch(Menu.RunMenu)
		{
			case RUN_ACTIVE:
			if(T_hot < T_HOT_IND_MIN)		memcpy(strDisp, ToDisplay(T_HOT_IND_MIN), sizeof(strDisp));
			else if(T_hot > T_HOT_IND_MAX)	memcpy(strDisp, ToDisplay(T_HOT_IND_MAX), sizeof(strDisp));
			else							memcpy(strDisp, ToDisplay(T_hot), sizeof(strDisp));
			break;

			case RUN_SET_UST:
			memcpy(strDisp, ToDisplay(ClockRAM.config.T1), sizeof(strDisp));
			break;

		    case RUN_SET_MODE:
		    if(BIT_TEST(ClockRAM.config.rr, RR_BIT_REMOTE))			memcpy(strDisp, "P_Y", sizeof(strDisp));
		    else if(BIT_TEST(ClockRAM.config.rr, RR_BIT_LOCAL))		memcpy(strDisp, "P_A", sizeof(strDisp));
		    else if(BIT_TEST(ClockRAM.config.rr, RR_BIT_CLEAR))		memcpy(strDisp, "P_C", sizeof(strDisp));
		    else													memcpy(strDisp, "P_H", sizeof(strDisp));
		    break;

			case RUN_SET_ADDR:
			memcpy(strDisp, ToDisplay(ClockRAM.config.addr), sizeof(strDisp));
			break;

		    default:
		    break;
		}
		break;

		case SUB_RUN_MENU:
		switch(Menu.RunMenu)
		{
			default:
			break;

			case RUN_ACTIVE:
			Menu.CurrMenu = RUN_MENU;
			break;

			case RUN_SET_UST:
			memcpy(strDisp, ToDisplay(ClockRAM.config.T1), sizeof(strDisp));
			ledFlash = FLASH_DIGIT;
			break;

			case RUN_SET_MODE:
			ledFlash = FLASH_DIGIT;
		    if(BIT_TEST(ClockRAM.config.rr, RR_BIT_REMOTE))			memcpy(strDisp, "P_Y", sizeof(strDisp));
		    else if(BIT_TEST(ClockRAM.config.rr, RR_BIT_LOCAL))		memcpy(strDisp, "P_A", sizeof(strDisp));
		    else if(BIT_TEST(ClockRAM.config.rr, RR_BIT_CLEAR))		memcpy(strDisp, "P_C", sizeof(strDisp));
		    else													memcpy(strDisp, "P_H", sizeof(strDisp));
			break;

			case RUN_SET_ADDR:
			ledFlash = FLASH_DIGIT;
			memcpy(strDisp, ToDisplay(ClockRAM.config.addr), sizeof(strDisp));
			break;
		}
		break;

		case CURR_SERVICE:
		ledRegim = REGIM_OFF;
		ledState = STATE_OFF;
		ledFlash = FLASH_OFF;
		switch(Menu.ServiceMenu)
		{
			case SERVICE_UGO:			// 1
			memcpy(strDisp, "YG0", sizeof(strDisp));
			break;

			case SERVICE_UGZ:			// 2
			memcpy(strDisp, "YG3", sizeof(strDisp));
			break;

			case SERVICE_UZO:			//	3
			memcpy(strDisp, "Y30", sizeof(strDisp));
			break;

			case SERVICE_GO1:			//	4
			memcpy(strDisp, "GO1", sizeof(strDisp));
			break;

			case SERVICE_GO2:			//	5
			memcpy(strDisp, "GO2", sizeof(strDisp));
			break;

			case SERVICE_NAG:			//	6
			memcpy(strDisp, "HAG", sizeof(strDisp));
			break;

			case SERVICE_NAS:			//	7
			memcpy(strDisp, "HAC", sizeof(strDisp));
			break;

			case SERVICE_VEN:			//	8
			memcpy(strDisp, "VEH", sizeof(strDisp));
			break;

			case SERVICE_LOCK:			//	9
			memcpy(strDisp, "6ZG", sizeof(strDisp));
			break;

			case SERVICE_TPOD:			//	10
			memcpy(strDisp, "_tZ", sizeof(strDisp));
			break;

			case SERVICE_TOBR:			//	11
			memcpy(strDisp, "_t0", sizeof(strDisp));
			break;

			case SERVICE_TGOR:			//	12
			memcpy(strDisp, "_tG", sizeof(strDisp));
			break;

			case SERVICE_TSG:			//	13
			memcpy(strDisp, "_tC", sizeof(strDisp));
			break;

			case SERVICE_TVYH:			//	14
			memcpy(strDisp, "_t8", sizeof(strDisp));
			break;

			case SERVICE_CC:			//	15
			memcpy(strDisp, "C_C", sizeof(strDisp));
			break;

			case SERVICE_CR:			//	16
			memcpy(strDisp, "C_P", sizeof(strDisp));
			break;

			case SERVICE_7C:			//	17
			memcpy(strDisp, "7_C", sizeof(strDisp));
			break;

			case SERVICE_PV:			//	18
			memcpy(strDisp, "_Z8", sizeof(strDisp));
			break;

			case SERVICE_PG:			//	19
			memcpy(strDisp, "_ZG", sizeof(strDisp));
			break;

			case SERVICE_PR:			//	20
			memcpy(strDisp, "_ZP", sizeof(strDisp));
			break;

			default:
			break;
		}
		break;

		case SUB_MENU_SERVICE:
		ledRegim = REGIM_OFF;
		ledState = STATE_OFF;
		ledFlash = FLASH_DIGIT;
		switch(Menu.ServiceMenu)
		{
			case SERVICE_UGO:			// 1
			if(Menu.Param == 0)
			{
				memcpy(strDisp, "-0-", sizeof(strDisp));
				Relays(RELAY_KOLOSNIK_ON, 0);
			}
			if(Menu.Param == 1)
			{
				memcpy(strDisp, "-1-", sizeof(strDisp));
				Relays(RELAY_KOLOSNIK_ON, 1);
			}
			break;

			case SERVICE_UGZ:			// 2
			if(Menu.Param == 0)
			{
				memcpy(strDisp, "-0-", sizeof(strDisp));
				Relays(RELAY_KOLOSNIK_OFF, 0);
			}
			if(Menu.Param == 1)
			{
				memcpy(strDisp, "-1-", sizeof(strDisp));
				Relays(RELAY_KOLOSNIK_OFF, 1);
			}
			break;

			case SERVICE_UZO:			//	3
			if(Menu.Param == 0)
			{
				memcpy(strDisp, "-0-", sizeof(strDisp));
				Relays(RELAY_SHNEK3, 0);
			}
			if(Menu.Param == 1)
			{
				memcpy(strDisp, "-1-", sizeof(strDisp));
				Relays(RELAY_SHNEK3, 1);
			}
			break;

			case SERVICE_GO1:			//	4
			if(Menu.Param == 0)
			{
				memcpy(strDisp, "-0-", sizeof(strDisp));
				Relays(RELAY_SHNEK1, 0);
			}
			if(Menu.Param == 1)
			{
				memcpy(strDisp, "-1-", sizeof(strDisp));
				Relays(RELAY_SHNEK1, 1);
			}
			break;

			case SERVICE_GO2:			//	5
			if(Menu.Param == 0)
			{
				memcpy(strDisp, "-0-", sizeof(strDisp));
				Relays(RELAY_SHNEK2, 0);
			}
			if(Menu.Param == 1)
			{
				memcpy(strDisp, "-1-", sizeof(strDisp));
				Relays(RELAY_SHNEK2, 1);
			}
			break;

			case SERVICE_NAG:			//	6
			if(Menu.Param == 0)
			{
				memcpy(strDisp, "-0-", sizeof(strDisp));
				Relays(RELAY_HEATER, 0);
			}
			if(Menu.Param == 1)
			{
				memcpy(strDisp, "-1-", sizeof(strDisp));
				Relays(RELAY_HEATER, 1);
			}
			break;

			case SERVICE_NAS:			//	7
			if(Menu.Param == 0)
			{
				memcpy(strDisp, "-0-", sizeof(strDisp));
				Relays(RELAY_PUMP, 0);
			}
			if(Menu.Param == 1)
			{
				memcpy(strDisp, "-1-", sizeof(strDisp));
				Relays(RELAY_PUMP, 1);
			}
			break;

			case SERVICE_VEN:			//	8
			if(Menu.Param == 0)
			{
				memcpy(strDisp, "-0-", sizeof(strDisp));
				sifuTestFlag = 0;	// drivers.c TestVentilator();
			}
			if(Menu.Param == 1)
			{
				memcpy(strDisp, "-1-", sizeof(strDisp));
				sifuTestFlag = 1;
			}
			break;

			case SERVICE_LOCK:			//	9
			if(Menu.Param == 0)
			{
				memcpy(strDisp, "-0-", sizeof(strDisp));
				Relays(RELAY_LOCK, 0);
			}
			if(Menu.Param == 1)
			{
				memcpy(strDisp, "-1-", sizeof(strDisp));
				Relays(RELAY_LOCK, 1);
			}
			break;

			case SERVICE_TPOD:			//	10
			memcpy(strDisp, ToDisplay(T_hot), sizeof(strDisp));
			break;

			case SERVICE_TOBR:			//	11
			memcpy(strDisp, ToDisplay(T_cold), sizeof(strDisp));
			break;

			case SERVICE_TGOR:			//	12
			memcpy(strDisp, ToDisplay(T_gor), sizeof(strDisp));
			break;

			case SERVICE_TSG:			//	13
			memcpy(strDisp, ToDisplay(T_sg), sizeof(strDisp));
			break;

			case SERVICE_TVYH:			//	14
			memcpy(strDisp, ToDisplay(T_vyh), sizeof(strDisp));
			break;

			case SERVICE_CC:			//	15
			memcpy(strDisp, "C_C", sizeof(strDisp));
			ledFlash = FLASH_DIGIT | FLASH_STATE_RG;
			break;

			case SERVICE_CR:			//	16
			memcpy(strDisp, "C_P", sizeof(strDisp));
			ledFlash = FLASH_DIGIT | FLASH_REGIM_RG;
			break;

			case SERVICE_7C:			//	17
			ledFlash = FLASH_OFF;
			if(rm_counter > 9)		rm_counter = 0;
			switch(rm_counter)
			{
				case 0:
				memcpy(strDisp, "000", sizeof(strDisp));
				break;
				case 1:
				memcpy(strDisp, "111", sizeof(strDisp));
				break;
				case 2:
				memcpy(strDisp, "222", sizeof(strDisp));
				break;
				case 3:
				memcpy(strDisp, "333", sizeof(strDisp));
				break;
				case 4:
				memcpy(strDisp, "444", sizeof(strDisp));
				break;
				case 5:
				memcpy(strDisp, "555", sizeof(strDisp));
				break;
				case 6:
				memcpy(strDisp, "666", sizeof(strDisp));
				break;
				case 7:
				memcpy(strDisp, "777", sizeof(strDisp));
				break;
				case 8:
				memcpy(strDisp, "888", sizeof(strDisp));
				break;
				case 9:
				memcpy(strDisp, "999", sizeof(strDisp));
				break;
			}
			break;

			case SERVICE_PV:			//	18
			ledFlash = FLASH_DIGIT;
			if(BIT_TEST(inputData, PV_INPUT_BIT))	memcpy(strDisp, "-1-", sizeof(strDisp));
			else									memcpy(strDisp, "-0-", sizeof(strDisp));
			break;

			case SERVICE_PG:			//	19
			ledFlash = FLASH_DIGIT;
			if(BIT_TEST(inputData, PG_INPUT_BIT))	memcpy(strDisp, "-1-", sizeof(strDisp));
			else									memcpy(strDisp, "-0-", sizeof(strDisp));
			break;

			case SERVICE_PR:			//	20
			ledFlash = FLASH_DIGIT;
			if(BIT_TEST(inputData, PR_INPUT_BIT))	memcpy(strDisp, "-1-", sizeof(strDisp));
			else									memcpy(strDisp, "-0-", sizeof(strDisp));
			break;

			default:
			break;
		}
		break;

		case IN_TO_SERVICE:
		ledFlash = FLASH_OFF;
		ledRegim = REGIM_OFF;
		ledState = STATE_OFF;
		memcpy(strDisp, "CP8", sizeof(strDisp));
		timeoutService = TIMEOUT_SERVICE;
		if(rm_counter > 5)
		{
			Menu.CurrMenu = CURR_SERVICE;
			Menu.ServiceMenu = SERVICE_MIN;
			OffAllRelays();
			timeoutService = 0;
		}
		break;
	}
}

void InitInputs(void)
{ // inputData
	InitD(&DT1A);
	InitD(&DT3A);
	InitD(&DDP1);
}

void TestInputs(void)
{ // inputData
	TestD(&DT1A, DEFAULT_CFG_DELAY, PV_INPUT_BIT, PV_DIO_BIT); // DIO, bit 6
	TestD(&DT3A, DEFAULT_CFG_DELAY, PG_INPUT_BIT, PG_DIO_BIT); // DIO, bit 7
	TestD(&DDP1, DEFAULT_CFG_DELAY, PR_INPUT_BIT, PR_DIO_BIT); // DIO, bit 8
	if(BIT_TEST(DIO, PV_DIO_BIT) == 0)
	{
		BIT_SET(DIO, PG_DIO_BIT);
		BIT_SET(DIO, PR_DIO_BIT);
	}
	if(BIT_TEST(DIO, PG_DIO_BIT) == 0)
	{
		BIT_SET(DIO, PR_DIO_BIT);
	}
}

void InitD(input_t *dd)
{//
	dd->delay = DEFAULT_CFG_DELAY;
	dd->state = 1;
}

void TestD(input_t *DP , uint16_t dly, uint16_t in_bit, uint16_t out_bit)
{	// inputData, out in register DIO
	uint8_t val;

	if(BIT_TEST(inputData, in_bit))	val = 1;
	else							val = 0;
	if(DP->state != val)
	{
		DP->state = val;
		DP->delay = dly;
		if(DP->delay == 0)		DP->delay = 1;
	}
	if(DP->delay == 0)
	{
		if(DP->state)
		{
			BIT_SET(DIO, out_bit);
		}
		else
		{
			BIT_CLR(DIO, out_bit);
		}
	}
}

void Avary1DT1A(void)
{ // 1, APV
	if(!((BIT_TEST(DIO, PV_DIO_BIT) == 0) && (T_hot >= (int16_t)ClockRAM.config.T9)))
	{ // alarm bit 0
		BIT_CLR(ClockRAM.config.flagAvary, ALR_BIT_PODACHA);
	}
	if((BIT_TEST(DIO, PV_DIO_BIT) == 0) && (T_hot >= (int16_t)ClockRAM.config.T9) && (BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_PODACHA) == 0))
	{ // alarm bit 0
		BIT_SET(ClockRAM.config.flagAvary, ALR_BIT_PODACHA);
		UnitOff(PUMP_RUN_ON, SHNECK_COOL_OFF);		// off unit, ВН+АО
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, ALR_BIT_PODACHA))
		{
			BIT_CLR(ClockRAM.config.alr, ALR_BIT_PODACHA);
			BIT_SET(ClockRAM.config.alrMemory, ALR_BIT_PODACHA);
		}
	}
}

void Avary2DT3A(void)
{ // 2, APG
	if(!((BIT_TEST(DIO, PG_DIO_BIT) == 0) && (T_gor >= (int16_t)ClockRAM.config.T11)))
	{ // alarm bit 1
		BIT_CLR(ClockRAM.config.flagAvary, ALR_BIT_SHNECK);
	}
	if((BIT_TEST(DIO, PG_DIO_BIT) == 0) && (T_gor >= (int16_t)ClockRAM.config.T11) && (BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SHNECK) == 0))
	{ // alarm bit 1
		BIT_SET(ClockRAM.config.flagAvary, ALR_BIT_SHNECK);
		UnitOff(PUMP_RUN_OFF, SHNECK_COOL_ON);			// off unit, ОШ+АО
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, ALR_BIT_SHNECK))
		{
			BIT_CLR(ClockRAM.config.alr, ALR_BIT_SHNECK);
			BIT_SET(ClockRAM.config.alrMemory, ALR_BIT_SHNECK);
		}
	}
}

void Avary3DP1(void)
{ // 3, NPR
	if(!(BIT_TEST(DIO, PR_DIO_BIT) && (BIT_TEST(DIO, RELAY_PUMP) == 0)))
	{
		BIT_CLR(ClockRAM.config.flagAvary, ALR_BIT_PROTOK);
	}
	if(BIT_TEST(DIO, PR_DIO_BIT) && (BIT_TEST(DIO, RELAY_PUMP) == 0) && (BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_PROTOK) == 0))
	{ // alarm bit 2
		BIT_SET(ClockRAM.config.flagAvary, ALR_BIT_PROTOK);
		UnitOff(PUMP_RUN_OFF, SHNECK_COOL_OFF);		// off unit,  АО
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, ALR_BIT_PROTOK))
		{
			BIT_CLR(ClockRAM.config.alr, ALR_BIT_PROTOK);
			BIT_SET(ClockRAM.config.alrMemory, ALR_BIT_PROTOK);
		}
	}
}

void Avary4DT1(void)
{ // 4, NtP
	if(!((BIT_TEST(DIO, PV_DIO_BIT) == 0) && (T_hot < (int16_t)ClockRAM.config.T9)))
	{ // alarm bit 3
		BIT_CLR(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_PODACHA);
	}
	if((BIT_TEST(DIO, PV_DIO_BIT) == 0) && (T_hot < (int16_t)ClockRAM.config.T9) && (BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_PODACHA) == 0))
	{ // alarm bit 3
		BIT_SET(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_PODACHA);
		UnitOff(PUMP_RUN_ON, SHNECK_COOL_OFF);		// off unit, ВН+АО
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, ALR_BIT_SENSOR_PODACHA))
		{
			BIT_CLR(ClockRAM.config.alr, ALR_BIT_SENSOR_PODACHA);
			BIT_SET(ClockRAM.config.alrMemory, ALR_BIT_SENSOR_PODACHA);
		}
	}
}

void Avary5DT1A(void)
{ // 5, NPV
	if(!((T_hot > (int16_t)ClockRAM.config.T10) && BIT_TEST(DIO, PV_DIO_BIT)))
	{ // alarm bit 4
		BIT_CLR(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_PODACHA2);
	}
	if((T_hot > (int16_t)ClockRAM.config.T10) && BIT_TEST(DIO, PV_DIO_BIT) && (BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_PODACHA2) == 0))
	{ // alarm bit 4
		BIT_SET(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_PODACHA2);
		UnitOff(PUMP_RUN_ON, SHNECK_COOL_OFF);		// off unit, ВН+АО
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, ALR_BIT_SENSOR_PODACHA2))
		{
			BIT_CLR(ClockRAM.config.alr, ALR_BIT_SENSOR_PODACHA2);
			BIT_SET(ClockRAM.config.alrMemory, ALR_BIT_SENSOR_PODACHA2);
		}
	}
}

void Avary6DT3(void)
{ // 6, NtG
	if(!((BIT_TEST(DIO, PG_DIO_BIT) == 0) && (T_gor < (int16_t)ClockRAM.config.T11)))
	{ // alarm bit 5
		BIT_CLR(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_SHNECK);
	}
	if((BIT_TEST(DIO, PG_DIO_BIT) == 0) && (T_gor < (int16_t)ClockRAM.config.T11) && (BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_SHNECK) == 0))
	{ // alarm bit 5
		BIT_SET(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_SHNECK);
		UnitOff(PUMP_RUN_OFF, SHNECK_COOL_OFF);		// off unit, АО
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, ALR_BIT_SENSOR_SHNECK))
		{
			BIT_CLR(ClockRAM.config.alr, ALR_BIT_SENSOR_SHNECK);
			BIT_SET(ClockRAM.config.alrMemory, ALR_BIT_SENSOR_SHNECK);
		}
	}
}

void Avary7DT3A(void)
{ // 7, NPG
	if(!(BIT_TEST(DIO, PG_DIO_BIT) && (T_gor > (int16_t)ClockRAM.config.T12)))
	{ // alarm bit 6
		BIT_CLR(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_SHNECK2);
	}
	if(BIT_TEST(DIO, PG_DIO_BIT) && (T_gor > (int16_t)ClockRAM.config.T12) && (BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_SHNECK2) == 0))
	{ // alarm bit 6
		BIT_SET(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_SHNECK2);
		UnitOff(PUMP_RUN_OFF, SHNECK_COOL_ON);		// off unit, ОШ+АО
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, ALR_BIT_SENSOR_SHNECK2))
		{
			BIT_CLR(ClockRAM.config.alr, ALR_BIT_SENSOR_SHNECK2);
			BIT_SET(ClockRAM.config.alrMemory, ALR_BIT_SENSOR_SHNECK2);
		}
	}
}

void Avary8(void)
{ // alarm bit 7
	if(BIT_TEST(ClockRAM.config.alr, ALR_BIT_IGNITION))
	{
		BIT_CLR(ClockRAM.config.alr, ALR_BIT_IGNITION);
		BIT_SET(ClockRAM.config.alrMemory, ALR_BIT_IGNITION);
		BIT_CLR(ClockRAM.config.flagAvary, ALR_BIT_IGNITION);
	}
}

void Avary9DP1(void)
{ // 9, ANP
	if(!((BIT_TEST(DIO, PR_DIO_BIT) == 0) && BIT_TEST(DIO, RELAY_PUMP)))
	{ // alarm bit 8
		BIT_CLR(ClockRAM.config.flagAvary, ALR_BIT_NO_PROTOK);
	}
	if((BIT_TEST(DIO, PR_DIO_BIT) == 0) && BIT_TEST(DIO, RELAY_PUMP) && (BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_NO_PROTOK) == 0))
	{ // alarm bit 8
		BIT_SET(ClockRAM.config.flagAvary, ALR_BIT_NO_PROTOK);
		UnitOff(PUMP_RUN_OFF, SHNECK_COOL_OFF);		// off unit
	}
	else
	{
		if(BIT_TEST(ClockRAM.config.alr, ALR_BIT_NO_PROTOK))
		{
			BIT_CLR(ClockRAM.config.alr, ALR_BIT_NO_PROTOK);
			BIT_SET(ClockRAM.config.alrMemory, ALR_BIT_NO_PROTOK);
		}
	}
}

void Avary10DT1(void)
{ // 10, OtP // alarm bit 9
	// drivers.c, TestNTCsensor();
}

void Avary11DT1(void)
{ // 11, OtP // alarm bit 10
	// drivers.c, TestNTCsensor();
}

void SetAvary(void)
{
	if(alarmState_old != ClockRAM.config.alr)
	{
		if(alarmState_old < ClockRAM.config.alr)
		{
			Beep(BEEP_PULSE_5);
		}
		alarmState_old = ClockRAM.config.alr;
	}
	if(alarm_old != ALR)
	{
		alarm_old = ALR;
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println1("\nALR: 0x");
			itoa(ALR, buff, 16);
			Println1(buff);
		}
#endif
	}
	if(warning_old != ClockRAM.config.wrn)
	{
		if(warning_old < ClockRAM.config.wrn)
		{
			Beep(BEEP_PULSE_4);
		}
		warning_old = ClockRAM.config.wrn;
#ifdef _AUTOMAT_OUTPUT_UART
		if(log_debug)
		{
			Println1("\nwrn: 0x");
			itoa(ClockRAM.config.wrn, buff, 16);
			Println1(buff);
		}
#endif
	}
#ifdef _AUTOMAT_OUTPUT_UART
	if(log_debug)
	{
		if(di_old != DIO)
		{
			Println1("\ndio: 0x");
			itoa(DIO, buff, 16);
			Println1(buff);
			di_old = DIO;
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_PODACHA))			Println1(", avary_podacha");   			// 0
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SHNECK))			Println1(", avary_shneck");   			// 1
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_PROTOK))			Println1(", avary_protok"); 			// 2
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_PODACHA))	Println1(", avary_sensor_podacha");  	// 3
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_PODACHA2))	Println1(", avary_sensor_podacha_2");  	// 4
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_SHNECK))		Println1(", avary_sensor_shneck");		// 5
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SENSOR_SHNECK2))	Println1(", avary_sensor_shneck_2");	// 6
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_IGNITION))			Println1(", avary_ignition");		// 7
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_NO_PROTOK))			Println1(", avary_no_protok");			// 8
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_OPEN_HOT))			Println1(", avary_open_sensor");		// 9
			if(BIT_TEST(ClockRAM.config.flagAvary, ALR_BIT_SHORT_HOT))			Println1(", avary_short_sensor");		// 10
		}
		if(BIT_TEST(DIO, RELAY_FAN))
		{
			if(sifuOld != Unit.sifu)
			{
				Println1("\nsifu: ");
				itoa(Unit.sifu, buff, 10);
				Println1(buff);
				sifuOld = Unit.sifu;
			}
		}
	}
#endif
	if(ClockRAM.config.srk > GO_WAIT_STATE)
	{
		Avary1DT1A();		// alarmState, bit0
		Avary2DT3A();		// alarmState, bit1
//		Avary3DP1();		// alarmState, bit2
		Avary4DT1();		// alarmState, bit3
		Avary5DT1A();		// alarmState, bit4
		Avary6DT3();		// alarmState, bit5
		Avary7DT3A();		// alarmState, bit6
		Avary8();			// alarmState, bit7
		Avary9DP1();		// alarmState, bit8
		Avary10DT1();		// alarmState, bit9
		Avary11DT1();		// alarmState, bit10
	}
	ALR = ClockRAM.config.alr | ClockRAM.config.alrMemory;
	Warnings();
}

void Warnings(void)
{
	// warnings 0...3 in drivers.c, TestNTCsensor();

	if(BIT_TEST(ClockRAM.config.wrn, WRN_BIT_OPEN_DT2))
	{
		if(T_gor >= (int16_t)ClockRAM.config.T8)	BIT_SET(ClockRAM.config.wrn, WRN_BIT_SHNECK);	// warning bit 5
		else										BIT_CLR(ClockRAM.config.wrn, WRN_BIT_SHNECK);
	}
	if(BIT_TEST(ClockRAM.config.wrn, WRN_BIT_SHNECK))		Shneck.state = SHNECK_COOL;
	if(((ClockRAM.config.flagAvary & ALR_DT1_MASK) == 0) && ((ClockRAM.config.alr & ALR_DT1_MASK) == 0) && ((ClockRAM.config.alrMemory & ALR_DT1_MASK) == 0))
	{
		if(T_hot >= (int16_t)ClockRAM.config.T7)	BIT_SET(ClockRAM.config.wrn, WRN_BIT_PODACHA);	// warning bit 4
		else										BIT_CLR(ClockRAM.config.wrn, WRN_BIT_PODACHA);
		if(T_hot < ClockRAM.config.T19)				BIT_SET(ClockRAM.config.wrn, WRN_BIT_FROZE);	// warning bit 6
		if(BIT_TEST(ClockRAM.config.wrn, WRN_BIT_FROZE) && (T_hot >= (ClockRAM.config.T19 + ClockRAM.config.delta_T19)))	BIT_CLR(ClockRAM.config.wrn, WRN_BIT_FROZE);	// warning bit 6
	}
	WarningWarmDown();

}

void WarningWarmDown(void)
{
	if((Unit.State == STABLE_STATE) || (Unit.State == WORK_STATE))
	{// AP8 - warm down
		if(BIT_TEST(ClockRAM.config.rc, RC_BIT_IGNITION_TOPKA))
		{ // DT4
			if(T_sg < (ClockRAM.config.T4 - ClockRAM.config.delta_T4))	BIT_SET(ClockRAM.config.wrn, WRN_BIT_HOT_DOWN);
		}
		else
		{ // DT5
			if(T_vyh < (ClockRAM.config.T4 - ClockRAM.config.delta_T4))	BIT_SET(ClockRAM.config.wrn, WRN_BIT_HOT_DOWN);
		}
		if(BIT_TEST(ClockRAM.config.wrn, WRN_BIT_HOT_DOWN))
		{ //
			if(BIT_TEST(ClockRAM.config.rc, RC_BIT_AUTO_IGNITION))		Unit.State = GO_IGNITION_STATE;
			else
			{
				Ventilator(1, 0);  // podduff off
				BIT_SET(ClockRAM.config.flagAvary, ALR_BIT_IGNITION);
				UnitOff(PUMP_RUN_OFF, SHNECK_COOL_OFF);		// off unit
			}
		}
	}
}

void DisplayAvary(uint16_t cnt)
{
	if((ClockRAM.config.alr) || (ClockRAM.config.flagAvary))
	{
		ledState = STATE_RED;
		ledFlash = FLASH_DIGIT;
		if(BitCalc(ClockRAM.config.alr) > 1)		indPoints = 1;
		else										indPoints = 0;
		switch(cnt)
		{
			default:
			break;

			case 0:
			memcpy(strDisp, "AZ8", sizeof(strDisp));	// "АПВ"
			break;

			case 1:
			memcpy(strDisp, "AZG", sizeof(strDisp));	// "АПГ"
			break;

			case 2:
			memcpy(strDisp, "HZP", sizeof(strDisp));	// "HПP"
			break;

			case 3:
			memcpy(strDisp, "HtZ", sizeof(strDisp));	// "HtП"
			break;

			case 4:
			memcpy(strDisp, "HZ8", sizeof(strDisp));	// "НПВ"
			break;

			case 5:
			memcpy(strDisp, "HtG", sizeof(strDisp));	// "НtC"
			break;

			case 6:
			memcpy(strDisp, "HZG", sizeof(strDisp));	// "HПГ"
			break;

			case 7:
			memcpy(strDisp, "AP3", sizeof(strDisp));	// "AP3"
			break;

			case 8:
			memcpy(strDisp, "AZP", sizeof(strDisp));	// "AПP"
			break;

			case 9:
			memcpy(strDisp, "0tZ", sizeof(strDisp));	// "0tП"
			break;

			case 10:
			memcpy(strDisp, "3tZ", sizeof(strDisp));	// "3tП"
			break;
		}
	}
	else if(ClockRAM.config.alrMemory)
	{
		ledState = STATE_RED;
		ledFlash = FLASH_OFF;
		if(BitCalc(ClockRAM.config.alrMemory) > 1)		indPoints = 1;
		else											indPoints = 0;
		switch(cnt)
		{
			default:
			break;

			case 0:
			memcpy(strDisp, "AZ8", sizeof(strDisp));	// "АПВ"
			break;

			case 1:
			memcpy(strDisp, "AZG", sizeof(strDisp));	// "АПГ"
			break;

			case 2:
			memcpy(strDisp, "HZP", sizeof(strDisp));	// "HПP"
			break;

			case 3:
			memcpy(strDisp, "HtZ", sizeof(strDisp));	// "HtП"
			break;

			case 4:
			memcpy(strDisp, "HZ8", sizeof(strDisp));	// "НПВ"
			break;

			case 5:
			memcpy(strDisp, "HtG", sizeof(strDisp));	// "НtC"
			break;

			case 6:
			memcpy(strDisp, "HZG", sizeof(strDisp));	// "HПГ"
			break;

			case 7:
			memcpy(strDisp, "AP3", sizeof(strDisp));	// "AP3"
			break;

			case 8:
			memcpy(strDisp, "AZP", sizeof(strDisp));	// "AПP"
			break;

			case 9:
			memcpy(strDisp, "0tZ", sizeof(strDisp));	// "0tП"
			break;

			case 10:
			memcpy(strDisp, "3tZ", sizeof(strDisp));	// "3tП"
			break;
		}
	}
}

void DispRunMenu(void)
{
	if(BIT_TEST(ClockRAM.config.rr, RR_BIT_CLEAR))
	{
		ledFlash = FLASH_REGIM_RG;
		ledState = STATE_OFF;
	}
	else
	{
		ledFlash = FLASH_OFF;
		ledState = STATE_GREEN;
		if(ClockRAM.config.wrn)								ledState |= STATE_RED;
		if(BIT_TEST(ClockRAM.config.rr, RR_BIT_REMOTE))		ledRegim = REGIM_GREEN;
		if(BIT_TEST(ClockRAM.config.rr, RR_BIT_LOCAL))		ledRegim = REGIM_YELLOW;

		if(Unit.State == WAIT_STATE)				ledFlash = FLASH_STATE_1;
		else if(Unit.State == WAIT_STATE_TIMEOUT)	ledFlash = FLASH_STATE_1;
		else if(Unit.State == IGNITION_STATE)		ledFlash = FLASH_STATE_2;
		else if(Unit.State == STABLE_STATE)			ledFlash = FLASH_STATE_3;
		else if(Unit.State == WARMDOWN_STATE)		ledFlash = FLASH_STATE_4;
	}
}

uint16_t GetCntDisplayAvary(uint16_t curr_cnt, uint8_t dir)
{
	uint16_t cnt;

	cnt = curr_cnt;
	if(dir == 0)  // 0 - no change
	{
		if(ClockRAM.config.alr)
		{
			if(BIT_TEST(ClockRAM.config.alr, curr_cnt) == 0)
			{
				dir = 1;
			}
		}
		else if(ClockRAM.config.alrMemory)
		{
			if(BIT_TEST(ClockRAM.config.alrMemory, curr_cnt) == 0)
			{
				dir = 1;
			}
		}
	}
	if(dir == 1)
	{ // increment, 1
		if(ClockRAM.config.alr)
		{
			do
			{
				cnt++;
				if(cnt > DISPLAY_AVARY_MAX) 	cnt = DISPLAY_AVARY_MIN;
				if(BIT_TEST(ClockRAM.config.alr, cnt))	break;
			}while(cnt != curr_cnt);
		}
		else if(ClockRAM.config.alrMemory)
		{
			do
			{
				cnt++;
				if(cnt > DISPLAY_AVARY_MAX) 	cnt = DISPLAY_AVARY_MIN;
				if(BIT_TEST(ClockRAM.config.alrMemory, cnt))	break;
			}while(cnt != curr_cnt);
		}
	}
	if(dir == 2)
	{ // decrement, 2
		if(ClockRAM.config.alr)
		{
			do
			{
				if(cnt >= DISPLAY_AVARY_MIN)	cnt--;
				if(cnt < DISPLAY_AVARY_MIN)	cnt = DISPLAY_AVARY_MAX;
				if(BIT_TEST(ClockRAM.config.alr, cnt))	break;
			}while(cnt != curr_cnt);
		}
		else if(ClockRAM.config.alrMemory)
		{
			do
			{
				if(cnt >= DISPLAY_AVARY_MIN)	cnt--;
				if(cnt < DISPLAY_AVARY_MIN)		cnt = DISPLAY_AVARY_MAX;
				if(BIT_TEST(ClockRAM.config.alrMemory, cnt))	break;
			}while(cnt != curr_cnt);
		}
	}
	return cnt;
}

void WaitingMode(void)
{ // go to waiting mode, off state

}

uint8_t BitCalc(uint16_t val)
{
	uint8_t nBits, ci;

	nBits = 0;
	for(ci=DISPLAY_AVARY_MIN; ci<DISPLAY_AVARY_MAX; ci++)
	{
		if(BIT_TEST(val, ci))	nBits++;
	}
	return nBits;
}

void Kolosnik(void)
{
	uint16_t onTime, offTime;

	if(Unit.kolosnikOnTime)		Unit.kolosnikOnTime--;
	if(Unit.kolosnikOffTime)	Unit.kolosnikOffTime--;
	if(BIT_TEST(ClockRAM.config.rc, RC_BIT_ON_KOLOSNIK) == 0)		return;
	switch(Unit.State)
	{
	default:
		break;

	case STABLE_STATE:
		onTime = ClockRAM.config.t9;
		offTime = ClockRAM.config.t10;
		break;

	case WORK_STATE:
		switch(Unit.Regim)
		{
		case 0:
		case 3:
		default:  // PI-reg
			onTime = Unit.kolosnikOnPI;
			offTime = Unit.kolosnikOffPI;
			break;

		case 1:  // P-nominal
			onTime = ClockRAM.config.t9;
			offTime = ClockRAM.config.t10;
			break;

		case 2: // P-min
			onTime = ClockRAM.config.t20;
			offTime = ClockRAM.config.t21;
			break;
		}
		break;
		break;
	}
	switch(Unit.kolosnikCntr)
	{ // kolosnik run
	default:
	case KOLOSNIK_WAIT:
		break;

	case KOLOSNIK_RUN:
		if((Unit.kolosnikOnTime == 0) && (Unit.kolosnikOffTime == 0))
		{
			Unit.kolosnikOnTime = onTime;
			Relays(RELAY_KOLOSNIK_ON, 1);   // on kolosnik open
			Relays(RELAY_KOLOSNIK_OFF, 0);  // off kolosnik close
			Unit.kolosnikCntr++;
		}
		break;

	case KOLOSNIK_RUN+1:
		if(Unit.kolosnikOnTime == 0)
		{
			Relays(RELAY_KOLOSNIK_ON, 0);  // off kolosnik open
			Unit.kolosnikOffTime = offTime;
			if(BIT_TEST(ClockRAM.config.rc, RC_BIT_POS_KILISNIK) == 0)
			{ // 0-two position
				Relays(RELAY_KOLOSNIK_OFF, 1);   // on kolosnik close
			}
			Unit.kolosnikCntr++;
		}
		break;

	case KOLOSNIK_RUN+2:
		if(Unit.kolosnikOffTime == 0)
		{
			Relays(RELAY_KOLOSNIK_ON, 0);  // off kolosnik open
			Relays(RELAY_KOLOSNIK_OFF, 0);  // off kolosnik close
			Unit.kolosnikCntr = KOLOSNIK_RUN;
		}
		break;

	case KOLOSNIK_STOP:
		Unit.kolosnikOnTime = 0;
		Unit.kolosnikOffTime = 0;
		Relays(RELAY_KOLOSNIK_ON, 0);  // off kolosnik open
		Relays(RELAY_KOLOSNIK_OFF, 0);  // off kolosnik close
		Unit.kolosnikCntr = KOLOSNIK_WAIT;
		break;
	}
}

void Podacha(void)
{
	uint16_t onTime, offTime;

	if(Unit.podachaOnTime)		Unit.podachaOnTime--;
	if(Unit.podachaOffTime)		Unit.podachaOffTime--;
	switch(Unit.State)
	{
	default:
		break;

	case STABLE_STATE:
		onTime = ClockRAM.config.t7;
		offTime = ClockRAM.config.t8;
		break;

	case WORK_STATE:
		switch(Unit.Regim)
		{
		case 0:
		case 3:
		default:  // PI-reg
			onTime = Unit.podachaOnPI;
			offTime = Unit.podachaOffPI;
			break;

		case 1:  // P-nominal
			onTime = ClockRAM.config.t7;
			offTime = ClockRAM.config.t8;
			break;

		case 2: // P-min
			onTime = ClockRAM.config.t22;
			offTime = ClockRAM.config.t23;
			break;
		}
		break;
	}
	switch(Unit.podachaCntr)
	{ // podacha run
	default:
	case PODACHA_WAIT:  // 0
		break;

	case PODACHA_RUN: // 1
		Unit.N1_cnt = ClockRAM.config.N1;
		Unit.N5_cnt = ClockRAM.config.N5;
		Unit.podachaCntr++;
		break;

	case PODACHA_RUN+1: // 2
		if((Unit.podachaOnTime == 0) && (Unit.podachaOffTime == 0))
		{
			Unit.podachaOnTime = onTime;
			Relays(RELAY_SHNEK1, 1);   // on podacha
			Unit.podachaCntr++;
		}
		break;

	case PODACHA_RUN+2:  // 3
		if(Unit.podachaOnTime == 0)
		{
			Relays(RELAY_SHNEK1, 0);  // off podacha
			Unit.podachaOffTime = offTime;
			Unit.podachaCntr++;
		}
		break;

	case PODACHA_RUN+3:  // 4
		if(Unit.podachaOffTime == 0)
		{
			if(Unit.N1_cnt)		Unit.N1_cnt--;
			if(Unit.N1_cnt == 0)
			{
				Unit.N1_cnt = ClockRAM.config.N1;
				Unit.zolodelCntr = ZOLODEL_RUN;
				if(Unit.N5_cnt)		Unit.N5_cnt--;
				if(Unit.N5_cnt == 0)
				{
					Unit.N5_cnt = ClockRAM.config.N5;
					BIT_SET(ClockRAM.config.rc, RC_BIT_ZOLO_DEL);
				}
			}
			Unit.podachaCntr = PODACHA_RUN+1;
		}
		break;

	case PODACHA_STOP:  // 10
		Relays(RELAY_SHNEK1, 0);  // off podacha
		Unit.N1_cnt = 0;
		Unit.N5_cnt = 0;
		Unit.podachaCntr = PODACHA_WAIT;
		break;

	}
}

void ZoloDel(void)
{  // to run zolodel -> Unit.zolodelCntr = ZOLODEL_RUN;
	if(Unit.zolodelTime)	Unit.zolodelTime--;
	switch(Unit.zolodelCntr)
	{
	default:
	case ZOLODEL_WAIT:  // 0
		break;

	case ZOLODEL_RUN:  // 1
		if(Unit.zolodelTime == 0)
		{
			Unit.zolodelTime = ClockRAM.config.t11;
			Relays(RELAY_SHNEK3, 1);  // zolodel on
			Unit.zolodelCntr++;
		}
		break;

	case ZOLODEL_RUN+1:  // 2
		if(Unit.zolodelTime == 0)
		{
			Relays(RELAY_SHNEK3, 0);  // zolodel off
			Unit.zolodelCntr = ZOLODEL_WAIT;
		}
		break;

	case ZOLODEL_STOP:  // 10
		Unit.zolodelTime = 0;
		Relays(RELAY_SHNEK3, 0);  // zolodel off
		Unit.zolodelCntr = ZOLODEL_WAIT;
		break;

	}
}

char* ToDisplay(int16_t val)
{
	char str[8];

	memset(str, 0, sizeof(str));
	itoa(val, str, 10);
	if(val < 0)
	{
		if(strlen(str) == 2)
		{
			buff[2] = str[1];
			buff[1] = '0';
			buff[0] = '-';
		}
		if(strlen(str) == 3)
		{
			buff[2] = str[2];
			buff[1] = str[1];
			buff[0] = '-';
		}
		if(strlen(str) > 3)
		{
			buff[2] = ' ';
			buff[1] = ' ';
			buff[0] = ' ';
		}
	}
	else
	{
		if(strlen(str) == 1)
		{
			buff[2] = str[0];
			buff[1] = '0';
			buff[0] = '0';
		}
		if(strlen(str) == 2)
		{
			buff[2] = str[1];
			buff[1] = str[0];
			buff[0] = '0';
		}
		if(strlen(str) > 2)
		{
			buff[2] = str[2];
			buff[1] = str[1];
			buff[0] = str[0];
		}
	}
	return buff;
}

void InitUnit(void)
{
	Unit.sifu = 0;
	Unit.sifuCnt = 0;
	ClockRAM.config.alr |= ClockRAM.config.flagAvary;
}

void LoadSettings(void)
{
	relayData = 0;
	DIO = 0;
	tempDIO = 0;
}

void SaveSettings(void)
{

}

void UnitOff(uint8_t vn, uint8_t osh)
{
	Unit.warmDownState = BEGIN_WARMDOWN;
	if(vn)		Relays(RELAY_PUMP, 1);
	if(osh)		Shneck.state = SHNECK_COOL;
}

void SetSRK(uint8_t bit)
{
	ClockRAM.config.srk = 0;
	BIT_SET(ClockRAM.config.srk, bit);
}

void SetRR(uint8_t bit)
{
	ClockRAM.config.rr = 0;
	BIT_SET(ClockRAM.config.rr, bit);
}

void IndexingRegisters(void)
{ // BA_REGISTERS
	ptr_reg[0] = &ClockRAM.config.null;			// loop
	ptr_reg[1] = &DIO;						// RAM,
	ptr_reg[2] = &ALR;						// RAM, ALR = ClockRAM.config.alr | ClockRAM.config.alrMemory;
	ptr_reg[3] = &ClockRAM.config.wrn;			// 4, 5
	ptr_reg[4] = &ClockRAM.config.srk;			// 6, 7
	ptr_reg[5] = &ClockRAM.config.rr;			// 10, 11
	ptr_reg[6] = &ClockRAM.config.rc;			// 14, 15
	ptr_reg[7] = &T1;						// RAM, TPP
	ptr_reg[8] = &T2;						// RAM, TOP
	ptr_reg[9] = &T3;						// RAM, TWP
	ptr_reg[10] = &T4;						// RAM, TTP
	ptr_reg[11] = &T5;						// RAM, TDP
	ptr_reg[12] = &ClockRAM.config.T1;			// 16, 17, ustavka
	ptr_reg[13] = &ClockRAM.config.T21;			// 18, 19, ustavka
	ptr_reg[14] = &Q0;						// RAM, oboroty
	ptr_reg[15] = &ClockRAM.config.Kp;			// 22, 23
	ptr_reg[16] = &ClockRAM.config.Ki;			// 24, 25
	ptr_reg[17] = &ClockRAM.config.t15;			// 26, 27
	ptr_reg[18] = &ClockRAM.config.Q1;			// 28, 29
	ptr_reg[19] = &ClockRAM.config.t1;			// 30, 31
	ptr_reg[20] = &ClockRAM.config.t2;			// 32, 33
	ptr_reg[21] = &ClockRAM.config.t3;			// 34, 35
	ptr_reg[22] = &ClockRAM.config.t4;			// 36, 37
	ptr_reg[23] = &ClockRAM.config.t5;			// 38, 39
	ptr_reg[24] = &ClockRAM.config.t6;			// 40, 41
	ptr_reg[25] = &ClockRAM.config.T4;			// 42_43
	ptr_reg[26] = &ClockRAM.config.Q4;			// 44_45
	ptr_reg[27] = &ClockRAM.config.T5;			// 46_47
	ptr_reg[28] = &ClockRAM.config.t7;			// 48_49
	ptr_reg[29] = &ClockRAM.config.t8;			// 50_51
	ptr_reg[30] = &ClockRAM.config.t9;			// 52_53
	ptr_reg[31] = &ClockRAM.config.t10;			// 54_55
	ptr_reg[32] = &ClockRAM.config.t11;			// 56_57
	ptr_reg[33] = &ClockRAM.config.Q2;			// 58_59
	ptr_reg[34] = &ClockRAM.config.Q3;			// 60_61
	ptr_reg[35] = &ClockRAM.config.N1;			// 62, 63
	ptr_reg[36] = &ClockRAM.config.delta_T3;	// 64, 65
	ptr_reg[37] = &ClockRAM.config.t12;			// 68, 69
	ptr_reg[38] = &ClockRAM.config.t13;			// 70, 71
	ptr_reg[39] = &ClockRAM.config.t14;			// 72, 73
	ptr_reg[40] = &ClockRAM.config.t16;			// 76, 77
	ptr_reg[41] = &ClockRAM.config.t17;			// 78, 79
	ptr_reg[42] = &ClockRAM.config.T6;			// 80, 81
	ptr_reg[43] = &ClockRAM.config.N2;			// 82, 83
	ptr_reg[44] = &ClockRAM.config.delta_T1;	// 84, 85,
	ptr_reg[45] = &ClockRAM.config.delta_T4;	// 74, 75, dT2
	ptr_reg[46] = &ClockRAM.config.t20;			// 76, 77
	ptr_reg[47] = &ClockRAM.config.t21;			// 78, 79
	ptr_reg[48] = &ClockRAM.config.t25;			// 80, 81
	ptr_reg[49] = &ClockRAM.config.T13;			// 82, 83
	ptr_reg[50] = &ClockRAM.config.T14;			// 84, 85
	ptr_reg[51] = &ClockRAM.config.addr;		// 86, 87, BA address
	ptr_reg[52] = &ClockRAM.config.t26;			// 88, 89
	ptr_reg[53] = &ClockRAM.config.Q7;			// 90, 91
	ptr_reg[54] = &ClockRAM.config.Q8;			// 92, 93
	ptr_reg[55] = &ClockRAM.config.T10;			// 94, 95
	ptr_reg[56] = &ClockRAM.config.T7;			// 96, 97
	ptr_reg[57] = &ClockRAM.config.T11;			// 98, 99
	ptr_reg[58] = &ClockRAM.config.T12;			// 100, 101
	ptr_reg[59] = &ClockRAM.config.T9;			// 102, 103
	ptr_reg[60] = &ClockRAM.config.T8;			// 104, 105
	ptr_reg[61] = &ClockRAM.config.t24;			// 106, 107
	ptr_reg[62] = &ClockRAM.config.preset;		// 108, 109
	ptr_reg[63] = &ClockRAM.config.t18;			// 110, 111
	ptr_reg[64] = &ClockRAM.config.T19;			// 112, 113
	ptr_reg[65] = &ClockRAM.config.delta_T19;	// 114, 115, dT4
	ptr_reg[66] = &ClockRAM.config.N3;			// 116, 117
	ptr_reg[67] = &ClockRAM.config.N4;			// 118, 119
	ptr_reg[68] = &ClockRAM.config.N5;			// 120, 121
	ptr_reg[69] = &ClockRAM.config.t22;			// 122, 123
	ptr_reg[70] = &ClockRAM.config.t23;			// 124, 125
	ptr_reg[71] = &ClockRAM.config.null;				// loop
	ptr_reg[72] = &ClockRAM.config.null;				// loop
}




