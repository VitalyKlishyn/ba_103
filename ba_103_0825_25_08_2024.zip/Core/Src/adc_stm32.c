#include "main.h"
#include "adc_stm32.h"

void adcInit()
{
	ADC1->IER = 0;
	ADC1->CR = 0;
	ADC1->CR |= ADC_CR_ADCAL;
	while(ADC1->CR & ADC_CR_ADCAL);				// wait end of calibrate ADC
	ADC1->CR |= ADC_CR_ADEN; 					// enable ADC
	ADC1->CFGR1 = 0;
	ADC1->CFGR2 = 0;
	ADC1->SMPR |= 0;
	ADC1->CHSELR = 0;
	if ((ADC1->ISR & ADC_ISR_ADRDY) != 0) //
	{
		ADC1->ISR |= ADC_ISR_ADRDY; //
	}
	ADC->CCR |= ADC_CCR_VREFEN | ADC_CCR_TSEN; //
	countSample = 0;
}

void Single(void)
{
/// Single conversion sequence
// 9-Uin (ADC_result[0]),
// 10-DT1(ADC_result[1]),
// 11-DT2(ADC_result[2]),
// 12-DT3(ADC_result[3]),
// 13-DT4(ADC_result[4]),
// 0-DT5 (ADC_result[5]),
	switch(countSample)
	{
	// Performs the AD conversion
	case 1:
		if(ADC1->ISR & ADC_ISR_EOC) // Wait end of conversion
		{
			ADC1->CHSELR = ADC_CHSELR_CHSEL0;// 0-DT5 (ADC_result[5])
			countSample++;
		}
		break;

	case 2:
		ADC1->CR |= ADC_CR_ADSTART; // Start the ADC conversion
		countSample++;
		break;

	case 3:
		if(ADC1->ISR & ADC_ISR_EOC) // Wait end of conversion
		{
			ADC_result[5] = ADC1->DR; // Store the ADC conversion result
			ADC1->CHSELR = ADC_CHSELR_CHSEL9;  // 9-Uin (ADC_result[0]),
			countSample++;
		}
		break;

	case 4:
		ADC1->CR |= ADC_CR_ADSTART; // Start the ADC conversion
		countSample++;
		break;

	case 5:
		if(ADC1->ISR & ADC_ISR_EOC) // Wait end of conversion
		{
			ADC_result[0] = ADC1->DR; // Store the ADC conversion result
			ADC1->CHSELR = ADC_CHSELR_CHSEL10;  // 10-DT1(ADC_result[1])
			countSample++;
		}
		break;

	case 6:
		ADC1->CR |= ADC_CR_ADSTART; // Start the ADC conversion
		countSample++;
		break;

	case 7:
		if(ADC1->ISR & ADC_ISR_EOC) // Wait end of conversion
		{
			ADC_result[1] = ADC1->DR; // Store the ADC conversion result
			ADC1->CHSELR = ADC_CHSELR_CHSEL11;  // 11-DT2(ADC_result[2])
			countSample++;
		}
		break;

	case 8:
		ADC1->CR |= ADC_CR_ADSTART; // Start the ADC conversion
		countSample++;
		break;

	case 9:
		if(ADC1->ISR & ADC_ISR_EOC) // Wait end of conversion
		{
			ADC_result[2] = ADC1->DR; // Store the ADC conversion result
			ADC1->CHSELR = ADC_CHSELR_CHSEL12;  // 12-DT3(ADC_result[3])
			countSample++;
		}
		break;

	case 10:
		ADC1->CR |= ADC_CR_ADSTART; // Start the ADC conversion
		countSample++;
		break;

	case 11:
		if(ADC1->ISR & ADC_ISR_EOC) // Wait end of conversion
		{
			ADC_result[3] = ADC1->DR; // Store the ADC conversion result
			ADC1->CHSELR = ADC_CHSELR_CHSEL13;  // 13-DT4(ADC_result[4])
			countSample++;
		}
		break;

	case 12:
		ADC1->CR |= ADC_CR_ADSTART; // Start the ADC conversion
		countSample++;
		break;

	case 13:
		if(ADC1->ISR & ADC_ISR_EOC) // Wait end of conversion
		{
			ADC_result[4] = ADC1->DR; // Store the ADC conversion result
			countSample++;
		}
		break;

	default:
		ADC1->CHSELR = ADC_CHSELR_CHSEL0;
		ADC1->CR |= ADC_CR_ADSTART; // Start the ADC conversion
		countSample = 1;
		break;
	}
}
